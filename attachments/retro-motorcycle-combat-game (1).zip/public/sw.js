/*
 * KILL SWITCH — this app no longer uses a service worker.
 *
 * An earlier version cached the game shell, so returning visitors kept getting
 * that stale build and the game opened to a black screen even after the bug was
 * fixed. This worker immediately unregisters itself and wipes every cache.
 *
 * It deliberately does NOT call clients.navigate(): doing so while the page also
 * registers a worker can produce an endless reload loop.
 */
self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    (async () => {
      try {
        const keys = await caches.keys();
        const old = keys.filter((k) => k.indexOf('roadfury') === 0);
        await Promise.all(old.map((k) => caches.delete(k)));
      } catch {
        /* ignore */
      }
      try {
        await self.registration.unregister();
      } catch {
        /* ignore */
      }
    })(),
  );
});

// Intentionally no fetch handler — always go to the network.
