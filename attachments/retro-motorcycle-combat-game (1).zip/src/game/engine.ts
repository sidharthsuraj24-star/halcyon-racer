import { audio } from './audio';
import {
  CONTACT_X,
  CONTACT_Y,
  LEAN_MAX,
  SPR_H,
  SPR_RATIO,
  SPR_W,
  drawArticulatedRider,
  drawWheel,
  type BikeSet,
  type RiderPose,
  type SwingAnim,
} from './bike';
import { BIKE_LOD_MIN_PX, RENDER_AREA, device } from './device';
import { haptic } from './haptics';
import { getSprites, spriteBuildPending, stepSpriteBuild, type Sprite, type SpriteBank } from './sprites';
import {
  CAMERA_HEIGHT,
  FIELD_OF_VIEW,
  FOG_DENSITY,
  LANES,
  MAX_SPEED,
  ROAD_WIDTH,
  SEGMENT_LENGTH,
  THEMES,
  TOTAL_SEGMENTS,
  blendThemes,
  buildTrack,
  findSegment,
  project,
  type Theme,
} from './track';
import type {
  Enemy,
  Entity,
  HudState,
  Particle,
  Pickup,
  Popup,
  RunResult,
  Segment,
  Traffic,
  WeaponKind,
} from './types';
import { WEAPONS } from './types';
import {
  clamp,
  css,
  cssA,
  exponentialFog,
  increase,
  lerp,
  makeRng,
  mixRgb,
  overlap,
  pick,
  randRange,
  wrapDelta,
  type RGB,
  type Rng,
} from './util';

const ACCEL = MAX_SPEED / 3.8; // pull near top speed
// A bike pulls hardest off the line and tapers as it approaches top speed.
// Without this, leaving the grid at 0 km/h felt like the throttle was broken.
const LAUNCH_ACCEL = MAX_SPEED / 1.35;
const LAUNCH_BAND = MAX_SPEED * 0.42;
const BOOST_ACCEL = MAX_SPEED / 2.2;
const BRAKING = -MAX_SPEED / 1.5; // S / ↓ — ~2.5× stronger than just letting off the gas
// Off-throttle "engine braking" + rolling resistance, like a real bike:
// a constant drag plus air resistance that grows with speed.
const COAST_DECEL = -MAX_SPEED / 8;
const AIR_DRAG = 0.32; // fraction of current speed shed per second
const STOP_SNAP = MAX_SPEED * 0.012; // below this with no gas, the bike settles to a full stop
const OFFROAD_DECEL = -MAX_SPEED / 1.8;
const OFFROAD_LIMIT = MAX_SPEED / 3.4;
const CENTRIFUGAL = 0.11; // smooth outward drift on curves (easily carved through)
const PLAYER_W = 0.15;
const ATTACK_TIME = 0.36;
const KICK_TIME = 0.3;
const KICK_CD = 0.55;
const WEAPON_DURABILITY: Record<WeaponKind, number> = { bat: Infinity, chain: 10, wrench: 6 };
const TAUNTS = ['EAT THIS!', 'TOO SLOW!', 'GOTCHA!', 'YER MINE!', 'WAKE UP!', 'OUT THE WAY!'];
const KO_TAUNTS = ['NOOO!', 'UUGGH!', 'CURSE YOU!', 'AAARGH!'];

/* ---- tyre & cornering model -------------------------------------------
 * Smooth, high-authority cornering with tactile tyre slip feedback:
 * - Steering builds lateral velocity quickly and self-centers crisply when released.
 * - Leaning into a corner (steerInput * curve > 0) gives apex turn-in bite.
 * - Hard cornering at high speed induces a controllable powerslide (tyre smoke,
 *   skid marks, rear wheel spin) WITHOUT ever locking up steering authority.
 */
const MAX_LAT_VEL = 2.65; // road-widths per second at full grip
const LAT_RESPONSE = 14; // how quickly the tyre builds lateral velocity
const GRIP_LOSS = 0.9; // grip shed per second, per unit of normalised over-demand
const GRIP_RECOVER = 1.15; // grip regained per second when not over-demanding
const SPEED_OVERDEMAND = 0.6; // extra lateral ask per unit of speed
const CURVE_GRIP_LOAD = 0.55; // a bend loads the tyre
const CURVE_NORMALISE = 6; // track curves run 0..7
const LEAN_PER_LAT = 0.28; // bike leans into the direction of travel
const LEAN_CURVE = 0.035; // extra lean to hold a bend
const SLIDE_YAW = 0.32; // extra visual yaw while the tyre is scrubbing
const SKID_MARK_LIFE = 6; // seconds a skid mark stays visible
/** Player plus at most nine rival bikes. */
export const MAX_RACE_FIELD = 10;


export interface EngineCallbacks {
  onHud: (h: HudState) => void;
  onGameOver: (r: RunResult) => void;
}

type Phase = 'attract' | 'playing' | 'dying' | 'over';

export class Engine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: EngineCallbacks;
  private bank: SpriteBank;
  private rng: Rng = makeRng(12345);
  private dev = device;

  W = 820;
  H = 460;
  private res = 1;
  private cameraDepth = 1;
  private playerZ = 1;
  private trackLength = TOTAL_SEGMENTS * SEGMENT_LENGTH;
  private segments: Segment[] = [];
  private dirty: Segment[] = [];

  phase: Phase = 'attract';
  paused = false;

  // player
  private position = 0;
  private playerX = 0;
  private speed = 0;
  private lean = 0;
  private bounce = 0;
  /* tyres & suspension */
  private vLat = 0; // lateral velocity, road-widths/sec
  private grip = 1; // 1 = full traction, 0 = sliding
  private slip = 0; // how hard the tyre is scrubbing (0..1)
  private susp = 0; // + front dive under braking, - rear squat under power
  private wheelAngle = 0; // accumulated wheel rotation for the tread scroll
  private wheelSpin = 0; // extra rotation while the tyre is losing traction
  private riderLean = 0; // rider hangs off the bike, lagging the chassis
  private stun = 0;
  private invuln = 0;
  private health = 100;
  private boost = 100;
  private boosting = false;
  private attackTimer = 0;
  private attackCd = 0;
  private attackSide: 1 | -1 = 1;
  private kickTimer = 0;
  private kickCd = 0;
  private kickSide: 1 | -1 = 1;
  /* weapons */
  private weapon: WeaponKind = 'bat';
  private weaponDur = Infinity;
  private swingTime = ATTACK_TIME;
  private kickDone = false;
  /* slow-motion takedown flourish */
  private timeScale = 1;
  private slowmoT = 0;
  private attackHit = false;
  private crashRot = 0;
  private dyingTimer = 0;
  private cause = '';

  // run stats
  private distance = 0;
  private score = 0;
  private takedowns = 0;
  private combo = 0;
  private comboTimer = 0;
  private bestCombo = 0;
  private runTime = 0;
  private wanted = 0;

  // world
  private enemies: Enemy[] = [];
  private traffic: Traffic[] = [];
  private pickups: Pickup[] = [];
  private particles: Particle[] = [];
  private popups: Popup[] = [];
  private enemySeq = 0;
  private spawnEnemyTimer = 1.5;
  private spawnPickupTimer = 6;

  // fx
  private shake = 0;
  private shakeX = 0;
  private shakeY = 0;
  private flash = 0;
  private flashColor = '255,80,60';
  private hitstop = 0;
  private skidding = 0;
  private skidMarks: { z: number; x: number; life: number }[] = [];
  private edgeScrape = 0;
  private skyOffset = 0;
  private bgSlope = 0;
  private speedBlur = 0;
  private time = 0;

  // background geometry (3 parallax mountain ranges + ridge spur offsets + clouds + stars)
  private mountainsFar: number[] = [];
  private mountainsMid: number[] = [];
  private mountainsNear: number[] = [];
  private ridgeSway: number[] = [];
  private clouds: { x: number; y: number; w: number; h: number; speed: number; alpha: number }[] = [];
  private stars: number[][] = [];

  private raf = 0;
  private last = 0;
  private acc = 0;
  private hudTimer = 0;
  private running = false;

  input = { left: false, right: false, up: false, down: false, boost: false };
  touchHints = false;
  autoGas = false;
  /**
   * Set as soon as the player drives with the keyboard. Auto-throttle is a
   * touch-screen convenience only — keyboard riders must hold ↑ / W to move.
   */
  keyboardDriving = false;
  /** True while the throttle is actually applied this frame (for audio/HUD). */
  private throttleOn = false;
  /** Shown when the rider is stationary so new players know what to press. */
  private idleTime = 0;

  /* ---- race start ---- */
  /** True while the field is lined up waiting for the lights. */
  private grid = false;
  private countdown = 0;
  private lastBeep = 99;
  /** Engine revs on the grid (0..1) and time spent bouncing off the limiter. */
  private rev = 0;
  private redline = 0;
  private goFlash = 0;
  private startLineIdx = -1;
  /* ---- race standings ---- */
  private field = 1;
  private racePos = 1;
  private posCandidate = 1;
  private posTimer = 0;
  private overtakes = 0;
  /** Multiplier on steering rate. 0.6 = sluggish, 1.0 = default, 1.8 = twitchy. */
  steerSensitivity = 1;

  constructor(canvas: HTMLCanvasElement, cb: EngineCallbacks) {
    this.canvas = canvas;
    this.cb = cb;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.bank = getSprites();
    this.buildBackground();
    this.resize();
    this.reset(true);
  }

  /* ------------------------------------------------------------ lifecycle */

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }

  /**
   * Build one deferred asset chunk. Routed through the Engine so callers share
   * this module instance — importing the sprite module separately would get a
   * second, independent copy of the build queue. Returns 0..1 (1 = ready).
   */
  stepAssetBuild(): number {
    return stepSpriteBuild();
  }

  assetsPending(): number {
    return spriteBuildPending();
  }

  /** True once every rival livery has streamed in. */
  get assetsReady(): boolean {
    return spriteBuildPending() === 0;
  }

  resize() {
    // CRITICAL: never trust a degenerate rect. Before first layout (and during
    // some mobile orientation changes) getBoundingClientRect() can return 0x0.
    // Writing that back as an inline style permanently hides the canvas, which
    // is exactly the "opens to a blank screen on my phone" failure. The element
    // is sized by CSS (w-full h-full), so we only read it — never write to it.
    const rect = this.canvas.getBoundingClientRect();
    const vw = window.innerWidth || 800;
    const vh = window.innerHeight || 450;
    const cw = rect.width > 2 ? rect.width : vw;
    const ch = rect.height > 2 ? rect.height : vh;

    const dpr = Math.min(this.dev.maxPixelRatio, window.devicePixelRatio || 1);
    const aspect = clamp(cw / ch, 0.4, 3.2);
    let h = clamp(Math.round(Math.sqrt(RENDER_AREA / aspect)), 260, 800);
    let w = Math.round(h * aspect);
    const maxW = this.dev.isMobile ? 760 : 1080;
    if (w > maxW) {
      w = maxW;
      h = Math.round(w / aspect);
    }
    w = Math.max(2, Math.round(w * dpr));
    h = Math.max(2, Math.round(h * dpr));

    if (w === this.W && h === this.H) return; // no-op resizes churn the GPU
    this.W = w;
    this.H = h;
    this.res = h / 460;
    this.canvas.width = w;
    this.canvas.height = h;
    this.ctx.imageSmoothingEnabled = true;
    this.cameraDepth = 1 / Math.tan(((FIELD_OF_VIEW / 2) * Math.PI) / 180);
    this.playerZ = CAMERA_HEIGHT * this.cameraDepth;
  }

  private buildBackground() {
    const rng = makeRng(777);

    // Helper: periodic multi-octave ridged mountain profile (seamless wrap: first === last)
    const makeRange = (count: number, minH: number, maxH: number, sharpness: number, seedOff: number) => {
      const p1 = seedOff * 1.7 + 0.4;
      const p2 = seedOff * 2.9 + 1.3;
      const p3 = seedOff * 4.3 + 2.6;
      const p4 = seedOff * 6.1 + 0.9;
      const out: number[] = [];
      for (let i = 0; i < count; i++) {
        // Periodic angle 0..2π so the last vertex matches vertex 0 seamlessly
        const t = (i / (count - 1)) * Math.PI * 2;
        const m1 = 1 - Math.abs(Math.sin(t * 2 + p1)); // 4 major massifs
        const m2 = 1 - Math.abs(Math.sin(t * 5 + p2)); // 10 secondary peaks
        const m3 = 1 - Math.abs(Math.sin(t * 11 + p3)); // craggy sub-peaks
        const m4 = 0.5 + 0.5 * Math.sin(t * 23 + p4); // rocky ridge teeth
        const raw = Math.pow(clamp(m1 * 0.52 + m2 * 0.28 + m3 * 0.14 + m4 * 0.06, 0, 1), sharpness);
        out.push(lerp(minH, maxH, raw));
      }
      out[count - 1] = out[0];
      return out;
    };

    this.mountainsFar = makeRange(65, 0.18, 1.0, 1.25, 1);
    this.mountainsMid = makeRange(73, 0.14, 0.78, 1.35, 2);
    this.mountainsNear = makeRange(97, 0.1, 0.56, 1.15, 3);

    for (let i = 0; i < 97; i++) {
      this.ridgeSway.push(randRange(rng, -0.35, 0.35));
    }
    for (let i = 0; i < 16; i++) {
      this.clouds.push({
        x: rng(),
        y: randRange(rng, 0.08, 0.44),
        w: randRange(rng, 0.16, 0.36),
        h: randRange(rng, 0.022, 0.055),
        speed: randRange(rng, 0.04, 0.12),
        alpha: randRange(rng, 0.16, 0.38),
      });
    }
    for (let i = 0; i < 90; i++) this.stars.push([rng(), rng() * 0.6, rng() < 0.2 ? 2 : 1]);
  }

  reset(attract: boolean) {
    this.rng = makeRng((Math.random() * 1e9) | 0);
    this.segments = buildTrack(this.rng);
    this.trackLength = this.segments.length * SEGMENT_LENGTH;
    this.position = 0;
    this.playerX = 0;
    this.speed = attract ? MAX_SPEED * 0.55 : 0;
    this.lean = 0;
    this.vLat = 0;
    this.grip = 1;
    this.slip = 0;
    this.susp = 0;
    this.wheelAngle = 0;
    this.wheelSpin = 0;
    this.riderLean = 0;
    this.stun = 0;
    this.invuln = 0;
    this.health = 100;
    this.boost = 100;
    this.boosting = false;
    this.attackTimer = 0;
    this.attackCd = 0;
    this.kickTimer = 0;
    this.kickCd = 0;
    this.weapon = 'bat';
    this.weaponDur = Infinity;
    this.swingTime = ATTACK_TIME;
    this.timeScale = 1;
    this.slowmoT = 0;
    this.crashRot = 0;
    this.dyingTimer = 0;
    this.distance = 0;
    this.score = 0;
    this.takedowns = 0;
    this.combo = 0;
    this.comboTimer = 0;
    this.bestCombo = 0;
    this.runTime = 0;
    this.wanted = 0;
    this.enemies = [];
    this.traffic = [];
    this.pickups = [];
    this.particles.length = 0;
    this.popups.length = 0;
    this.skidMarks.length = 0;
    this.skidding = 0;
    this.edgeScrape = 0;
    this.shake = 0;
    this.flash = 0;
    this.hitstop = 0;
    this.spawnEnemyTimer = attract ? 0.2 : 1.6;
    this.spawnPickupTimer = 8;
    this.phase = attract ? 'attract' : 'playing';
    this.grid = false;
    this.startLineIdx = -1;
    this.field = 1;
    this.racePos = 1;
    this.posCandidate = 1;
    this.posTimer = 0;
    this.overtakes = 0;
    this.goFlash = 0;
    for (let i = 0; i < 8; i++) this.spawnTraffic(true);
    if (attract) for (let i = 0; i < 2; i++) this.spawnEnemy();
  }

  startRun() {
    this.reset(false);
    // Standing start — the bike only moves once the lights go green.
    this.speed = 0;
    this.idleTime = 0;
    this.setupGrid();
    audio.resume();
    audio.start();
  }

  /** Line up at most ten riders (including the player) on a three-wide grid. */
  private setupGrid() {
    const rng = this.rng;
    this.grid = true;
    this.countdown = 3.4; // brief "GET READY", then 3 · 2 · 1 · GO
    this.lastBeep = 99;
    this.rev = 0;
    this.redline = 0;
    this.enemies = [];
    this.playerX = 0;

    const names = ['VIPER', 'NATASHA', 'SLASH', 'RAZOR', 'DUKE', 'MOJO', 'BONES', 'JINX', 'ROXY'];
    for (let i = names.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [names[i], names[j]] = [names[j], names[i]];
    }
    // Five-wide, two-row grid to fill the 6-lane road: nine rivals plus the
    // player (who slots into the middle of the back row) = ten riders total.
    const slots: [number, number][] = [
      [-0.72, 230], [-0.36, 250], [0.36, 250], [0.72, 230],
      [-0.54, 480], [-0.18, 500], [0.18, 500], [0.54, 480],
      [0.0, 760],
    ];
    const pz = this.playerWorldZ();
    slots.slice(0, MAX_RACE_FIELD - 1).forEach(([x, dz], i) => {
      this.spawnEnemy();
      const e = this.enemies[this.enemies.length - 1];
      e.type = 'gang';
      e.racer = true;
      e.name = names[i];
      e.colorIdx = i % 6;
      e.x = x;
      e.side = x < 0 ? -1 : 1;
      e.z = increase(pz, dz, this.trackLength);
      e.dist = dz;
      e.speed = 0;
      e.pace = randRange(rng, 0.8, 0.95);
      e.engage = -3 - rng() * 4;
      e.cooldown = randRange(rng, 2, 4);
      e.health = e.maxHealth = 85 + Math.round(rng() * 25);
      e.weapon = pick(rng, ['bat', 'chain', 'wrench'] as const);
    });
    this.field = Math.min(MAX_RACE_FIELD, slots.length + 1);
    this.racePos = this.posCandidate = Math.min(this.field, 1 + slots.filter(([, dz]) => dz > 0).length);

    // Chequered line just ahead of the front row; push traffic well clear.
    this.startLineIdx = Math.floor((pz + 1100) / SEGMENT_LENGTH);
    for (const t of this.traffic) {
      if (wrapDelta(t.z - pz, this.trackLength) < 16000) t.z = increase(t.z, 16000, this.trackLength);
    }
  }

  /** Grid phase: count down, beep, and let the rider rev for the launch. */
  private updateGrid(dt: number, autoThrottle: boolean) {
    this.countdown -= dt;
    const stage = Math.ceil(this.countdown);
    if (stage <= 3 && stage >= 1 && stage !== this.lastBeep) {
      this.lastBeep = stage;
      audio.countBeep(false);
      haptic.light();
    }
    // Revs climb while ↑ / W is held; sitting on the limiter too long = wheelspin.
    const revving = this.input.up || autoThrottle;
    this.rev = revving ? Math.min(1, this.rev + dt * 2.2) : Math.max(0, this.rev - dt * 2.6);
    this.redline = this.rev >= 1 ? this.redline + dt : Math.max(0, this.redline - dt * 2);
    if (this.rev > 0.3 && this.rng() < dt * this.rev * 26) this.emitSmoke();
    if (this.countdown <= 0) this.launch(autoThrottle);
  }

  private launch(autoThrottle: boolean) {
    this.grid = false;
    this.goFlash = 1;
    audio.countBeep(true);
    haptic.medium();
    // No revs at GO = a true standing start: the bike does not creep forward on
    // its own. It is not a dead end though — launch acceleration is strong and the
    // on-screen prompt tells the rider to open the throttle.
    let launchSpeed = 0;
    let msg = 'FLAT-FOOTED! OPEN THE THROTTLE';
    let col = '#ff6b6b';
    let size = 0.8;

    if (autoThrottle) {
      launchSpeed = MAX_SPEED * 0.34;
      msg = 'GOOD START';
      col = '#8be9ff';
    } else if (this.redline > 1.2) {
      // Pinned on the limiter for ages: the rear tyre spins up. Brief traction
      // loss only — deliberately NOT a stop, and no stun (that scrambled steering).
      launchSpeed = MAX_SPEED * 0.16;
      msg = 'WHEELSPIN!';
      col = '#ff6b6b';
      size = 0.9;
      for (let i = 0; i < 12; i++) this.emitSmoke();
      audio.squeal();
    } else if (this.rev >= 0.75) {
      launchSpeed = MAX_SPEED * 0.48;
      this.score += 500;
      this.boost = 100;
      msg = 'PERFECT START!  +500';
      col = '#8dff6a';
      size = 1;
      this.flashScreen('140,255,120', 0.25);
      this.shake = Math.max(this.shake, 8);
      audio.boost();
      haptic.boost();
    } else if (this.rev >= 0.4) {
      launchSpeed = MAX_SPEED * 0.34;
      msg = 'GOOD START';
      col = '#8be9ff';
    }

    this.speed = launchSpeed;
    this.throttleOn = this.input.up || autoThrottle;
    this.addPopup(msg, col, size);
    for (const e of this.enemies) {
      if (e.racer) e.speed = MAX_SPEED * randRange(this.rng, 0.12, 0.4);
    }
  }

  /** Rank the player against the rest of the field (debounced to avoid flicker). */
  private updateStandings(dt: number) {
    let ahead = 0;
    for (const e of this.enemies) if (e.racer && !e.dnf && e.dist > this.distance) ahead++;
    const pos = 1 + ahead;
    if (pos !== this.posCandidate) {
      this.posCandidate = pos;
      this.posTimer = 0;
      return;
    }
    this.posTimer += dt;
    if (this.posTimer < 0.3 || pos === this.racePos) return;
    const gained = this.racePos - pos;
    this.racePos = pos;
    if (gained > 0) {
      this.overtakes += gained;
      this.score += 150 * gained;
      this.addPopup(pos === 1 ? 'RACE LEADER!  P1' : `UP TO P${pos}!`, pos === 1 ? '#ffd86b' : '#8dff6a', 0.75, this.W / 2, this.H * 0.34);
      audio.nearMiss();
      haptic.light();
    } else {
      this.addPopup(`DROPPED TO P${pos}`, '#ff6b6b', 0.55, this.W / 2, this.H * 0.34);
    }
  }

  toAttract() {
    this.reset(true);
  }

  setPaused(p: boolean) {
    this.paused = p;
    if (p) audio.engine(0, 0, false);
  }

  attack() {
    if (this.phase !== 'playing' || this.paused || this.grid) return;
    if (this.attackTimer > 0 || this.attackCd > 0) return;
    this.swingTime = WEAPONS[this.weapon].swing;
    this.attackTimer = this.swingTime;
    this.attackCd = this.swingTime + 0.08;
    this.attackHit = false;
    // swing towards the steering direction, else towards the closest rival
    let side: 1 | -1 = this.attackSide;
    if (this.input.left) side = -1;
    else if (this.input.right) side = 1;
    else {
      let best = 99;
      for (const e of this.enemies) {
        if (!e.alive || e.state === 'crash') continue;
        const dz = Math.abs(wrapDelta(e.z - this.playerWorldZ(), this.trackLength));
        if (dz < best) {
          best = dz;
          side = e.x >= this.playerX ? 1 : -1;
        }
      }
    }
    this.attackSide = side;
    audio.swing();
  }

  /** Road Rash boot: short reach, big shove, low damage. */
  kick() {
    if (this.phase !== 'playing' || this.paused || this.grid) return;
    if (this.kickTimer > 0 || this.kickCd > 0) return;
    this.kickTimer = KICK_TIME;
    this.kickCd = KICK_TIME + KICK_CD;
    this.kickDone = false;
    let side: 1 | -1 = this.kickSide;
    if (this.input.left) side = -1;
    else if (this.input.right) side = 1;
    else {
      let best = 99;
      for (const e of this.enemies) {
        if (!e.alive || e.state === 'crash') continue;
        const d = Math.abs(wrapDelta(e.z - this.playerWorldZ(), this.trackLength));
        if (d < best) {
          best = d;
          side = e.x >= this.playerX ? 1 : -1;
        }
      }
    }
    this.kickSide = side;
    audio.scrape();
    haptic.light();
  }

  /** Swap to a weapon found on the road. */
  private equipWeapon(kind: WeaponKind) {
    this.weapon = kind;
    this.weaponDur = WEAPON_DURABILITY[kind];
    this.swingTime = WEAPONS[kind].swing;
  }

  /**
   * Tyre physics. Steering demand is converted into lateral velocity through a
   * grip budget: ask for more than the tyre can give and traction breaks, the
   * bike slides wide and smokes, and grip only returns once you ease off.
   */
  private applyTyres(dt: number, steerInput: number, authority: number, speedPct: number, curve: number) {
    const maxLat = MAX_LAT_VEL * authority * this.steerSensitivity;
    const curveLoad = (Math.abs(curve) / CURVE_NORMALISE) * speedPct * CURVE_GRIP_LOAD * maxLat;
    const demand = Math.abs(steerInput) * maxLat * (1 + speedPct * SPEED_OVERDEMAND) + curveLoad;
    const cap = this.grip * maxLat;

    const over = demand - cap;
    if (over > 0.01 && Math.abs(steerInput) > 0.05) {
      // Normalised: over-demand bleeds grip gradually for powerslide feedback.
      this.grip = Math.max(0.14, this.grip - (over / Math.max(0.001, maxLat)) * dt * GRIP_LOSS);
    } else {
      // Recovers quickly once you ease off or straighten up.
      this.grip = Math.min(1, this.grip + dt * GRIP_RECOVER * (Math.abs(steerInput) < 0.25 ? 1.8 : 1));
    }
    this.slip = Math.abs(steerInput) > 0.05 ? clamp(over / Math.max(0.001, maxLat), 0, 1) : 0;

    // Apex turn-in assist: leaning into a curve (steerInput * curve > 0) helps the
    // bike carve smoothly around the bend. Even while powersliding at low grip,
    // steering retains >= 88% authority so corners never feel locked or stiff.
    const intoCorner = steerInput * curve > 0 ? 1 + Math.min(0.24, Math.abs(curve) / 24) : 1;
    const tractionFactor = 0.88 + 0.12 * this.grip;
    const targetLat = steerInput * maxLat * tractionFactor * intoCorner;

    // Crisp turn-in when steering, and fast self-centering when key is released
    const resp = Math.abs(steerInput) > 0.05 ? LAT_RESPONSE : LAT_RESPONSE * 1.3;
    this.vLat += (targetLat - this.vLat) * Math.min(1, dt * resp);

    // Gentle, predictable outward drift on curves (easily overpowered by steering)
    const curveDrift = speedPct * speedPct * curve * CENTRIFUGAL;
    this.vLat = clamp(this.vLat, -MAX_LAT_VEL * 1.6, MAX_LAT_VEL * 1.6);
    this.playerX += (this.vLat - curveDrift) * dt;

    // Smooth continuous lean into the corner, with powerslide yaw when scrubbing
    const slideYaw = this.slip * SLIDE_YAW * Math.sign(steerInput || this.vLat || 1);
    const leanTarget = clamp(
      this.vLat * LEAN_PER_LAT + curve * speedPct * LEAN_CURVE + slideYaw,
      -LEAN_MAX,
      LEAN_MAX,
    );
    this.lean += (leanTarget - this.lean) * Math.min(1, dt * 11);
  }

  /** Suspension travel, road chatter and wheel rotation. */
  private updateChassis(dt: number, speedPct: number, offroad: boolean) {
    const braking = this.phase === 'playing' && this.input.down;
    const suspTarget = braking ? 0.8 : this.throttleOn ? -0.55 : 0;
    this.susp += (suspTarget - this.susp) * Math.min(1, dt * 7.5);

    // Road chatter: gentle on tarmac, violent on the shoulder.
    const chatter = (offroad ? 2.7 : 0.75) * speedPct;
    this.bounce = (Math.sin(this.time * 34) + Math.sin(this.time * 51)) * chatter * this.res;

    // Wheels follow ground speed; spin up hard when traction is broken.
    this.wheelAngle += (this.speed / 260) * dt + this.wheelSpin * dt;
    this.wheelSpin = Math.max(0, this.wheelSpin - dt * 7);
    if (this.slip > 0.22 || (this.boosting && speedPct < 0.55) || this.grid) {
      this.wheelSpin = Math.max(this.wheelSpin, this.grid ? this.rev * 16 : 8 + this.slip * 26);
    }
    if (this.wheelAngle > 1e6) this.wheelAngle = 0;

    // Scrubbing rubber throws smoke off the rear tyre.
    if (this.slip > 0.3 && speedPct > 0.2 && this.rng() < dt * this.slip * 55) {
      this.spawnParticle(
        this.W / 2 - Math.sign(this.vLat || 1) * 12 * this.res,
        this.H * 0.88,
        randRange(this.rng, -70, 70) - this.vLat * 55,
        randRange(this.rng, -150, -50),
        0.5,
        'rgba(215,215,225,0.7)',
        'smoke',
      );
    }
  }

  private playerWorldZ() {
    return increase(this.position, this.playerZ, this.trackLength);
  }

  /* ---------------------------------------------------------------- loop */

  private loop = (ts: number) => {
    if (!this.running) return;
    this.raf = requestAnimationFrame(this.loop);
    let dt = (ts - this.last) / 1000;
    this.last = ts;
    if (dt > 0.1) dt = 0.1;
    if (!this.paused) {
      if (this.slowmoT > 0) {
        this.slowmoT -= dt;
        if (this.slowmoT <= 0) this.timeScale = 1;
      }
      const sdt = dt * this.timeScale;
      if (this.hitstop > 0) {
        this.hitstop -= dt;
      } else {
        this.acc += sdt;
        let steps = 0;
        while (this.acc >= 1 / 120 && steps < 8) {
          this.update(1 / 120);
          this.acc -= 1 / 120;
          steps++;
        }
        if (steps >= 8) this.acc = 0;
      }
      this.time += sdt;
    }
    this.render();
  };

  /* -------------------------------------------------------------- update */

  private update(dt: number) {
    const playing = this.phase === 'playing';
    const attract = this.phase === 'attract';
    const dying = this.phase === 'dying';

    const autoThrottleOn = this.autoGas && this.touchHints && !this.keyboardDriving && playing;
    if (playing && this.grid) this.updateGrid(dt, autoThrottleOn);
    // read AFTER updateGrid so the launch frame isn't clamped back to 0 kph
    const grid = playing && this.grid;
    if (playing && !grid) this.runTime += dt;
    if (this.goFlash > 0) this.goFlash = Math.max(0, this.goFlash - dt);

    const playerSeg = findSegment(this.segments, this.playerWorldZ());
    const speedPct = this.speed / MAX_SPEED;

    /* ---- input / steering */
    let steerInput = 0;
    if (attract) {
      // autopilot cruise for the title screen
      const target = Math.sin(this.time * 0.6) * 0.45 - playerSeg.curve * 0.08;
      steerInput = clamp((target - this.playerX) * 2.2, -1, 1);
      this.speed += (MAX_SPEED * 0.62 - this.speed) * dt * 0.8;
    } else if (playing && !grid) {
      if (this.input.left) steerInput -= 1;
      if (this.input.right) steerInput += 1;
      if (this.stun > 0) steerInput = steerInput * 0.35 + Math.sin(this.time * 24) * 0.55;
    } else if (dying) {
      steerInput = this.crashRot > 0 ? 0.35 : -0.35;
    } else {
      // game over: drift the wreck back towards the tarmac for a nicer backdrop
      this.playerX += (clamp(this.playerX, -0.6, 0.6) - this.playerX) * Math.min(1, dt * 0.8);
    }

    // Steering needs forward motion: a stationary bike can't slide sideways.
    // Ramps from 0 at standstill to full authority by ~35% speed.
    // Minimum 15% steering even at a crawl, ramping to full authority by ~28% speed.
    // This removes the "stuck in mud" feeling when pulling away from the grid.
    const steerAuthority = dying ? Math.max(0.25, speedPct) : clamp(0.15 + speedPct / 0.28, 0, 1);
    this.applyTyres(dt, steerInput, steerAuthority, speedPct, playerSeg.curve);

    // soft wall: the deep weeds shove you back towards the road
    if (Math.abs(this.playerX) > 1.2) {
      this.playerX -= Math.sign(this.playerX) * (Math.abs(this.playerX) - 1.2) * Math.min(1, dt * 9);
    }
    this.playerX = clamp(this.playerX, -1.5, 1.5);

    // Rider hangs off the inside of the corner, trailing the chassis slightly.
    const hangTarget = clamp(this.lean * 1.25, -0.62, 0.62);
    this.riderLean += (hangTarget - this.riderLean) * Math.min(1, dt * 7.5);

    /* ---- skidding: hard brake at speed, or violent turns */
    const hardBrake = playing && this.input.down && this.speed > MAX_SPEED * 0.4;
    const hardTurn = playing && this.slip > 0.34 && speedPct > 0.35;
    if (hardBrake || hardTurn) {
      this.skidding = Math.min(1, this.skidding + dt * 6);
      this.laySkidMark();
      if (hardBrake && this.rng() < dt * 60) this.emitSmoke();
      if (this.skidding > 0.7 && this.rng() < dt * 8) haptic.light();
    } else {
      this.skidding = Math.max(0, this.skidding - dt * 4);
    }

    /* ---- scraping the road edge throws sparks */
    if (playing && Math.abs(this.playerX) > 1.0 && Math.abs(this.playerX) < 1.25 && speedPct > 0.2) {
      this.edgeScrape += dt;
      this.shake = Math.max(this.shake, 2.4);
      if (this.rng() < dt * 45) {
        const side = this.playerX > 0 ? 1 : -1;
        this.spawnParticle(
          this.W / 2 + side * 26 * this.res,
          this.H * 0.83,
          randRange(this.rng, -180, 180) - side * 220,
          randRange(this.rng, -320, -80),
          0.32,
          this.rng() < 0.5 ? '#ffd86b' : '#ff9b3d',
          'spark',
        );
      }
      if (this.rng() < dt * 4) audio.scrape();
    } else {
      this.edgeScrape = 0;
    }

    /* ---- throttle */
    const offroad = Math.abs(this.playerX) > 1.02;
    const coasting = dying || this.phase === 'over';
    if (grid) {
      // Lined up on the grid: clutch in, front brake on — revs only.
      this.speed = 0;
      this.boosting = false;
      this.throttleOn = this.input.up || autoThrottleOn;
    } else if (!coasting) {
      // Braking ALWAYS wins — otherwise auto-throttle made the brake a no-op.
      const braking = playing && this.input.down;
      // Auto-throttle only for touch riders; keyboard riders must hold ↑ / W.
      const autoThrottle = this.autoGas && this.touchHints && !this.keyboardDriving && playing;
      const wantGas = !braking && (attract || this.input.up || autoThrottle);
      this.throttleOn = wantGas;
      this.boosting =
        playing && !braking && this.input.boost && this.boost > 0 && this.speed > MAX_SPEED * 0.25;

      if (braking) {
        // brakes + air drag together
        this.speed += (BRAKING - this.speed * AIR_DRAG) * dt;
        this.boost = Math.min(100, this.boost + dt * 6);
      } else if (this.boosting) {
        this.boost = Math.max(0, this.boost - dt * 34);
        this.speed += BOOST_ACCEL * dt;
        if (this.rng() < dt * 40) this.emitExhaust();
        if (this.rng() < dt * 3) haptic.light();
      } else if (wantGas) {
        // Strong off-the-line punch, blending into normal acceleration.
        const band = clamp(this.speed / LAUNCH_BAND, 0, 1);
        this.speed += lerp(LAUNCH_ACCEL, ACCEL, band) * dt * (this.stun > 0 ? 0.3 : 1);
        this.boost = Math.min(100, this.boost + dt * 4.5);
      } else {
        // Off the throttle: engine braking + rolling resistance + air drag.
        // From top speed this rolls to a stop in roughly 3 seconds.
        this.speed += (COAST_DECEL - this.speed * AIR_DRAG) * dt;
        this.boost = Math.min(100, this.boost + dt * 6);
      }
      // No creeping: once nearly stopped with no throttle, come to rest.
      if (!wantGas && !this.boosting && this.speed < STOP_SNAP) this.speed = 0;
      if (offroad && this.speed > OFFROAD_LIMIT) this.speed += OFFROAD_DECEL * dt;
      const maxNow = MAX_SPEED * (this.boosting ? 1.22 : 1);
      this.speed = clamp(this.speed, 0, maxNow);
    } else {
      this.speed += BRAKING * 1.1 * dt;
      this.speed = Math.max(0, this.speed);
    }

    this.position = increase(this.position, this.speed * dt, this.trackLength);
    if (playing || attract) this.distance += this.speed * dt;
    if (playing) {
      this.score += (this.speed * dt) / 100;
      const heat = clamp(Math.floor(this.distance / 100 / 650), 0, 5);
      if (heat > this.wanted) {
        this.wanted = heat;
        this.addPopup(heat >= 2 ? 'HEAT ' + heat + ' \u2605 COPS INBOUND' : 'HEAT ' + heat + ' \u2605', '#ff5a4d', 0.85);
        this.flashScreen('255,80,60', 0.2);
        audio.ui();
      }
    }

    /* ---- idle tracking (for the "hold throttle" prompt) */
    if (playing && !grid && this.speed < MAX_SPEED * 0.02) this.idleTime += dt;
    else this.idleTime = 0;

    /* ---- skid mark decay */
    for (let i = this.skidMarks.length - 1; i >= 0; i--) {
      this.skidMarks[i].life -= dt;
      if (this.skidMarks[i].life <= 0) this.skidMarks.splice(i, 1);
    }

    /* ---- timers */
    if (this.stun > 0) this.stun -= dt;
    if (this.invuln > 0) this.invuln -= dt;
    if (this.attackCd > 0) this.attackCd -= dt;
    if (this.kickCd > 0) this.kickCd -= dt;
    if (this.kickTimer > 0) {
      this.kickTimer -= dt;
      const kp = 1 - this.kickTimer / KICK_TIME;
      if (kp > 0.2 && kp < 0.7 && !this.kickDone) {
        this.kickDone = true;
        this.checkKickHits();
      }
    }
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) this.combo = 0;
    }
    this.shake = Math.max(0, this.shake - dt * 42);
    this.flash = Math.max(0, this.flash - dt * 5.5);
    this.updateChassis(dt, speedPct, offroad);
    if (grid) this.bounce += Math.sin(this.time * 70) * this.rev * 1.6 * this.res;
    this.speedBlur = lerp(this.speedBlur, this.boosting ? 1 : Math.max(0, speedPct - 0.55) / 0.45, dt * 5);
    if (offroad && this.speed > MAX_SPEED * 0.12) {
      this.shake = Math.max(this.shake, 2.2 * speedPct);
      if (this.rng() < dt * 50) this.emitDust();
    }

    /* ---- attack swing */
    if (this.attackTimer > 0) {
      this.attackTimer -= dt;
      const p = 1 - this.attackTimer / this.swingTime;
      if (!this.attackHit && p > 0.22 && p < 0.66) this.checkMeleeHits();
    }

    /* ---- world */
    if (!grid) this.updateTraffic(dt);
    this.updateEnemies(dt);
    this.updatePickups(dt);
    if (playing && !grid) this.updateStandings(dt);
    if (playing && !grid) {
      this.collideScenery(playerSeg);
      this.collideTraffic(dt);
    }
    this.updateParticles(dt);
    this.updatePopups(dt);

    /* ---- spawners */
    this.spawnEnemyTimer -= dt;
    const wantEnemies = attract ? 3 : 1 + Math.floor(this.wanted / 2);
    let roaming = 0;
    let cops = 0;
    for (const e of this.enemies) {
      if (!e.racer) roaming++;
      if (e.type === 'cop') cops++;
    }
    const canSpawn = attract || (playing && !grid && this.runTime > 8);
    // Count racers and roaming combat bikes together; never exceed nine AI bikes
    // plus the player on screen. At the start all nine slots are race rivals.
    const aiBikeLimit = attract ? 3 : MAX_RACE_FIELD - 1;
    // Cops chase harder at higher wanted: spawn faster, more of them.
    const wantedHeat = Math.max(0, this.wanted - 1);
    if (canSpawn && this.enemies.length < aiBikeLimit && roaming < wantEnemies) {
      this.spawnEnemy();
      this.spawnEnemyTimer = randRange(this.rng, 1.4 - wantedHeat * 0.25, 3.2 - wantedHeat * 0.4);
    }
    const wantTraffic = 7 + Math.min(6, Math.floor(this.distance / 100 / 900));
    while (this.traffic.length < wantTraffic) this.spawnTraffic(false);
    this.spawnPickupTimer -= dt;
    if (this.spawnPickupTimer <= 0 && this.pickups.length < 2 && !attract) {
      this.spawnPickup();
      this.spawnPickupTimer = randRange(this.rng, 7, 13);
    }

    /* ---- death */
    if (dying) {
      this.dyingTimer -= dt;
      this.crashRot += dt * (this.crashRot >= 0 ? 7 : -7);
      if (this.rng() < dt * 30) this.emitDebris(this.W / 2, this.H * 0.78, '#d8502a');
      if (this.dyingTimer <= 0) {
        this.phase = 'over';
        this.cb.onGameOver({
          score: Math.floor(this.score),
          distance: Math.floor(this.distance / 100),
          takedowns: this.takedowns,
          bestCombo: this.bestCombo,
          time: this.runTime,
          cause: this.cause,
          position: this.racePos,
          field: this.field,
          overtakes: this.overtakes,
        });
      }
    }

    /* ---- audio + hud (throttled) */
    this.hudTimer -= dt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.05;
      audio.engine(grid ? Math.max(speedPct, this.rev * 0.8) : speedPct, this.throttleOn ? 1 : 0, this.phase !== 'over');
      let cops = 0;
      for (const e of this.enemies) if (e.type === 'cop' && e.state !== 'crash') cops++;
      audio.siren(playing && cops > 0 ? 1 : 0);
      this.cb.onHud({
        speedKph: Math.round(this.speed * 0.036),
        speedPct,
        health: Math.max(0, Math.round(this.health)),
        score: Math.floor(this.score),
        distance: Math.floor(this.distance / 100),
        takedowns: this.takedowns,
        combo: this.combo,
        boost: this.boost,
        wanted: this.wanted,
        offroad,
        position: this.racePos,
        field: this.field,
        countdown: grid ? Math.max(0, this.countdown) : -1,
        cops: cops,
        weapon: WEAPONS[this.weapon].name,
        weaponPower: Math.round(WEAPONS[this.weapon].power * 100),
        grip: this.grip,
      });
    }
  }

  /* ------------------------------------------------------------- spawning */

  private spawnTraffic(initial: boolean) {
    const rng = this.rng;
    const oncoming = rng() < 0.33;
    const body = pick(rng, ['car', 'car', 'car', 'van', 'truck'] as const);
    const z = increase(
      this.playerWorldZ(),
      initial ? randRange(rng, 6000, 40000) : randRange(rng, 30000, 58000),
      this.trackLength,
    );
    this.traffic.push({
      kind: 'traffic',
      z,
      x: oncoming ? randRange(rng, -0.82, -0.28) : randRange(rng, -0.1, 0.78),
      speed: MAX_SPEED * (oncoming ? randRange(rng, 0.3, 0.45) : randRange(rng, 0.26, 0.52)),
      dir: oncoming ? -1 : 1,
      body,
      colorIdx: Math.floor(rng() * 6),
      drift: randRange(rng, -0.04, 0.04),
      alive: true,
      passed: false,
    });
  }

  private spawnEnemy() {
    const rng = this.rng;
    // Cops escalate gradually: none until heat 1, then a rising chance that
    // tops out so a 5-star chase averages one new officer every few seconds
    // (capped at MAX_COPS live at any time).
    const copChance = this.wanted >= 1 ? 0.12 + this.wanted * 0.14 : 0;
    // Hard cap of four pursuit officers: enough to be a real threat, never a
    // wall of blue that makes the road unplayable.
    const MAX_COPS = 4;
    let liveCops = 0;
    for (const o of this.enemies) if (o.type === 'cop' && !o.dnf) liveCops++;
    const isCop = liveCops < MAX_COPS && rng() < copChance;
    const health = isCop ? 115 : 90 + this.wanted * 8;
    // Cops chasing with heat spawn BEHIND the player so they hunt from behind.
    // Use raw addition (no wrap-around) so that spawning behind the player near
    // the start of the track doesn't wrap to the end of the track.
const spawnOffset = isCop && this.wanted > 0
      ? randRange(rng, -300, -100)
      : randRange(rng, 1800, 5200);
    const spawnZ = this.playerWorldZ() + spawnOffset;
    const z = spawnZ < 0 ? 0 : spawnZ >= this.trackLength ? spawnZ - this.trackLength : spawnZ;
    this.enemies.push({
      kind: 'enemy',
      id: ++this.enemySeq,
      type: isCop ? 'cop' : 'gang',
      colorIdx: Math.floor(rng() * 6),
      z,
      x: randRange(rng, -0.75, 0.75),
      vx: 0,
      speed: isCop && this.wanted > 0
        ? MAX_SPEED * 0.9
        : this.speed * 0.95 + MAX_SPEED * 0.05,
      health,
      maxHealth: health,
      state: 'ride',
      timer: 0,
      cooldown: randRange(rng, 1, 2.4),
      side: rng() < 0.5 ? -1 : 1,
      hitFlash: 0,
      lean: 0,
      punchSide: 1,
      crashRot: 0,
      crashTime: 0,
      bob: rng() * 6,
      aggression: 0.75 + this.wanted * 0.12 + rng() * 0.3,
      racer: false,
      dnf: false,
      name: '',
      taunt: '',
      tauntT: 0,
      weapon: 'bat',
      vLat: 0,
      grip: 1,
      slip: 0,
      susp: 0,
      wheel: rng() * 6,
      hang: 0,
      dist: 0,
      pace: 0,
      engage: 0,
      alive: true,
    });
  }

  private spawnPickup() {
    const rng = this.rng;
    this.pickups.push({
      kind: 'pickup',
      type: this.health < 65 ? 'repair' : rng() < 0.34 ? 'weapon' : 'nitro',
      weapon: pick(rng, ['chain', 'wrench'] as const),
      z: increase(this.playerWorldZ(), randRange(rng, 9000, 20000), this.trackLength),
      x: randRange(rng, -0.7, 0.7),
      phase: rng() * 6,
      alive: true,
    });
  }

  /* --------------------------------------------------------------- world */

  private updateTraffic(dt: number) {
    const pz = this.playerWorldZ();
    for (const t of this.traffic) {
      t.z = increase(t.z, t.speed * t.dir * dt, this.trackLength);
      t.x = clamp(t.x + t.drift * dt, -0.88, 0.88);
      if (Math.abs(t.x) > 0.85) t.drift *= -1;
      const dz = wrapDelta(t.z - pz, this.trackLength);
      if (dz < -2600 || dz > 60000) {
        t.alive = false;
      }
      // near miss bonus
      if (this.phase === 'playing' && !t.passed && dz < 0 && dz > -600) {
        t.passed = true;
        const gap = Math.abs(t.x - this.playerX);
        if (gap < 0.42 && this.speed > MAX_SPEED * 0.45) {
          this.addCombo();
          this.score += 40 * this.combo;
          this.addPopup('CLOSE CALL!', '#8be9ff', 0.6);
          audio.nearMiss();
          haptic.light();
        }
      }
    }
    this.traffic = this.traffic.filter((t) => t.alive);
  }

  private updateEnemies(dt: number) {
    const pz = this.playerWorldZ();
    for (const e of this.enemies) {
      if (e.hitFlash > 0) e.hitFlash -= dt;
      if (e.tauntT > 0) e.tauntT -= dt;
      if (e.state === 'crash') {
        e.crashTime += dt;
        e.crashRot += dt * 9 * Math.sign(e.vx || 1);
        e.x += e.vx * dt;
        e.vx *= 1 - Math.min(0.9, dt * 1.4);
        e.speed *= 1 - Math.min(0.9, dt * 1.1);
        e.z = increase(e.z, e.speed * dt, this.trackLength);
        e.dist += e.speed * dt;
        if (e.crashTime > 2.4) {
          if (e.racer && !e.dnf) {
            // Road Rash rules: dust yourself off and get back on the bike.
            e.state = 'ride';
            e.crashRot = 0;
            e.crashTime = 0;
            e.vx = 0;
            e.x = clamp(e.x, -0.8, 0.8);
            e.speed = 0;
            e.health = Math.max(e.health, e.maxHealth * 0.5);
            e.cooldown = 2;
          } else {
            e.alive = false;
          }
        }
        continue;
      }

      // Racers sit frozen on the grid until the lights go green.
      if (e.racer && this.grid) {
        e.lean = 0;
        continue;
      }

      const dz = wrapDelta(e.z - pz, this.trackLength);
      const dxp = e.x - this.playerX;
      const rel = e.racer ? e.dist - this.distance : dz; // + = ahead of player
      const near = Math.abs(rel) < 1600;

      // COPS hunt anyone breaking the law: the player at heat, and gang racers
      // always (they are an outlaw bike club). Pick the closest target each frame.
      let copTarget: Enemy | null = null;
      if (e.type === 'cop' && this.phase === 'playing') {
        let best = Infinity;
        for (const o of this.enemies) {
          if (o === e || !o.alive || o.state === 'crash') continue;
          const isPlayer = false;
          const dzO = wrapDelta(o.z - e.z, this.trackLength);
          const d = Math.abs(dzO);
          // Gang racers are always fair game; the player only when wanted.
          if (o.racer && o.type === 'gang' && d < 14000) {
            if (d < best) {
              best = d;
              copTarget = o;
            }
          }
          void isPlayer;
        }
        // The player is always a valid target at heat, and takes priority when close.
        if (this.wanted > 0) {
          const dzP = wrapDelta(pz - e.z, this.trackLength);
          if (Math.abs(dzP) < 14000 && Math.abs(dzP) < best) copTarget = null; // null => chase player
        }
      }
      // Chasing the player (copTarget === null at heat) or a gang racer?
      const isCopChase = e.type === 'cop' && this.phase === 'playing' && (this.wanted > 0 || copTarget !== null);
      const chaseX = copTarget ? copTarget.x : this.playerX;
      const chaseZ = copTarget ? copTarget.z : pz;

      // lateral behaviour
      let targetX = this.playerX + e.side * 0.42;
      if (this.phase === 'attract') targetX = e.side * 0.5;
      if (isCopChase) {
        // Cops drive straight at whoever they are hunting.
        targetX = chaseX;
      } else if (e.racer && (!near || e.engage <= 0)) {
        // own racing line, with a gentle weave so the pack looks alive
        targetX = e.side * 0.48 + Math.sin(this.time * 0.5 + e.id * 1.7) * 0.18;
      }
      // avoid traffic in front of them
      for (const t of this.traffic) {
        const tdz = wrapDelta(t.z - e.z, this.trackLength);
        const lead = t.dir === -1 ? 11000 : 5200;
        if (tdz > 0 && tdz < lead && Math.abs(t.x - e.x) < 0.5) targetX = t.x + (t.x > e.x ? -0.95 : 0.95);
      }
      if (Math.abs(e.x) > 1) targetX = clamp(targetX, -0.75, 0.75);
      targetX = clamp(targetX, -0.92, 0.92);
      // Rivals ride on the same tyre model: they build lateral velocity, can
      // break traction, and lean into whatever line they are taking.
      const reach = e.state === 'stun' ? 1.6 : 3.6;
      const latTarget = clamp((targetX - e.x) * reach, -MAX_LAT_VEL, MAX_LAT_VEL);
      const cap = e.grip * MAX_LAT_VEL;
      e.vLat += (clamp(latTarget, -cap, cap) - e.vLat) * Math.min(1, dt * LAT_RESPONSE);
      const overE = Math.abs(latTarget) - cap;
      e.grip =
        overE > 0.01
          ? Math.max(0.22, e.grip - overE * dt * GRIP_LOSS * 0.65)
          : Math.min(1, e.grip + dt * GRIP_RECOVER * 1.25);
      e.slip = clamp(overE / MAX_LAT_VEL, 0, 1);
      e.x += e.vLat * dt + e.vx * dt;
      e.vx *= 1 - Math.min(0.95, dt * 3.2);
      e.x = clamp(e.x, -1.5, 1.5);

      const eCurve = findSegment(this.segments, e.z).curve;
      const eLean = clamp(
        e.vLat * LEAN_PER_LAT + eCurve * LEAN_CURVE + e.slip * SLIDE_YAW * Math.sign(e.vLat || 1),
        -LEAN_MAX,
        LEAN_MAX,
      );
      e.lean += (eLean - e.lean) * Math.min(1, dt * 8);
      e.hang += (clamp(e.lean * 1.2, -0.6, 0.6) - e.hang) * Math.min(1, dt * 6.5);
      e.susp += ((e.speed > this.speed * 1.02 ? -0.5 : 0.1) - e.susp) * Math.min(1, dt * 6);
      e.wheel += (e.speed / 260) * dt + e.slip * dt * 16;

      // longitudinal: hold station near the player
      let want;
      if (isCopChase) {
        // COPS CHASE: relentless pursuit of their target, no rubber-banding.
        // Speed scales with heat so a 5-star chase is genuinely dangerous.
        const chaseBonus = 1.15 + this.wanted * 0.05;
        const targetSpeed = copTarget ? copTarget.speed : this.speed;
        want = clamp(targetSpeed * chaseBonus, MAX_SPEED * 0.6, MAX_SPEED * 1.35);
        // If they're way ahead of their target, ease off rather than drive off into
        // the distance — they should circle back into the fight.
        const dzTarget = wrapDelta(chaseZ - e.z, this.trackLength);
        if (dzTarget < -4000) want *= 0.5;
      } else {
        const gap = e.state === 'wind' || e.state === 'punch' ? 40 : 110 + Math.sin(this.time * 0.7 + e.id) * 210;
        const err = clamp((gap - dz) * 1.1, -MAX_SPEED * 0.35, MAX_SPEED * 0.4);
        const ref = Math.max(this.speed, MAX_SPEED * 0.42);
        want = clamp(ref + err, MAX_SPEED * 0.2, MAX_SPEED * 1.25);
      }
      if (e.racer && !isCopChase) {
        e.engage -= dt;
        // Alongside the player? Sometimes pick a fight for a few seconds.
        if (e.engage < -3 && Math.abs(rel) < 700 && this.phase === 'playing' && this.rng() < dt * 0.9 * e.aggression) {
          e.engage = randRange(this.rng, 2.5, 5.5);
        }
        if (!(e.engage > 0 && near)) {
          // Race pace, rubber-banded so the field stays together.
          let pace = e.pace * MAX_SPEED;
          if (rel > 3500) pace *= 1 - Math.min(0.22, (rel - 3500) / 30000);
          else if (rel < -2500) pace *= 1 + Math.min(0.12, (-rel - 2500) / 25000);
          // Never faster than a flat-out player: the race must be winnable.
          want = Math.min(pace, MAX_SPEED * 0.97);
        }
      }
      e.speed += (want - e.speed) * Math.min(1, dt * 1.6);
      if (e.state === 'stun') e.speed *= 1 - Math.min(0.8, dt * 0.9);
      e.z = increase(e.z, e.speed * dt, this.trackLength);
      e.dist += e.speed * dt;

      // state machine
      e.timer -= dt;
      e.cooldown -= dt;
      if (e.state === 'stun' && e.timer <= 0) e.state = 'ride';
      if (e.state === 'wind' && e.timer <= 0) {
        e.state = 'punch';
        e.timer = 0.22;
        if (e.tauntT <= 0) {
          e.taunt = pick(this.rng, TAUNTS);
          e.tauntT = 1.15;
        }
        if (this.phase === 'playing' && Math.abs(dz) < 420 && Math.abs(dxp) < 0.92 && this.invuln <= 0) {
          this.damagePlayer(5 + this.wanted, 'punch');
          this.playerX -= Math.sign(dxp || 1) * 0.12;
          this.addPopup('OUCH!', '#ff6b6b', 0.5);
          haptic.heavy();
        }
      } else if (e.state === 'punch' && e.timer <= 0) {
        e.state = 'ride';
        // Cops punch faster when chasing
        const punchCd = isCopChase ? randRange(this.rng, 0.6, 1.4) : randRange(this.rng, 1.1, 2.3);
        e.cooldown = punchCd / e.aggression;
      } else if (
        e.state === 'ride' &&
        e.cooldown <= 0 &&
        this.phase === 'playing' &&
        Math.abs(dz) < (isCopChase ? 460 : 320) &&
        Math.abs(dxp) < (isCopChase ? 1.1 : 0.8)
      ) {
        e.state = 'wind';
        e.timer = 0.3;
        e.punchSide = dxp > 0 ? -1 : 1;
      }

      // body check: enemies shove the player when touching
      if (this.phase === 'playing' && Math.abs(dz) < 240 && Math.abs(dxp) < 0.26) {
        const push = dt * 1.4;
        this.playerX -= Math.sign(dxp || 1) * push;
        e.x += Math.sign(dxp || 1) * push;
      }

      // enemies eat traffic too
      for (const t of this.traffic) {
        if (Math.abs(wrapDelta(t.z - e.z, this.trackLength)) < 260 && Math.abs(t.x - e.x) < 0.3) {
          this.crashEnemy(e, false);
          break;
        }
      }
      if (Math.abs(e.x) > 1.42 && this.rng() < dt * 1.5) this.crashEnemy(e, false);
      // Cops hunting don't despawn when far behind; only non-racers despawn when far ahead
      if (!e.racer && !isCopChase && dz > 30000) e.alive = false;
    }
    this.enemies = this.enemies.filter((e) => e.alive);
  }

  private updatePickups(dt: number) {
    const pz = this.playerWorldZ();
    for (const p of this.pickups) {
      p.phase += dt * 4;
      const dz = wrapDelta(p.z - pz, this.trackLength);
      if (dz < -800) p.alive = false;
      if (this.phase === 'playing' && Math.abs(dz) < 260 && Math.abs(p.x - this.playerX) < 0.33) {
        p.alive = false;
        if (p.type === 'repair') {
          this.health = Math.min(100, this.health + 28);
          this.addPopup('+28 ARMOR', '#5cff9d', 0.8);
        } else if (p.type === 'weapon') {
          this.equipWeapon(p.weapon);
          this.addPopup(WEAPONS[p.weapon].name + ' EQUIPPED', WEAPONS[p.weapon].color, 0.85, this.W / 2, this.H * 0.42);
          this.flashScreen('180,220,255', 0.2);
        } else {
          this.boost = Math.min(100, this.boost + 55);
          this.addPopup('+NITRO', '#8be9ff', 0.8);
        }
        this.flashScreen('120,255,180', 0.22);
        audio.pickup();
        haptic.pickup();
        for (let i = 0; i < 14; i++)
          this.spawnParticle(this.W / 2, this.H * 0.72, randRange(this.rng, -200, 200), randRange(this.rng, -280, -40), 0.5, p.type === 'repair' ? '#5cff9d' : p.type === 'weapon' ? '#d6dde8' : '#8be9ff', 'spark');
      }
    }
    this.pickups = this.pickups.filter((p) => p.alive);
  }

  /* ------------------------------------------------------------- combat */

  private checkMeleeHits() {
    const pz = this.playerWorldZ();
    for (const e of this.enemies) {
      if (!e.alive || e.state === 'crash') continue;
      const dz = wrapDelta(e.z - pz, this.trackLength);
      const dxp = e.x - this.playerX;
      const wpReach = WEAPONS[this.weapon].reach;
      if (dz < -360 * wpReach || dz > 620 * wpReach) continue;
      if (Math.abs(dxp) > 1.05) continue;
      if (dxp * this.attackSide < -0.12) continue;
      this.attackHit = true;
      const wp = WEAPONS[this.weapon];
      const dmg = (26 + (this.speed / MAX_SPEED) * 16 + (this.boosting ? 12 : 0)) * wp.power;
      e.health -= dmg;
      e.hitFlash = 0.22;
      e.vx += this.attackSide * 3.4 * wp.knock;
      // weapons wear out, then you are back to the nightstick
      if (this.weaponDur !== Infinity) {
        this.weaponDur--;
        if (this.weaponDur <= 0) {
          this.equipWeapon('bat');
          this.addPopup(wp.name + ' BROKE!', '#ff6b6b', 0.7, this.W / 2, this.H * 0.5);
        }
      }
      e.state = 'stun';
      e.timer = 0.5;
      e.cooldown = Math.max(e.cooldown, 0.9);
      this.hitstop = 0.06;
      this.shake = Math.max(this.shake, 9);
      haptic.hit();
      this.flashScreen('255,230,140', 0.22);
      this.addCombo();
      const sx = this.W / 2 + this.attackSide * this.W * 0.16;
      const sy = this.H * 0.66;
      for (let i = 0; i < 16; i++)
        this.spawnParticle(sx, sy, randRange(this.rng, -320, 320), randRange(this.rng, -300, 60), 0.45, i % 3 ? '#ffd86b' : '#fff6d0', 'spark');
      if (e.health <= 0) {
        this.crashEnemy(e, true);
      } else if (e.racer) {
        e.taunt = pick(this.rng, KO_TAUNTS);
        e.tauntT = 0.9;
      } else {
        this.score += 60 * this.combo;
        audio.hit();
        haptic.hit();
        this.addPopup(pick(this.rng, ['CRACK!', 'SMACK!', 'WHAM!', 'CLOBBER!']), '#ffd86b', 0.7, sx, sy);
      }
      break;
    }
  }

  /** Boot a rival sideways — low damage, big shove, can send them off the road. */
  private checkKickHits() {
    const pz = this.playerWorldZ();
    for (const e of this.enemies) {
      if (!e.alive || e.state === 'crash') continue;
      const dz = wrapDelta(e.z - pz, this.trackLength);
      const dxp = e.x - this.playerX;
      if (dz < -300 || dz > 700) continue;
      if (Math.abs(dxp) > 1.15) continue;
      if (dxp * this.kickSide < -0.25) continue;
      const dmg = 11 + (this.speed / MAX_SPEED) * 7;
      e.health -= dmg;
      e.hitFlash = 0.18;
      e.vx += this.kickSide * 6.2;
      e.state = 'stun';
      e.timer = 0.55;
      e.cooldown = Math.max(e.cooldown, 1.1);
      this.hitstop = Math.max(this.hitstop, 0.05);
      this.shake = Math.max(this.shake, 7);
      haptic.hit();
      audio.hit();
      this.flashScreen('255,220,150', 0.18);
      const sx = this.W / 2 + this.kickSide * this.W * 0.15;
      const sy = this.H * 0.68;
      for (let i = 0; i < 10; i++)
        this.spawnParticle(sx, sy, randRange(this.rng, -240, 240), randRange(this.rng, -260, 40), 0.38, '#fff2c8', 'spark');
      this.addPopup(pick(this.rng, ['BOOT!', 'GET OFF!', 'SHOVE!']), '#fff2c8', 0.6, sx, sy);
      if (e.health <= 0) this.crashEnemy(e, true);
      break;
    }
  }

  private crashEnemy(e: Enemy, byPlayer: boolean) {
    if (e.state === 'crash') return;
    e.state = 'crash';
    e.health = 0;
    e.crashTime = 0;
    e.vx = (e.vx || (this.rng() < 0.5 ? -1 : 1)) * 1.4;
    const sx = this.W / 2 + (e.x - this.playerX) * this.W * 0.3;
    const sy = this.H * 0.62;
    for (let i = 0; i < 26; i++)
      this.spawnParticle(sx, sy, randRange(this.rng, -420, 420), randRange(this.rng, -420, 80), 0.9, pick(this.rng, ['#ff9b3d', '#ffd86b', '#ff5a3c', '#ffffff']), 'debris');
    if (byPlayer) {
      if (e.racer) {
        e.dnf = true;
        this.addPopup(`${e.name} IS OUT!`, '#ffd86b', 0.7, this.W / 2, this.H * 0.3);
      }
      this.takedowns++;
      // Taking out a cop that was hunting you is worth extra: it resets the pursuit.
      if (e.type === 'cop') {
        this.score += 1200;
        this.addPopup('COP DOWN!  +1200', '#6fb4ff', 0.9, this.W / 2, this.H * 0.38);
      }
      this.addCombo();
      this.score += 750 * this.combo;
      this.boost = Math.min(100, this.boost + 26);
      this.health = Math.min(100, this.health + 4);
      this.hitstop = 0.12;
      this.shake = Math.max(this.shake, 16);
      this.flashScreen('255,255,255', 0.38);
      this.addPopup('TAKEDOWN! +' + 750 * this.combo, '#ff9b3d', 1.1, sx, sy - 20);
      audio.knockout();
      haptic.knockout();
      // cinematic slow-mo, like Road Rash's finishers
      this.timeScale = 0.32;
      this.slowmoT = 0.85;
    } else if (Math.abs(wrapDelta(e.z - this.playerWorldZ(), this.trackLength)) < 5000) {
      this.addPopup('WIPEOUT', '#9aa2b1', 0.6, sx, sy);
      audio.crash();
    }
  }

  private addCombo() {
    this.combo = Math.min(9, this.combo + 1);
    this.comboTimer = 4;
    this.bestCombo = Math.max(this.bestCombo, this.combo);
  }

  private damagePlayer(amount: number, type: 'punch' | 'crash') {
    if (this.phase !== 'playing' || this.invuln > 0) return;
    this.health -= amount;
    this.combo = 0;
    this.comboTimer = 0;
    if (type === 'crash') {
      this.invuln = 1.1;
      this.stun = 0.55;
      this.shake = Math.max(this.shake, 24);
      this.flashScreen('255,60,50', 0.45);
      audio.crash();
      haptic.crash();
      for (let i = 0; i < 22; i++)
        this.spawnParticle(this.W / 2, this.H * 0.74, randRange(this.rng, -380, 380), randRange(this.rng, -420, -40), 0.8, pick(this.rng, ['#ff5a3c', '#ffd86b', '#ffffff']), 'debris');
    } else {
      this.invuln = 0.6;
      this.shake = Math.max(this.shake, 11);
      this.flashScreen('255,60,50', 0.26);
      audio.hurt();
      haptic.heavy();
    }
    if (this.health <= 0) {
      this.health = 0;
      this.phase = 'dying';
      this.dyingTimer = 1.5;
      this.crashRot = this.rng() < 0.5 ? 1 : -1;
      this.shake = 30;
      audio.crash();
      audio.gameOver();
      haptic.crash();
    }
  }

  private collideScenery(seg: Segment) {
    if (this.invuln > 0 || this.speed < MAX_SPEED * 0.05) return;
    const check = (s: Segment) => {
      for (const sp of s.sprites) {
        const spr = this.bank.scenery[sp.kind];
        if (!spr) continue;
        const w = spr.ratio * 0.82;
        const cx = sp.offset + (w / 2) * (sp.offset > 0 ? 1 : -1);
        if (overlap(this.playerX, PLAYER_W, cx, w, 0.9)) {
          this.cause = 'WRAPPED AROUND THE SCENERY';
          const pct = this.speed / MAX_SPEED;
          this.speed *= 0.28;
          this.damagePlayer(10 + pct * 9, 'crash');
          // shove back towards the tarmac so you are not stuck in a tree farm
          this.playerX += (this.playerX > 0 ? -1 : 1) * 0.3;
          return true;
        }
      }
      return false;
    };
    if (check(seg)) return;
    check(this.segments[(seg.index + 1) % this.segments.length]);
  }

  private collideTraffic(dt: number) {
    if (this.invuln > 0) return;
    const pz = this.playerWorldZ();
    for (const t of this.traffic) {
      const dz = wrapDelta(t.z - pz, this.trackLength);
      const closing = (this.speed - t.speed * t.dir) * dt;
      if (dz > -140 && dz < 190 + Math.abs(closing)) {
        const spr = this.vehicleSprite(t);
        if (overlap(this.playerX, PLAYER_W, t.x, spr.ratio * 0.8, 0.85)) {
          this.cause = t.dir === -1 ? 'MET ONCOMING TRAFFIC' : 'REAR-ENDED A COMMUTER';
          const sev = t.dir === -1 ? 1.3 : 1;
          const pct = this.speed / MAX_SPEED;
          this.speed *= t.dir === -1 ? 0.14 : 0.34;
          this.damagePlayer((12 + pct * 12) * sev, 'crash');
          t.x += (t.x > this.playerX ? 1 : -1) * 0.1;
          this.playerX += (this.playerX > t.x ? 1 : -1) * 0.16;
          return;
        }
      }
    }
  }

  /* ------------------------------------------------------------ particles */

  private spawnParticle(
    x: number,
    y: number,
    vx: number,
    vy: number,
    life: number,
    color: string,
    kind: Particle['kind'],
  ) {
    if (this.particles.length > this.dev.maxParticles) return;
    this.particles.push({
      x,
      y,
      vx: vx * this.res,
      vy: vy * this.res,
      life,
      maxLife: life,
      size: (kind === 'debris' ? randRange(this.rng, 2, 5) : randRange(this.rng, 1.5, 3.5)) * this.res,
      color,
      gravity: kind === 'smoke' ? -120 : 700,
      kind,
    });
  }

  /** Drop a pair of skid marks at the rider's current world position. */
  private laySkidMark() {
    const z = this.playerWorldZ();
    const last = this.skidMarks[this.skidMarks.length - 1];
    // wrapped distance check so marks keep laying across the track seam
    if (last && Math.abs(wrapDelta(z - last.z, this.trackLength)) < 90) return;
    this.skidMarks.push({ z, x: this.playerX, life: SKID_MARK_LIFE });
    if (this.skidMarks.length > 90) this.skidMarks.shift();
  }

  private emitSmoke() {
    this.spawnParticle(
      this.W / 2 + randRange(this.rng, -20, 20) * this.res,
      this.H * 0.85,
      randRange(this.rng, -90, 90),
      randRange(this.rng, -140, -40),
      0.7,
      this.rng() < 0.5 ? 'rgba(225,225,235,0.75)' : 'rgba(180,180,195,0.6)',
      'smoke',
    );
  }

  private emitDust() {
    const side = this.playerX > 0 ? 1 : -1;
    this.spawnParticle(
      this.W / 2 - side * 14 * this.res,
      this.H * 0.86,
      randRange(this.rng, -120, 120) - side * 60,
      randRange(this.rng, -200, -60),
      0.55,
      this.rng() < 0.5 ? 'rgba(190,170,130,0.85)' : 'rgba(150,140,110,0.7)',
      'dust',
    );
  }

  private emitExhaust() {
    this.spawnParticle(
      this.W / 2 + randRange(this.rng, -18, 18) * this.res,
      this.H * 0.84,
      randRange(this.rng, -60, 60),
      randRange(this.rng, 40, 160),
      0.4,
      pick(this.rng, ['#8be9ff', '#5ad7ff', '#ffffff']),
      'smoke',
    );
  }

  private emitDebris(x: number, y: number, color: string) {
    this.spawnParticle(x, y, randRange(this.rng, -300, 300), randRange(this.rng, -400, -60), 0.7, color, 'debris');
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += p.gravity * dt * this.res;
      p.vx *= 1 - Math.min(0.9, dt * 1.6);
    }
  }

  private addPopup(text: string, color: string, size: number, x?: number, y?: number) {
    if (this.popups.length > 10) this.popups.shift();
    this.popups.push({
      x: x ?? this.W / 2,
      y: y ?? this.H * 0.55,
      vy: -60 * this.res,
      life: 1.1,
      maxLife: 1.1,
      text,
      color,
      size,
    });
  }

  private updatePopups(dt: number) {
    for (let i = this.popups.length - 1; i >= 0; i--) {
      const p = this.popups[i];
      p.life -= dt;
      p.y += p.vy * dt;
      p.vy *= 1 - Math.min(0.9, dt * 2);
      if (p.life <= 0) this.popups.splice(i, 1);
    }
  }

  private flashScreen(color: string, amount: number) {
    this.flashColor = color;
    this.flash = Math.max(this.flash, amount);
  }

  /* --------------------------------------------------------------- render */

  private theme(): Theme {
    const t = (this.distance / 100 / 2600) % THEMES.length;
    const i = Math.floor(t);
    const f = t - i;
    const a = THEMES[i % THEMES.length];
    const b = THEMES[(i + 1) % THEMES.length];
    const k = f < 0.75 ? 0 : (f - 0.75) / 0.25;
    return k <= 0 ? a : blendThemes(a, b, k);
  }

  private vehicleSprite(t: Traffic): Sprite {
    const b = this.bank;
    if (t.body === 'truck') return t.dir === -1 ? b.truckFront : b.truckBack;
    if (t.body === 'van') return (t.dir === -1 ? b.vanFront : b.vanBack)[t.colorIdx % 6];
    return (t.dir === -1 ? b.carsFront : b.carsBack)[t.colorIdx % 6];
  }

  private drawSprite(
    sp: Sprite,
    scale: number,
    destX: number,
    destY: number,
    offsetX: number,
    offsetY: number,
    clipY: number,
    scaleMul = 1,
  ) {
    const ctx = this.ctx;
    const destW = sp.ratio * ROAD_WIDTH * scale * (this.W / 2) * scaleMul;
    const destH = destW * (sp.h / sp.w);
    if (destW < 1 || destW > this.W * 6) return;
    const x = destX + destW * offsetX;
    const y = destY + destH * offsetY;
    const clipH = clipY ? Math.max(0, y + destH - clipY) : 0;
    if (clipH >= destH) return;
    const srcH = Math.max(1, Math.floor(sp.h - (sp.h * clipH) / destH));
    ctx.drawImage(sp.cv, 0, 0, sp.w, srcH, x | 0, y | 0, Math.ceil(destW), Math.ceil(destH - clipH));
  }

  private polygon(x1: number, y1: number, x2: number, y2: number, x3: number, y3: number, x4: number, y4: number, color: string) {
    const ctx = this.ctx;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.lineTo(x4, y4);
    ctx.closePath();
    ctx.fill();
  }

  private render() {
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;
    const theme = this.theme();

    // screen shake
    const sh = this.shake;
    this.shakeX = sh > 0 ? (Math.random() * 2 - 1) * sh * this.res : 0;
    this.shakeY = sh > 0 ? (Math.random() * 2 - 1) * sh * this.res : 0;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.save();
    ctx.translate(this.shakeX, this.shakeY);

    const baseSegment = findSegment(this.segments, this.position);
    const basePercent = (this.position % SEGMENT_LENGTH) / SEGMENT_LENGTH;
    const playerSegment = findSegment(this.segments, this.playerWorldZ());
    const playerPercent = ((this.position + this.playerZ) % SEGMENT_LENGTH) / SEGMENT_LENGTH;
    const playerY = lerp(playerSegment.p1.world.y, playerSegment.p2.world.y, playerPercent);
    const slope = (playerSegment.p2.world.y - playerSegment.p1.world.y) / SEGMENT_LENGTH;
    this.bgSlope = lerp(this.bgSlope, slope, 0.08);
    this.skyOffset = increase(this.skyOffset, baseSegment.curve * (this.speed / MAX_SPEED) * 0.9, 10000);

    this.renderBackground(theme);

    /* ---------- road */
    let maxy = H;
    let x = 0;
    let dxc = -(baseSegment.curve * basePercent);

    for (let n = 0; n < this.dev.drawDistance; n++) {
      const seg = this.segments[(baseSegment.index + n) % this.segments.length];
      seg.looped = seg.index < baseSegment.index;
      seg.fog = exponentialFog(n / this.dev.drawDistance, FOG_DENSITY);
      seg.clip = maxy;

      const camZ = this.position - (seg.looped ? this.trackLength : 0);
      project(seg.p1, this.playerX * ROAD_WIDTH - x, playerY + CAMERA_HEIGHT, camZ, this.cameraDepth, W, H, ROAD_WIDTH);
      project(seg.p2, this.playerX * ROAD_WIDTH - x - dxc, playerY + CAMERA_HEIGHT, camZ, this.cameraDepth, W, H, ROAD_WIDTH);

      x += dxc;
      dxc += seg.curve;

      if (seg.p1.camera.z <= this.cameraDepth || seg.p2.screen.y >= seg.p1.screen.y || seg.p2.screen.y >= maxy) continue;

      this.renderSegment(seg, theme);
      maxy = seg.p2.screen.y;
    }

    /* ---------- entities bucketed into segments */
    for (const s of this.dirty) s.ents.length = 0;
    this.dirty.length = 0;
    const bucket = (e: Entity) => {
      const seg = findSegment(this.segments, e.z);
      if (seg.ents.length === 0) this.dirty.push(seg);
      seg.ents.push(e);
    };
    this.traffic.forEach(bucket);
    this.enemies.forEach(bucket);
    this.pickups.forEach(bucket);

    /* ---------- skid marks, painted on the tarmac */
    this.renderSkidMarks(baseSegment.index);

    /* ---------- sprites & entities, far to near */
    for (let n = this.dev.drawDistance - 1; n > 0; n--) {
      const seg = this.segments[(baseSegment.index + n) % this.segments.length];
      if (seg.p1.screen.scale <= 0) continue;
      const fog = seg.fog;
      if (fog < 0.02) continue;
      ctx.globalAlpha = Math.min(1, fog * 1.15);
      if (seg.index === this.startLineIdx) this.renderGantry(seg);
      for (const sp of seg.sprites) {
        const spr = this.bank.scenery[sp.kind];
        if (!spr) continue;
        const scale = seg.p1.screen.scale;
        const sx = seg.p1.screen.x + scale * sp.offset * ROAD_WIDTH * (W / 2);
        this.drawSprite(spr, scale, sx, seg.p1.screen.y, sp.offset < 0 ? -1 : 0, -1, seg.clip);
      }
      for (const e of seg.ents) {
        const percent = (e.z % SEGMENT_LENGTH) / SEGMENT_LENGTH;
        // skip anything that has slipped behind the rider (it would balloon on screen)
        if (lerp(seg.p1.camera.z, seg.p2.camera.z, percent) < this.playerZ * 0.55) continue;
        const scale = lerp(seg.p1.screen.scale, seg.p2.screen.scale, percent);
        const sx = lerp(seg.p1.screen.x, seg.p2.screen.x, percent) + scale * e.x * ROAD_WIDTH * (W / 2);
        const sy = lerp(seg.p1.screen.y, seg.p2.screen.y, percent);
        this.renderEntity(e, scale, sx, sy, seg.clip);
      }
      ctx.globalAlpha = 1;
    }
    ctx.globalAlpha = 1;

    /* ---------- player */
    if (this.phase !== 'over') this.renderPlayer(playerSegment, playerPercent);

    /* ---------- fx */
    this.renderParticles();
    this.renderSpeedLines();
    this.renderPopups();
    ctx.restore();
    this.renderOverlays(theme);
  }

  private renderBackground(theme: Theme) {
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;
    const horizon = H * 0.5 - clamp(this.bgSlope, -0.5, 0.5) * 170 * this.res;

    // ---- 1. Multi-stop atmospheric sky gradient
    const skyMid = mixRgb(theme.skyTop, theme.skyBot, 0.58);
    const skyGlow = mixRgb(theme.skyBot, theme.sun, 0.28);
    const g = ctx.createLinearGradient(0, -H * 0.2, 0, horizon + 12);
    g.addColorStop(0, css(theme.skyTop));
    g.addColorStop(0.52, css(skyMid));
    g.addColorStop(0.84, css(theme.skyBot));
    g.addColorStop(1, css(skyGlow));
    ctx.fillStyle = g;
    ctx.fillRect(-40, -H * 0.3, W + 80, horizon + H * 0.3 + 16);

    // ---- 2. Twinkling stars in night/dusk biomes
    if (theme.stars > 0.02) {
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < this.stars.length; i++) {
        const s = this.stars[i];
        const sx = (s[0] * W * 2 - this.skyOffset * 0.12) % (W * 2);
        const px = sx < 0 ? sx + W * 2 : sx;
        if (px > W) continue;
        const twinkle = 0.65 + 0.35 * Math.sin(this.time * 3.2 + i * 1.9);
        ctx.globalAlpha = theme.stars * twinkle;
        ctx.fillRect(px | 0, (s[1] * horizon * 0.85) | 0, s[2], s[2]);
      }
      ctx.globalAlpha = 1;
    }

    // ---- 3. Sun / Moon with multi-layered atmospheric corona
    const sunX = ((W * 0.72 - this.skyOffset * 0.22) % (W * 1.6) + W * 1.6) % (W * 1.6) - W * 0.3;
    const sunY = horizon - H * 0.19;
    const rad = H * 0.115;
    const sg = ctx.createRadialGradient(sunX, sunY, rad * 0.15, sunX, sunY, rad * 3.1);
    sg.addColorStop(0, cssA(theme.sun, 0.95));
    sg.addColorStop(0.32, cssA(theme.sun, 0.38));
    sg.addColorStop(0.65, cssA(theme.skyBot, 0.16));
    sg.addColorStop(1, cssA(theme.sun, 0));
    ctx.fillStyle = sg;
    ctx.fillRect(sunX - rad * 3.1, sunY - rad * 3.1, rad * 6.2, rad * 6.2);

    const discG = ctx.createLinearGradient(sunX, sunY - rad, sunX, sunY + rad);
    discG.addColorStop(0, '#ffffff');
    discG.addColorStop(0.35, css(theme.sun));
    discG.addColorStop(1, css(mixRgb(theme.sun, theme.skyBot, 0.45)));
    ctx.fillStyle = discG;
    ctx.beginPath();
    ctx.arc(sunX, sunY, rad, 0, Math.PI * 2);
    ctx.fill();

    // ---- 4. Soft seamless high-altitude cirrus cloud wisps
    const cloudBase = mixRgb(theme.skyBot, theme.sun, 0.42);
    for (const cl of this.clouds) {
      const spanW = W * 1.8;
      const cx = (((cl.x * spanW - this.skyOffset * cl.speed + this.time * 3.5 * cl.speed) % spanW) + spanW) % spanW - W * 0.4;
      const cy = cl.y * horizon;
      const cw = cl.w * W * 0.5;
      const ch = cl.h * H * 0.48;
      if (cx + cw < -40 || cx - cw > W + 40) continue;
      const a = cl.alpha * 0.65 * (1 - theme.stars * 0.55);
      const cg = ctx.createRadialGradient(cx, cy + ch * 0.25, ch * 0.1, cx, cy, cw);
      cg.addColorStop(0, cssA(cloudBase, a));
      cg.addColorStop(0.55, cssA(cloudBase, a * 0.45));
      cg.addColorStop(1, cssA(cloudBase, 0));
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.ellipse(cx, cy, cw, ch, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // ---- 5. Three Parallax 3D-Faceted Mountain Ranges + Valley Mist
    // Far Alpine Massifs (tall, sharp peaks, snow/alpenglow caps, strong sun-vs-shadow facets)
    this.renderMountainRange(
      this.mountainsFar,
      horizon + 2,
      H * 0.31,
      this.skyOffset * 0.24,
      sunX,
      theme.far,
      theme,
      true,
      0.55,
    );

    // Atmospheric valley mist separating Far and Mid ranges
    const mist1 = ctx.createLinearGradient(0, horizon - H * 0.14, 0, horizon + 4);
    mist1.addColorStop(0, cssA(theme.skyBot, 0));
    mist1.addColorStop(1, cssA(mixRgb(theme.skyBot, theme.fog, 0.5), 0.38));
    ctx.fillStyle = mist1;
    ctx.fillRect(-20, horizon - H * 0.14, W + 40, H * 0.14 + 4);

    // Mid-Range Sierra Ridges (sculpted rock faces, deeper tones)
    const midBaseColor = mixRgb(theme.far, theme.near, 0.58);
    this.renderMountainRange(
      this.mountainsMid,
      horizon + 2,
      H * 0.19,
      this.skyOffset * 0.5,
      sunX,
      midBaseColor,
      theme,
      false,
      0.38,
    );

    // Low valley mist separating Mid range and Near foothills
    const mist2 = ctx.createLinearGradient(0, horizon - H * 0.08, 0, horizon + 4);
    mist2.addColorStop(0, cssA(theme.fog, 0));
    mist2.addColorStop(1, cssA(theme.fog, 0.32));
    ctx.fillStyle = mist2;
    ctx.fillRect(-20, horizon - H * 0.08, W + 40, H * 0.08 + 4);

    // Near Foothills & Pine/Canyon Ridge Silhouette
    this.renderMountainRange(
      this.mountainsNear,
      horizon + 2,
      H * 0.1,
      this.skyOffset * 0.82,
      sunX,
      theme.near,
      theme,
      false,
      0.22,
    );

    // Ground plane under the horizon
    ctx.fillStyle = css(theme.grassDark);
    ctx.fillRect(-40, horizon, W + 80, H - horizon + 40);
  }

  /**
   * Renders a seamless parallax mountain range with vertical atmospheric shading,
   * 3D sunlit & shadowed rock facets descending from every peak, optional snow/alpenglow
   * summit caps, and a sun-tinted rim-light along the ridge crest.
   */
  private renderMountainRange(
    points: number[],
    baseY: number,
    amp: number,
    offset: number,
    sunX: number,
    baseRgb: RGB,
    theme: Theme,
    snowCaps: boolean,
    rimAlpha: number,
  ) {
    const ctx = this.ctx;
    const W = this.W;
    const span = W * 1.5;
    const n = points.length;
    const step = span / (n - 1);
    const shift = ((-offset % span) + span) % span;

    // 1. Main mountain massif silhouette with vertical aerial-perspective gradient
    const topRgb = mixRgb(baseRgb, theme.sun, 0.16);
    const botRgb = mixRgb(baseRgb, theme.fog, 0.32);
    const bodyGrad = ctx.createLinearGradient(0, baseY - amp, 0, baseY);
    bodyGrad.addColorStop(0, css(topRgb));
    bodyGrad.addColorStop(0.65, css(baseRgb));
    bodyGrad.addColorStop(1, css(botRgb));

    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.moveTo(-span + shift, baseY);
    for (let rep = 0; rep < 2; rep++) {
      const base = -span + shift + rep * span;
      for (let i = 0; i < n; i++) {
        ctx.lineTo(base + i * step, baseY - points[i] * amp);
      }
    }
    ctx.lineTo(-span + shift + 2 * span, baseY);
    ctx.closePath();
    ctx.fill();

    // 2. 3D Sunlit & Shadowed Triangular Rock Facets on local peaks + Snow/Alpenglow Caps
    const litColor = cssA(mixRgb(baseRgb, theme.sun, 0.46), 0.44);
    const subLitColor = cssA(mixRgb(baseRgb, theme.skyBot, 0.38), 0.28);
    const shadeColor = cssA(mixRgb(baseRgb, [4, 6, 16], 0.56), 0.52);
    const snowLit = cssA(mixRgb(theme.sun, [255, 255, 255], 0.62), 0.78);
    const snowShade = cssA(mixRgb(theme.skyTop, [200, 220, 255], 0.55), 0.62);

    for (let rep = 0; rep < 2; rep++) {
      const base = -span + shift + rep * span;
      for (let i = 1; i < n - 1; i++) {
        const h = points[i];
        // Identify local peaks & prominent shoulders
        if (h < points[i - 1] || h < points[i + 1] || h < 0.32) continue;

        const px = base + i * step;
        const py = baseY - h * amp;
        if (px < -step * 4 || px > W + step * 4) continue;

        // Walk left & right down to the nearest saddle (up to 3 steps) to form a broad 3D massif
        let li = i - 1;
        while (li > 0 && li > i - 3 && points[li - 1] <= points[li]) li--;
        let ri = i + 1;
        while (ri < n - 1 && ri < i + 3 && points[ri + 1] <= points[ri]) ri++;

        const lx = base + li * step;
        const ly = baseY - points[li] * amp;
        const rx = base + ri * step;
        const ry = baseY - points[ri] * amp;

        // Central ridge spine descending from the peak with natural dogleg sway
        const sway = this.ridgeSway[i % this.ridgeSway.length] * step * 1.3;
        const midRidgeX = px + sway * 0.45;
        const midRidgeY = lerp(py, baseY, 0.48);
        const botRidgeX = px + sway;

        const sunOnRight = sunX >= px;

        // Left face polygon
        ctx.fillStyle = sunOnRight ? shadeColor : litColor;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(lx, ly);
        ctx.lineTo(lx + (botRidgeX - lx) * 0.35, baseY);
        ctx.lineTo(botRidgeX, baseY);
        ctx.lineTo(midRidgeX, midRidgeY);
        ctx.closePath();
        ctx.fill();

        // Right face polygon
        ctx.fillStyle = sunOnRight ? litColor : shadeColor;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(midRidgeX, midRidgeY);
        ctx.lineTo(botRidgeX, baseY);
        ctx.lineTo(rx - (rx - botRidgeX) * 0.35, baseY);
        ctx.lineTo(rx, ry);
        ctx.closePath();
        ctx.fill();

        // Secondary spur ridge highlight on the sunlit side for extra rock detail
        const spurX = sunOnRight ? lerp(px, rx, 0.52) : lerp(px, lx, 0.52);
        const spurY = sunOnRight ? lerp(py, ry, 0.52) : lerp(py, ly, 0.52);
        ctx.fillStyle = subLitColor;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(spurX, spurY);
        ctx.lineTo(lerp(botRidgeX, spurX, 0.6), baseY);
        ctx.lineTo(midRidgeX, midRidgeY);
        ctx.closePath();
        ctx.fill();

        // Snowcaps / Alpenglow summit crowns on the tallest far peaks
        if (snowCaps && h > 0.64) {
          const capFrac = clamp((h - 0.64) / 0.55 + 0.22, 0.2, 0.46);
          const slx = lerp(px, lx, capFrac);
          const sly = lerp(py, ly, capFrac);
          const srx = lerp(px, rx, capFrac);
          const sry = lerp(py, ry, capFrac);
          const smx = lerp(px, midRidgeX, capFrac * 1.25);
          const smy = lerp(py, midRidgeY, capFrac * 1.25);

          ctx.fillStyle = sunOnRight ? snowShade : snowLit;
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(slx, sly);
          ctx.lineTo(lerp(slx, smx, 0.5), smy - (smy - sly) * 0.25);
          ctx.lineTo(smx, smy);
          ctx.closePath();
          ctx.fill();

          ctx.fillStyle = sunOnRight ? snowLit : snowShade;
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(smx, smy);
          ctx.lineTo(lerp(srx, smx, 0.5), smy - (smy - sry) * 0.25);
          ctx.lineTo(srx, sry);
          ctx.closePath();
          ctx.fill();
        }
      }
    }

    // 3. Sunlit rim-light stroke along the top ridge contour
    ctx.strokeStyle = cssA(mixRgb(theme.sun, theme.skyBot, 0.35), rimAlpha);
    ctx.lineWidth = Math.max(1, 1.4 * this.res);
    ctx.lineJoin = 'round';
    ctx.beginPath();
    for (let rep = 0; rep < 2; rep++) {
      const base = -span + shift + rep * span;
      for (let i = 0; i < n; i++) {
        const x = base + i * step;
        const y = baseY - points[i] * amp;
        if (rep === 0 && i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
    }
    ctx.stroke();
  }

  /**
   * Paint tyre marks onto the road. Each mark spans two segments so it reads
   * as a continuous streak rather than a dot.
   */
  private renderSkidMarks(baseIndex: number) {
    if (!this.skidMarks.length) return;
    const ctx = this.ctx;
    const W = this.W;
    const len = this.segments.length;
    const tyreW = ROAD_WIDTH * 0.012;

    for (const m of this.skidMarks) {
      const rel = ((m.z - this.position) % this.trackLength + this.trackLength) % this.trackLength;
      const n = Math.round(rel / SEGMENT_LENGTH);
      if (n < 3 || n > 60) continue; // start right under the rear tyre contact patch
      const seg = this.segments[(baseIndex + n) % len];
      const next = this.segments[(baseIndex + n + 1) % len];
      if (seg.p1.screen.scale <= 0) continue;

      const alpha = Math.min(0.42, (m.life / SKID_MARK_LIFE) * 0.5) * seg.fog;
      if (alpha < 0.02) continue;

      const x1 = seg.p1.screen.x + seg.p1.screen.scale * m.x * ROAD_WIDTH * (W / 2);
      const x2 = next.p1.screen.x + next.p1.screen.scale * m.x * ROAD_WIDTH * (W / 2);
      const y1 = seg.p1.screen.y;
      const y2 = next.p1.screen.y;
      if (y2 >= y1) continue;

      const w1 = Math.max(1, seg.p1.screen.scale * tyreW * (W / 2));
      const w2 = Math.max(1, next.p1.screen.scale * tyreW * (W / 2));

      ctx.globalAlpha = alpha;
      // Single motorcycle rear-tyre dark rubber streak
      this.polygon(x1 - w1 * 0.85, y1, x1 + w1 * 0.85, y1, x2 + w2 * 0.85, y2, x2 - w2 * 0.85, y2, '#121118');
    }
    ctx.globalAlpha = 1;
  }

  /** Overhead START banner on two poles, with the countdown lights. */
  private renderGantry(seg: Segment) {
    const s = seg.p1.screen;
    if (s.scale <= 0 || s.y > seg.clip) return;
    const ctx = this.ctx;
    const k = s.scale * (this.W / 2); // world units -> pixels (matches sprite scaling)
    const left = s.x - s.w * 1.16;
    const right = s.x + s.w * 1.16;
    const top = s.y - 1500 * k;
    const bannerH = 320 * k;
    const poleW = Math.max(2, 70 * k);
    if (right - left < 6) return;

    ctx.fillStyle = '#3a3f4f';
    ctx.fillRect(left - poleW / 2, top, poleW, s.y - top);
    ctx.fillRect(right - poleW / 2, top, poleW, s.y - top);
    ctx.fillStyle = '#12141c';
    ctx.fillRect(left, top, right - left, bannerH);
    ctx.fillStyle = '#ff8a3c';
    ctx.fillRect(left, top, right - left, Math.max(1, bannerH * 0.12));
    ctx.fillRect(left, top + bannerH * 0.88, right - left, Math.max(1, bannerH * 0.12));

    if (bannerH > 7) {
      ctx.font = `900 ${Math.round(bannerH * 0.55)}px "Rajdhani", "Arial Black", sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillStyle = '#f2f3f7';
      ctx.fillText('ROAD FURY  ·  START', s.x, top + bannerH * 0.7);
    }

    // three lamps under the banner: red one-by-one, all green on GO
    const lit = this.grid ? clamp(3 - Math.ceil(this.countdown) + 1, 0, 3) : 0;
    const green = !this.grid && this.startLineIdx >= 0;
    const r = Math.max(1.5, 95 * k);
    for (let i = 0; i < 3; i++) {
      const lx = s.x + (i - 1) * r * 3;
      const ly = top + bannerH + r * 1.5;
      const on = green || i < lit;
      const col = green ? '#3dff6e' : '#ff2e2e';
      if (on) {
        ctx.globalAlpha = 0.35;
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(lx, ly, r * 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      ctx.fillStyle = '#0b0c10';
      ctx.fillRect(lx - r * 1.3, ly - r * 1.3, r * 2.6, r * 2.6);
      ctx.fillStyle = on ? col : '#3a1414';
      ctx.beginPath();
      ctx.arc(lx, ly, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  /** Big countdown numbers, the rev gauge and the GO! flash. */
  private renderRaceStart() {
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;
    ctx.textAlign = 'center';

    if (this.grid) {
      const n = Math.ceil(this.countdown);
      const frac = this.countdown - Math.floor(this.countdown); // 1 → 0 within each second
      const label = n > 3 ? 'GET READY' : String(n);
      const pop = n > 3 ? 1 : 1 + Math.max(0, frac - 0.7) * 1.6;
      const fs = Math.round((n > 3 ? 30 : 84) * this.res * pop);
      ctx.font = `900 ${fs}px "Rajdhani", "Arial Black", sans-serif`;
      ctx.lineWidth = Math.max(3, fs * 0.08);
      ctx.strokeStyle = 'rgba(0,0,0,0.9)';
      ctx.strokeText(label, W / 2, H * 0.36);
      ctx.fillStyle = n > 3 ? '#ffd86b' : '#ff4d2d';
      ctx.fillText(label, W / 2, H * 0.36);

      const auto = this.autoGas && this.touchHints && !this.keyboardDriving;
      const tip = auto
        ? 'AUTO LAUNCH ENGAGED'
        : this.touchHints && !this.keyboardDriving
          ? 'HOLD GAS TO REV · LAUNCH IN THE GREEN ZONE'
          : 'HOLD  \u2191 / W  TO REV  ·  LAUNCH IN THE GREEN ZONE';
      ctx.font = `700 ${Math.round(12 * this.res)}px "Rajdhani", sans-serif`;
      ctx.lineWidth = Math.max(2, 3 * this.res);
      ctx.strokeText(tip, W / 2, H * 0.36 + 26 * this.res);
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fillText(tip, W / 2, H * 0.36 + 26 * this.res);

      if (!auto) {
        // rev gauge: green zone = perfect launch, flashing red = about to wheelspin
        const gw = W * 0.3;
        const gh = Math.max(6, 10 * this.res);
        const gx = W / 2 - gw / 2;
        const gy = H * 0.36 + 38 * this.res;
        ctx.fillStyle = 'rgba(0,0,0,0.65)';
        ctx.fillRect(gx - 2, gy - 2, gw + 4, gh + 4);
        ctx.fillStyle = 'rgba(80,255,120,0.28)';
        ctx.fillRect(gx + gw * 0.75, gy, gw * 0.25, gh);
        const danger = this.redline > 0.6 && Math.floor(this.time * 10) % 2 === 0;
        ctx.fillStyle = danger ? '#ff3b30' : this.rev >= 0.75 ? '#3dff6e' : '#ffd86b';
        ctx.fillRect(gx, gy, gw * this.rev, gh);
        ctx.font = `800 ${Math.round(9 * this.res)}px "Rajdhani", sans-serif`;
        ctx.fillStyle = danger ? '#ff6b6b' : 'rgba(255,255,255,0.6)';
        ctx.fillText(danger ? 'TOO MANY REVS!' : 'REV', W / 2, gy + gh + 12 * this.res);
      }
    } else if (this.goFlash > 0) {
      const a = Math.min(1, this.goFlash * 2);
      const fs = Math.round(96 * this.res * (1 + (1 - this.goFlash) * 0.5));
      ctx.globalAlpha = a;
      ctx.font = `900 ${fs}px "Rajdhani", "Arial Black", sans-serif`;
      ctx.lineWidth = Math.max(3, fs * 0.08);
      ctx.strokeStyle = 'rgba(0,0,0,0.9)';
      ctx.strokeText('GO!', W / 2, H * 0.38);
      ctx.fillStyle = '#3dff6e';
      ctx.fillText('GO!', W / 2, H * 0.38);
      ctx.globalAlpha = 1;
    }
  }

  private renderSegment(seg: Segment, theme: Theme) {
    const W = this.W;
    const p1 = seg.p1.screen;
    const p2 = seg.p2.screen;
    const grass = seg.dark ? theme.grassDark : theme.grassLight;
    const road = seg.dark ? theme.roadDark : theme.roadLight;
    const rumble = seg.dark ? theme.rumbleDark : theme.rumbleLight;

    // grass
    this.ctx.fillStyle = css(grass);
    this.ctx.fillRect(0, p2.y, W, Math.max(0, p1.y - p2.y));

    const r1 = p1.w / Math.max(6, 2 * LANES);
    const r2 = p2.w / Math.max(6, 2 * LANES);
    this.polygon(p1.x - p1.w - r1, p1.y, p1.x - p1.w, p1.y, p2.x - p2.w, p2.y, p2.x - p2.w - r2, p2.y, css(rumble));
    this.polygon(p1.x + p1.w + r1, p1.y, p1.x + p1.w, p1.y, p2.x + p2.w, p2.y, p2.x + p2.w + r2, p2.y, css(rumble));
    this.polygon(p1.x - p1.w, p1.y, p1.x + p1.w, p1.y, p2.x + p2.w, p2.y, p2.x - p2.w, p2.y, css(road));

    const startRow = this.startLineIdx >= 0 ? seg.index - this.startLineIdx : -1;
    if (startRow === 0 || startRow === 1) {
      const cols = 10;
      this.polygon(p1.x - p1.w, p1.y, p1.x + p1.w, p1.y, p2.x + p2.w, p2.y, p2.x - p2.w, p2.y, '#16161c');
      for (let c = 0; c < cols; c++) {
        if ((c + startRow) % 2) continue;
        const a1 = p1.x - p1.w + (2 * p1.w * c) / cols;
        const b1 = p1.x - p1.w + (2 * p1.w * (c + 1)) / cols;
        const a2 = p2.x - p2.w + (2 * p2.w * c) / cols;
        const b2 = p2.x - p2.w + (2 * p2.w * (c + 1)) / cols;
        this.polygon(a1, p1.y, b1, p1.y, b2, p2.y, a2, p2.y, '#f2f3f7');
      }
    } else if (seg.lane) {
      const lw1 = (p1.w * 2) / LANES;
      const lw2 = (p2.w * 2) / LANES;
      let lx1 = p1.x - p1.w + lw1;
      let lx2 = p2.x - p2.w + lw2;
      const l1 = p1.w / Math.max(32, 8 * LANES);
      const l2 = p2.w / Math.max(32, 8 * LANES);
      for (let lane = 1; lane < LANES; lane++, lx1 += lw1, lx2 += lw2) {
        this.polygon(lx1 - l1 / 2, p1.y, lx1 + l1 / 2, p1.y, lx2 + l2 / 2, p2.y, lx2 - l2 / 2, p2.y, css(theme.lane));
      }
    }

    if (seg.fog < 1) {
      this.ctx.globalAlpha = 1 - seg.fog;
      this.ctx.fillStyle = css(theme.fog);
      this.ctx.fillRect(0, p2.y, W, Math.max(0, p1.y - p2.y));
      this.ctx.globalAlpha = 1;
    }
  }

  /**
   * Draw a full bike: banked body, live spinning wheels, then the rider hung
   * off the inside of the corner. Used for the player AND every rival so the
   * whole field animates the same way.
   */
  private renderBike(
    set: BikeSet,
    scale: number,
    sx: number,
    sy: number,
    o: {
      lean: number;
      susp: number;
      wheel: number;
      slip: number;
      pose: RiderPose;
      hang: number;
      clip: number;
      braking?: boolean;
      swing?: SwingAnim;
      /** False only for the player, who always gets full articulation. */
      allowLod?: boolean;
    },
  ) {
    const ctx = this.ctx;
    const destW = SPR_RATIO * ROAD_WIDTH * scale * (this.W / 2);
    const destH = destW * (SPR_H / SPR_W);
    if (destW < 1.2) return;
    if (o.clip > 0 && sy - destH >= o.clip) return;

    /* ---- LOD billboard -------------------------------------------------
     * The fully articulated path costs ~40 canvas ops and ~10 gradient
     * allocations per bike per frame. At rival scale on a phone that is what
     * turns 60fps into a slideshow. Distant bikes are a single cached composite
     * blit instead — indistinguishable at that size, ~25x cheaper.
     */
    // On phones every rival billboards regardless of size: a tight 9-bike pack
    // otherwise costs ~110 gradient allocations per frame, which is what dragged
    // mobile to a crawl. The player always keeps full articulation.
    if (o.allowLod !== false && (this.dev.isMobile || destW < BIKE_LOD_MIN_PX)) {
      const lean = clamp(o.lean, -LEAN_MAX * 1.12, LEAN_MAX * 1.12);
      this.shadow(sx, sy, destW * 0.58, 0.36);
      ctx.save();
      if (o.clip > 0 && sy > o.clip) {
        ctx.beginPath();
        ctx.rect(0, 0, this.W, o.clip);
        ctx.clip();
      }
      ctx.translate(sx, sy);
      ctx.rotate(lean);
      ctx.drawImage(set.crashFull.cv, -destW / 2, -destH, destW, destH);
      ctx.restore();
      return;
    }

    const u = destW / SPR_W;
    const suspPx = o.susp * destH * 0.028;
    const squash = clamp(o.susp * 0.05, -0.05, 0.055);
    const lean = clamp(o.lean, -LEAN_MAX * 1.12, LEAN_MAX * 1.12);

    // Ground contact shadow hugging the rear tyre patch
    this.shadow(sx + Math.sin(lean) * destW * 0.16, sy - destH * 0.01, destW * (0.58 - squash), 0.44);

    ctx.save();
    if (o.clip > 0 && sy > o.clip) {
      ctx.beginPath();
      ctx.rect(0, 0, this.W, o.clip);
      ctx.clip();
    }

    ctx.translate(sx, sy + suspPx);
    ctx.scale(u, u * (1 - squash));
    ctx.rotate(lean);

    // 1. Front tyre tucked forward under the nose cowling
    drawWheel(ctx, {
      cx: 0,
      cy: -72,
      rx: 13,
      ry: 24,
      angle: o.wheel * 1.05,
      slip: o.slip * 0.3,
      squash: o.susp * 0.6,
      rear: false,
    });

    // 2. Forward & mid superbike chassis (fairings, windscreen, bars, mirrors, tank, exhausts)
    ctx.drawImage(set.chassis.cv, -CONTACT_X, -CONTACT_Y);

    // 3. Fat 200mm rear sportbike slick tyre + gold chain + brake rotor + gullwing swingarm
    drawWheel(ctx, {
      cx: 0,
      cy: -48,
      rx: 21,
      ry: 46,
      angle: o.wheel,
      slip: o.slip,
      squash: o.susp * 0.42,
      rear: true,
    });

    // 4. Connected IK-articulated rider + pointed tail cowl + LED tail light + rear-view helmet
    drawArticulatedRider(ctx, set, lean, o.hang, o.pose, Boolean(o.braking), o.swing);

    ctx.restore();
  }

  private shadow(x: number, y: number, w: number, alpha = 0.35) {
    const ctx = this.ctx;
    ctx.fillStyle = `rgba(0,0,0,${alpha})`;
    ctx.beginPath();
    ctx.ellipse(x, y, w * 0.5, Math.max(1, w * 0.13), 0, 0, Math.PI * 2);
    ctx.fill();
  }

  private renderEntity(e: Entity, scale: number, sx: number, sy: number, clip: number) {
    const ctx = this.ctx;
    if (e.kind === 'traffic') {
      const spr = this.vehicleSprite(e);
      this.shadow(sx, sy, spr.ratio * ROAD_WIDTH * scale * (this.W / 2) * 0.95, 0.3);
      this.drawSprite(spr, scale, sx, sy, -0.5, -1, clip);
      return;
    }
    if (e.kind === 'pickup') {
      const w = 0.12 * ROAD_WIDTH * scale * (this.W / 2);
      const bobY = Math.sin(e.phase) * w * 0.25;
      const col = e.type === 'repair' ? '#3ddc84' : e.type === 'weapon' ? '#c9a24a' : '#49c7ff';
      ctx.globalAlpha = Math.min(1, ctx.globalAlpha);
      this.shadow(sx, sy, w, 0.25);
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      ctx.fillRect(sx - w / 2, sy - w * 1.3 + bobY, w, w);
      ctx.fillStyle = col;
      ctx.fillRect(sx - w / 2 + w * 0.08, sy - w * 1.22 + bobY, w * 0.84, w * 0.84);
      ctx.fillStyle = '#ffffff';
      if (e.type === 'repair') {
        ctx.fillRect(sx - w * 0.08, sy - w * 1.06 + bobY, w * 0.16, w * 0.52);
        ctx.fillRect(sx - w * 0.26, sy - w * 0.88 + bobY, w * 0.52, w * 0.16);
      } else if (e.type === 'weapon') {
        const wc = WEAPONS[e.weapon].color;
        if (e.weapon === 'chain') {
          ctx.strokeStyle = wc;
          ctx.lineWidth = Math.max(1, w * 0.07);
          for (let i = 0; i < 5; i++) {
            const ly = sy - w * 1.12 + bobY + i * w * 0.17;
            ctx.beginPath();
            ctx.ellipse(sx, ly, w * 0.1, w * 0.07, 0, 0, Math.PI * 2);
            ctx.stroke();
          }
        } else if (e.weapon === 'wrench') {
          ctx.save();
          ctx.translate(sx, sy - w * 0.72 + bobY);
          ctx.rotate(-0.5);
          ctx.fillStyle = wc;
          ctx.fillRect(-w * 0.06, -w * 0.4, w * 0.12, w * 0.62);
          ctx.beginPath();
          ctx.arc(0, w * 0.24, w * 0.16, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else {
          ctx.save();
          ctx.translate(sx, sy - w * 0.72 + bobY);
          ctx.rotate(0.42);
          ctx.fillStyle = wc;
          ctx.fillRect(-w * 0.05, -w * 0.42, w * 0.1, w * 0.66);
          ctx.restore();
        }
      } else {
        ctx.beginPath();
        ctx.moveTo(sx + w * 0.1, sy - w * 1.1 + bobY);
        ctx.lineTo(sx - w * 0.18, sy - w * 0.74 + bobY);
        ctx.lineTo(sx - w * 0.02, sy - w * 0.74 + bobY);
        ctx.lineTo(sx - w * 0.1, sy - w * 0.42 + bobY);
        ctx.lineTo(sx + w * 0.2, sy - w * 0.82 + bobY);
        ctx.lineTo(sx + w * 0.03, sy - w * 0.82 + bobY);
        ctx.closePath();
        ctx.fill();
      }
      return;
    }

    // enemy biker
    const gangBanks = this.bank.bikes.gang;
    const set = e.type === 'cop' ? this.bank.bikes.cop : gangBanks[e.colorIdx % gangBanks.length];
    const pose: RiderPose = e.state === 'punch' || e.state === 'wind' ? (e.punchSide < 0 ? 'punchL' : 'punchR') : 'ride';
    const w = SPR_RATIO * ROAD_WIDTH * scale * (this.W / 2);

    if (e.state === 'crash') {
      this.shadow(sx, sy, w * 0.7, 0.3);
      ctx.save();
      ctx.translate(sx, sy - w * 0.4);
      ctx.rotate(e.crashRot);
      ctx.globalAlpha = Math.max(0, Math.min(1, (2.4 - e.crashTime) / 1.2)) * ctx.globalAlpha;
      this.drawSprite(set.crashFull, scale, 0, w * 0.4, -0.5, -CONTACT_Y / SPR_H, 0);
      ctx.restore();
      ctx.globalAlpha = 1;
      return;
    }

    if (e.hitFlash > 0) ctx.filter = 'brightness(2.8) saturate(0.3)';
    this.renderBike(set, scale, sx, sy, {
      lean: e.lean,
      susp: e.susp,
      wheel: e.wheel,
      slip: e.slip,
      pose,
      hang: e.hang,
      clip,
    });
    ctx.filter = 'none';

    // cop light bar
    if (e.type === 'cop') {
      const blink = Math.floor(this.time * 8) % 2 === 0;
      const lw = w * 0.17;
      const ly = sy - w * 1.05;
      ctx.fillStyle = blink ? '#ff3344' : '#2a2f3c';
      ctx.fillRect(sx - lw * 1.1, ly, lw, lw * 0.55);
      ctx.fillStyle = blink ? '#2a2f3c' : '#3ba7ff';
      ctx.fillRect(sx + lw * 0.1, ly, lw, lw * 0.55);
      if (blink) {
        ctx.globalAlpha = 0.25;
        ctx.fillStyle = '#ff3344';
        ctx.fillRect(sx - lw * 2.2, ly - lw, lw * 4.4, lw * 2.4);
        ctx.globalAlpha = 1;
      }
    }

    // racer name tag (fades in smoothly when close so distant packs never overlap text)
    if (e.racer && w > 28) {
      const tagAlpha = clamp((w - 28) / 22, 0, 1);
      const prevAlpha = ctx.globalAlpha;
      ctx.globalAlpha = prevAlpha * tagAlpha;
      const tagColors = ['#7aff98', '#d299ff', '#ffe47a', '#6ff0ff', '#ff7088', '#ffb06b'];
      const fs = Math.max(9, Math.min(15 * this.res, w * 0.16));
      ctx.font = `800 ${fs}px "Rajdhani", "Arial Black", sans-serif`;
      ctx.textAlign = 'center';
      ctx.lineWidth = Math.max(2, fs * 0.22);
      ctx.strokeStyle = 'rgba(0,0,0,0.85)';
      const ty = sy - w * 1.24;
      ctx.strokeText(e.name, sx, ty);
      ctx.fillStyle = tagColors[e.colorIdx % tagColors.length];
      ctx.fillText(e.name, sx, ty);
      ctx.globalAlpha = prevAlpha;
    }

    // rival taunt speech bubble
    if (e.tauntT > 0 && w > 14) {
      const a = Math.min(1, e.tauntT * 2.2);
      const fs = Math.max(8, Math.min(15 * this.res, w * 0.16));
      ctx.font = `900 ${fs}px "Rajdhani", "Arial Black", sans-serif`;
      const tw = ctx.measureText(e.taunt).width;
      const padX = fs * 0.42;
      const bh = fs * 1.5;
      const bx = sx - tw / 2 - padX;
      const by = sy - w * 1.72 - bh;
      const r = fs * 0.32;
      ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(12,10,22,0.9)';
      ctx.strokeStyle = '#ff9b3d';
      ctx.lineWidth = Math.max(1, this.res * 1.2);
      ctx.beginPath();
      ctx.moveTo(bx + r, by);
      ctx.lineTo(bx + tw + padX * 2 - r, by);
      ctx.arcTo(bx + tw + padX * 2, by, bx + tw + padX * 2, by + r, r);
      ctx.lineTo(bx + tw + padX * 2, by + bh - r);
      ctx.arcTo(bx + tw + padX * 2, by + bh, bx + tw + padX * 2 - r, by + bh, r);
      ctx.lineTo(bx + r, by + bh);
      ctx.arcTo(bx, by + bh, bx, by + bh - r, r);
      ctx.lineTo(bx, by + r);
      ctx.arcTo(bx, by, bx + r, by, r);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(sx - fs * 0.26, by + bh);
      ctx.lineTo(sx + fs * 0.26, by + bh);
      ctx.lineTo(sx, by + bh + fs * 0.52);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffd86b';
      ctx.fillText(e.taunt, sx, by + bh * 0.72);
      ctx.globalAlpha = 1;
    }

    // health pips
    if (e.health < e.maxHealth && w > 18) {
      const bw = w * 0.7;
      const bx = sx - bw / 2;
      const by = sy - w * 1.28;
      ctx.fillStyle = 'rgba(0,0,0,0.65)';
      ctx.fillRect(bx - 1, by - 1, bw + 2, 5 * this.res);
      const pct = Math.max(0, e.health / e.maxHealth);
      ctx.fillStyle = pct > 0.5 ? '#6ee36e' : pct > 0.25 ? '#ffd86b' : '#ff5a4d';
      ctx.fillRect(bx, by, bw * pct, 3 * this.res);
    }
  }

  private renderPlayer(seg: Segment, percent: number) {
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;
    const scale = this.cameraDepth / this.playerZ;
    const camY = lerp(seg.p1.camera.y, seg.p2.camera.y, percent);
    const baseY = H / 2 - scale * camY * (H / 2);
    const destY = baseY + this.bounce - H * 0.015;
    const destX = W / 2 + this.lean * W * 0.012;

    const set = this.bank.bikes.player;
    const pose: RiderPose =
      this.attackTimer > 0 ? (this.attackSide < 0 ? 'punchL' : 'punchR') : 'ride';
    const w = SPR_RATIO * ROAD_WIDTH * scale * (W / 2);

    const blink = this.invuln > 0 && Math.floor(this.time * 20) % 2 === 0;

    ctx.save();
    if (this.phase === 'dying') {
      ctx.translate(destX, destY - w * 0.5);
      ctx.rotate(this.crashRot);
      ctx.translate(-destX, -(destY - w * 0.5));
    }
    const swing: SwingAnim | undefined =
      this.attackTimer > 0
        ? {
            side: this.attackSide,
            p: 1 - this.attackTimer / this.swingTime,
            weapon: this.weapon,
            color: WEAPONS[this.weapon].color,
          }
        : undefined;

    if (blink) ctx.globalAlpha = 0.45;
    this.renderBike(set, scale, destX, destY, {
      lean: this.lean,
      susp: this.susp,
      wheel: this.wheelAngle,
      slip: this.slip,
      pose,
      hang: this.riderLean,
      clip: 0,
      braking: this.phase === 'playing' && this.input.down,
      swing,
      allowLod: false,
    });
    ctx.globalAlpha = 1;

    // kick: the boot thrusts out to the side
    if (this.kickTimer > 0) {
      const kp = 1 - this.kickTimer / KICK_TIME;
      const ext = Math.sin(Math.min(1, kp) * Math.PI);
      const dir = this.kickSide;
      const legLen = w * 0.46 * ext;
      const legY = destY - w * 0.32;
      ctx.save();
      ctx.translate(destX + dir * w * 0.12, legY);
      ctx.rotate(dir * 0.24 * ext);
      ctx.fillStyle = '#232a38';
      ctx.fillRect(0, -w * 0.06, legLen, w * 0.12);
      ctx.fillStyle = '#d8502a';
      ctx.fillRect(legLen - w * 0.1, -w * 0.1, w * 0.16, w * 0.2);
      if (ext > 0.5) {
        ctx.globalAlpha = 0.3 * ext;
        ctx.fillStyle = '#fff2c8';
        ctx.fillRect(legLen, -w * 0.1, w * 0.22, w * 0.2);
        ctx.globalAlpha = 1;
      }
      ctx.restore();
    }

    // Brake light bloom & twin titanium exhaust afterburners (rotated with bike lean)
    ctx.save();
    ctx.translate(destX, destY);
    ctx.rotate(this.lean);
    if (this.phase === 'playing' && this.input.down) {
      const ly = -w * 0.42;
      const bg = ctx.createRadialGradient(0, ly, w * 0.02, 0, ly, w * 0.26);
      bg.addColorStop(0, 'rgba(255, 220, 220, 0.95)');
      bg.addColorStop(0.35, 'rgba(255, 30, 50, 0.7)');
      bg.addColorStop(1, 'rgba(255, 0, 20, 0)');
      ctx.fillStyle = bg;
      ctx.beginPath();
      ctx.arc(0, ly, w * 0.26, 0, Math.PI * 2);
      ctx.fill();
    }
    if (this.boosting) {
      const fh = w * (0.24 + Math.random() * 0.18);
      for (const dir of [-1, 1]) {
        const ex = dir * w * 0.155;
        const ey = -w * 0.36;
        const fg = ctx.createLinearGradient(ex, ey, ex, ey + fh);
        fg.addColorStop(0, '#ffffff');
        fg.addColorStop(0.35, '#6ff0ff');
        fg.addColorStop(0.75, '#2b6cff');
        fg.addColorStop(1, 'rgba(43, 108, 255, 0)');
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.ellipse(ex, ey + fh * 0.42, w * 0.055, fh * 0.55, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();


    ctx.restore();
  }

  private renderParticles() {
    const ctx = this.ctx;
    for (const p of this.particles) {
      const a = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = p.kind === 'smoke' ? a * 0.5 : a;
      ctx.fillStyle = p.color;
      const s = p.size * (p.kind === 'smoke' ? 1 + (1 - a) * 2.5 : 1);
      ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
    }
    ctx.globalAlpha = 1;
  }

  private renderSpeedLines() {
    const amt = this.speedBlur;
    if (amt < 0.05) return;
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;
    ctx.save();
    ctx.strokeStyle = this.boosting ? '#9ef3ff' : '#ffffff';
    ctx.lineWidth = Math.max(1, 1.2 * this.res);
    ctx.globalAlpha = amt * (this.boosting ? 0.45 : 0.28);
    const cx = W / 2;
    const cy = H * 0.58;
    const n = 20;
    const tick = Math.floor(this.time * 30);
    for (let i = 0; i < n; i++) {
      const seed = (i * 71 + tick) % 97;
      const ang = (i / n) * Math.PI * 2 + (seed / 97) * 0.25;
      const r0 = W * (0.44 + (seed % 19) / 70);
      const r1 = r0 + W * 0.09 * (0.5 + amt);
      const y0 = cy + Math.sin(ang) * r0 * 0.62;
      if (y0 < H * 0.2) continue; // keep the skyline clean
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(ang) * r0, y0);
      ctx.lineTo(cx + Math.cos(ang) * r1, cy + Math.sin(ang) * r1 * 0.62);
      ctx.stroke();
    }
    ctx.restore();
  }

  private renderPopups() {
    const ctx = this.ctx;
    ctx.textAlign = 'center';
    for (const p of this.popups) {
      const a = Math.min(1, p.life / 0.35);
      const pop = p.life > p.maxLife - 0.1 ? 1.25 : 1;
      const size = Math.round(p.size * 22 * this.res * pop);
      ctx.globalAlpha = a;
      ctx.font = `900 ${size}px "Rajdhani", "Arial Black", sans-serif`;
      ctx.lineWidth = Math.max(2, 3 * this.res);
      ctx.strokeStyle = 'rgba(0,0,0,0.85)';
      ctx.strokeText(p.text, p.x, p.y);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text, p.x, p.y);
    }
    ctx.globalAlpha = 1;
  }

  /** Top-down mini-map: a ribbon of upcoming road with player + rival markers. */
  private renderMiniMap() {
    if (this.phase !== 'playing' && this.phase !== 'dying') return;
    const ctx = this.ctx;
    const W = this.W;
    const r = this.res;
    // compact strip in the top-centre
    const mapW = 130 * r;
    const mapH = 52 * r;
    const mx = W / 2 - mapW / 2;
    const my = 6 * r;
    const segs = this.segments;
    const nSegs = segs.length;
    const look = 22; // how many segments to look ahead

    // translucent background
    ctx.globalAlpha = 0.72;
    ctx.fillStyle = 'rgba(6,4,16,0.82)';
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.lineWidth = Math.max(1, r);
    ctx.beginPath();
    const br = 4 * r;
    ctx.moveTo(mx + br, my);
    ctx.lineTo(mx + mapW - br, my);
    ctx.arcTo(mx + mapW, my, mx + mapW, my + br, br);
    ctx.lineTo(mx + mapW, my + mapH - br);
    ctx.arcTo(mx + mapW, my + mapH, mx + mapW - br, my + mapH, br);
    ctx.lineTo(mx + br, my + mapH);
    ctx.arcTo(mx, my + mapH, mx, my + mapH - br, br);
    ctx.lineTo(mx, my + br);
    ctx.arcTo(mx, my, mx + br, my, br);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.globalAlpha = 1;

    // build road ribbon: a polyline from near the player out to horizon
    // x accumulates the curve, y steps down the map
    const baseIdx = Math.floor(this.position / SEGMENT_LENGTH);
    const pts: number[] = [];
    let cx = mapW / 2;
    for (let i = 0; i <= look; i++) {
      const idx = (baseIdx + i) % nSegs;
      const curve = segs[idx].curve;
      cx += curve * 0.42 * r; // accumulate curve into x
      cx = Math.max(10 * r, Math.min(mapW - 10 * r, cx));
      const cy = my + 6 * r + (i / look) * (mapH - 12 * r);
      pts.push(cx, cy);
    }

    // draw road strip
    const roadW = 10 * r;
    ctx.lineWidth = roadW;
    ctx.strokeStyle = 'rgba(120,130,160,0.45)';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(pts[0], pts[1]);
    for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
    ctx.stroke();

    // lane dashes
    ctx.lineWidth = Math.max(1, 1.5 * r);
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.setLineDash([3 * r, 4 * r]);
    ctx.beginPath();
    for (let i = 0; i < pts.length; i += 2) {
      const x = pts[i];
      if (i === 0) ctx.moveTo(x, pts[i + 1]);
      else ctx.lineTo(x, pts[i + 1]);
    }
    ctx.stroke();
    ctx.setLineDash([]);

    // draw the player marker near the bottom of the strip
    const playerMX = mapW / 2;
    const playerMY = my + mapH - 8 * r;
    ctx.fillStyle = '#ff8a3c';
    ctx.beginPath();
    ctx.moveTo(playerMX, playerMY - 5 * r);
    ctx.lineTo(playerMX - 4 * r, playerMY + 4 * r);
    ctx.lineTo(playerMX + 4 * r, playerMY + 4 * r);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = Math.max(1, r * 0.8);
    ctx.stroke();

    // rival markers projected onto the road ribbon
    const pz = this.playerWorldZ();
    for (const e of this.enemies) {
      if (!e.alive || e.state === 'crash') continue;
      const rel = e.racer ? e.dist - this.distance : wrapDelta(e.z - pz, this.trackLength);
      if (rel < -600 || rel > look * SEGMENT_LENGTH) continue;
      // find which segment index this enemy is at relative to the ribbon
      const eIdx = Math.floor(rel / SEGMENT_LENGTH);
      const fi = clamp(eIdx / look, 0, 1);
      // interpolate position on the road polyline
      const t0 = Math.floor(fi * (look - 1));
      const t1 = Math.min(t0 + 1, look - 1);
      const ft = (fi * (look - 1)) - t0;
      const ex = pts[t0 * 2] * (1 - ft) + pts[t1 * 2] * ft;
      const ey = pts[t0 * 2 + 1] * (1 - ft) + pts[t1 * 2 + 1] * ft;
      // lateral offset from road center
      const latOff = e.x * roadW * 0.45;
      const colours = e.type === 'cop' ? ['#3ba7ff', '#ff3344'] : ['#6fe08c', '#c48cff', '#ffe07a'];
      const col = e.dnf ? 'rgba(120,120,120,0.4)' : e.type === 'cop' ? colours[e.id % 2] : colours[e.colorIdx % 3];
      ctx.fillStyle = col;
      const dotR = e.dnf ? 2.2 * r : 3.2 * r;
      ctx.beginPath();
      ctx.arc(ex + latOff, ey, dotR, 0, Math.PI * 2);
      ctx.fill();
      if (!e.dnf) {
        ctx.strokeStyle = 'rgba(0,0,0,0.7)';
        ctx.lineWidth = Math.max(0.7, r * 0.6);
        ctx.stroke();
      }
    }
  }

  private renderOverlays(theme: Theme) {
    if (!this.running) return;
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;

    // damage vignette
    const hurt = this.health < 40 && this.phase !== 'over' ? (40 - this.health) / 40 : 0;
    if (hurt > 0) {
      const pulse = 0.35 + Math.sin(this.time * 6) * 0.15;
      const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.2, W / 2, H / 2, H * 0.78);
      g.addColorStop(0, 'rgba(255,0,0,0)');
      g.addColorStop(1, `rgba(190,10,10,${hurt * pulse})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }

    // generic vignette for depth
    const vg = ctx.createRadialGradient(W / 2, H * 0.5, H * 0.35, W / 2, H * 0.5, H * 0.95);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);

    if (this.flash > 0.01) {
      ctx.fillStyle = `rgba(${this.flashColor},${Math.min(0.45, this.flash)})`;
      ctx.fillRect(0, 0, W, H);
    }

    if (this.phase === 'playing' && this.runTime < 7) {
      const a = this.runTime < 5.5 ? 1 : 1 - (this.runTime - 5.5) / 1.5;
      ctx.globalAlpha = a;
      ctx.textAlign = 'center';
      const fs = Math.round(11 * this.res);
      ctx.font = `700 ${fs}px "Rajdhani", sans-serif`;
      const msg = this.touchHints && !this.keyboardDriving
        ? (this.autoGas && !this.keyboardDriving ? 'AUTO-GAS \u00b7 SLOW = BRAKE \u00b7 TAP HIT \u00b7 NOS = BOOST' : 'HOLD GAS \u00b7 SLOW = BRAKE \u00b7 HIT = NIGHTSTICK')
        : 'W / \u2191 GAS  \u00b7  S / \u2193 BRAKE  \u00b7  \u2190 \u2192 STEER  \u00b7  SPACE = NIGHTSTICK  \u00b7  SHIFT = NITRO';
      const y = H - (this.touchHints ? H * 0.28 : 10 * this.res);
      ctx.lineWidth = Math.max(2, 3 * this.res);
      ctx.strokeStyle = 'rgba(0,0,0,0.85)';
      ctx.strokeText(msg, W / 2, y);
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fillText(msg, W / 2, y);
      ctx.globalAlpha = 1;
    }

    // Stationary prompt: the bike won't move by itself, so tell the rider how.
    if (this.phase === 'playing' && this.idleTime > 0.6) {
      const pulse = 0.65 + Math.sin(this.time * 6) * 0.35;
      ctx.globalAlpha = pulse;
      ctx.textAlign = 'center';
      const fs = Math.round(16 * this.res);
      ctx.font = `900 ${fs}px "Rajdhani", "Arial Black", sans-serif`;
      const msg =
        this.touchHints && !this.keyboardDriving
          ? this.autoGas
            ? 'RELEASE SLOW TO RIDE'
            : 'HOLD  GAS  TO  RIDE'
          : 'HOLD  \u2191  /  W  TO  RIDE';
      const y = H * 0.42;
      ctx.lineWidth = Math.max(3, 4 * this.res);
      ctx.strokeStyle = 'rgba(0,0,0,0.9)';
      ctx.strokeText(msg, W / 2, y);
      ctx.fillStyle = '#8dff6a';
      ctx.fillText(msg, W / 2, y);
      ctx.globalAlpha = 1;
    }

    // cinematic slow-mo bars during a takedown
    if (this.timeScale < 1) {
      const amt = 1 - this.timeScale;
      const barH = H * 0.12 * amt;
      ctx.fillStyle = 'rgba(6,4,12,0.92)';
      ctx.fillRect(0, 0, W, barH);
      ctx.fillRect(0, H - barH, W, barH);
      ctx.globalAlpha = amt * 0.16;
      ctx.fillStyle = '#ff8a3c';
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }

    // equipped weapon chip, bottom-right
    if (this.phase === 'playing' && !this.grid) {
      const wp = WEAPONS[this.weapon];
      const fs = Math.round(11 * this.res);
      ctx.font = `900 ${fs}px "Rajdhani", "Arial Black", sans-serif`;
      ctx.textAlign = 'right';
      const tx = W - 10 * this.res;
      const ty = H - 14 * this.res;
      ctx.lineWidth = Math.max(2, fs * 0.26);
      ctx.strokeStyle = 'rgba(0,0,0,0.9)';
      ctx.strokeText(wp.name, tx, ty);
      ctx.fillStyle = wp.color;
      ctx.fillText(wp.name, tx, ty);
      if (this.weaponDur !== Infinity) {
        const max = WEAPON_DURABILITY[this.weapon];
        const pct = clamp(this.weaponDur / max, 0, 1);
        const bw = 62 * this.res;
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(tx - bw, ty + 5 * this.res, bw, 5 * this.res);
        ctx.fillStyle = pct > 0.5 ? '#8dff6a' : pct > 0.22 ? '#ffd86b' : '#ff5a4d';
        ctx.fillRect(tx - bw, ty + 5 * this.res, bw * pct, 5 * this.res);
      }
    }

    if (this.phase === 'playing') this.renderRaceStart();
    this.renderMiniMap();

    if (this.phase === 'attract') {
      ctx.fillStyle = 'rgba(8,6,18,0.45)';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = cssA(theme.sun, 0.07);
      ctx.fillRect(0, 0, W, H);
    }
  }
}
