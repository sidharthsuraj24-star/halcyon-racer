// Modern HD 2.5D procedural sprites for bikes, traffic vehicles, and roadside scenery.

import { buildBikeSet, type BikeSet } from './bike';

export interface Sprite {
  cv: HTMLCanvasElement;
  w: number;
  h: number;
  /** width as a fraction of the road width */
  ratio: number;
}

type Ctx = CanvasRenderingContext2D;

function make(w: number, h: number, ratio: number, draw: (c: Ctx) => void): Sprite {
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const c = cv.getContext('2d')!;
  c.imageSmoothingEnabled = true;
  draw(c);
  return { cv, w, h, ratio };
}

const px = (c: Ctx, x: number, y: number, w: number, h: number, color: string | CanvasGradient) => {
  c.fillStyle = color;
  c.fillRect(x, y, w, h);
};

function rrect(c: Ctx, x: number, y: number, w: number, h: number, r: number, color: string | CanvasGradient) {
  const rr = Math.min(r, w / 2, h / 2);
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(x + rr, y);
  c.arcTo(x + w, y, x + w, y + h, rr);
  c.arcTo(x + w, y + h, x, y + h, rr);
  c.arcTo(x, y + h, x, y, rr);
  c.arcTo(x, y, x + w, y, rr);
  c.closePath();
  c.fill();
}

const tri = (c: Ctx, pts: number[][], color: string | CanvasGradient) => {
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
  c.closePath();
  c.fill();
};

/* ------------------------------------------------------------------ bikes */

export interface RiderPalette {
  jacket: string;
  jacketDark: string;
  jacketLight: string;
  helmet: string;
  helmetStripe: string;
  bike: string;
  bikeDark: string;
  pants: string;
}

export const PLAYER_PAL: RiderPalette = {
  jacket: '#e04622',
  jacketDark: '#781d0a',
  jacketLight: '#ff9452',
  helmet: '#1b202e',
  helmetStripe: '#ffd23f',
  bike: '#262d3d',
  bikeDark: '#121620',
  pants: '#191e2b',
};

export const ENEMY_PALS: RiderPalette[] = [
  {
    // Venom Lime GP
    jacket: '#2cb852',
    jacketDark: '#145424',
    jacketLight: '#7aff98',
    helmet: '#14261a',
    helmetStripe: '#b6ff54',
    bike: '#1e2b24',
    bikeDark: '#0e1612',
    pants: '#17221b',
  },
  {
    // Ultraviolet Phantom
    jacket: '#8b46e0',
    jacketDark: '#421a75',
    jacketLight: '#d299ff',
    helmet: '#1f1333',
    helmetStripe: '#ff70ea',
    bike: '#241d36',
    bikeDark: '#110d1c',
    pants: '#1d172b',
  },
  {
    // Apex Solar Gold
    jacket: '#d99b1e',
    jacketDark: '#6e4a08',
    jacketLight: '#ffe47a',
    helmet: '#261e0c',
    helmetStripe: '#fff5b8',
    bike: '#2b261c',
    bikeDark: '#14120c',
    pants: '#221e16',
  },
  {
    // Cyber Cyan GP
    jacket: '#1798cc',
    jacketDark: '#0a4663',
    jacketLight: '#6ff0ff',
    helmet: '#102230',
    helmetStripe: '#84ffff',
    bike: '#1b2938',
    bikeDark: '#0d151f',
    pants: '#15202b',
  },
  {
    // Crimson Diablo
    jacket: '#cc1f3c',
    jacketDark: '#5e0b1b',
    jacketLight: '#ff7088',
    helmet: '#260e14',
    helmetStripe: '#ffb84d',
    bike: '#2b1a20',
    bikeDark: '#140b0e',
    pants: '#201418',
  },
  {
    // Titanium Stealth
    jacket: '#525c70',
    jacketDark: '#232833',
    jacketLight: '#9eabbf',
    helmet: '#181c26',
    helmetStripe: '#ff8a3c',
    bike: '#d44820',
    bikeDark: '#5e1b09',
    pants: '#1a1e28',
  },
];

export const COP_PAL: RiderPalette = {
  jacket: '#264b96',
  jacketDark: '#122652',
  jacketLight: '#72a6ff',
  helmet: '#f0f4fc',
  helmetStripe: '#264b96',
  bike: '#e6ecf7',
  bikeDark: '#6a758a',
  pants: '#182033',
};

/* --------------------------------------------------------------- vehicles */

const CAR_COLORS = ['#d83838', '#2978d9', '#e6b82e', '#46b058', '#dce2ed', '#8442cc'];

function carShade(hex: string, f: number) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.round(((n >> 16) & 255) * f));
  const g = Math.min(255, Math.round(((n >> 8) & 255) * f));
  const b = Math.min(255, Math.round((n & 255) * f));
  return `rgb(${r},${g},${b})`;
}

function drawCar(c: Ctx, color: string, front: boolean) {
  const dark = carShade(color, 0.55);
  const light = carShade(color, 1.28);

  // Soft shadow + wide performance tyres
  rrect(c, 8, 82, 112, 10, 5, 'rgba(8, 10, 16, 0.85)');
  rrect(c, 10, 68, 22, 22, 5, '#12151e');
  rrect(c, 96, 68, 22, 22, 5, '#12151e');

  // Sculpted lower body with vertical metallic gradient
  const bodyG = c.createLinearGradient(0, 40, 0, 82);
  bodyG.addColorStop(0, light);
  bodyG.addColorStop(0.25, color);
  bodyG.addColorStop(0.85, dark);
  bodyG.addColorStop(1, '#141720');
  rrect(c, 8, 40, 112, 40, 10, bodyG);

  // Tapered aerodynamic greenhouse / roof cabin
  const roofG = c.createLinearGradient(0, 12, 0, 44);
  roofG.addColorStop(0, light);
  roofG.addColorStop(0.5, color);
  roofG.addColorStop(1, dark);
  tri(
    c,
    [
      [28, 14],
      [100, 14],
      [114, 44],
      [14, 44],
    ],
    roofG,
  );

  // Windshield / rear glass with sky reflection
  const glassG = c.createLinearGradient(0, 18, 0, 42);
  glassG.addColorStop(0, front ? '#5578a3' : '#3a5270');
  glassG.addColorStop(0.5, front ? '#233347' : '#182230');
  glassG.addColorStop(1, '#0e141d');
  tri(
    c,
    [
      [32, 19],
      [96, 19],
      [106, 41],
      [22, 41],
    ],
    glassG,
  );
  // Diagonal glass reflection
  tri(c, [[38, 20], [52, 20], [42, 40], [28, 40]], 'rgba(255, 255, 255, 0.22)');

  if (front) {
    // Aggressive LED headlights + front splitter grille
    rrect(c, 14, 52, 24, 12, 4, '#fff4c2');
    rrect(c, 90, 52, 24, 12, 4, '#fff4c2');
    rrect(c, 16, 54, 20, 6, 2, '#ffffff');
    rrect(c, 92, 54, 20, 6, 2, '#ffffff');
    rrect(c, 42, 54, 44, 18, 5, '#141822');
    rrect(c, 46, 58, 36, 3, 1, '#4c566b');
  } else {
    // Modern LED tail light bar + diffuser + dual exhausts
    rrect(c, 14, 50, 26, 12, 4, '#ff1f3a');
    rrect(c, 88, 50, 26, 12, 4, '#ff1f3a');
    rrect(c, 17, 52, 20, 5, 2, '#ff9aa8');
    rrect(c, 91, 52, 20, 5, 2, '#ff9aa8');
    rrect(c, 40, 52, 48, 4, 2, '#d41930');
    rrect(c, 48, 60, 32, 11, 3, '#e4e9f2'); // license plate
    rrect(c, 10, 74, 108, 8, 3, '#1a1e29'); // rear diffuser
    rrect(c, 24, 75, 10, 6, 3, '#8e98ab');
    rrect(c, 94, 75, 10, 6, 3, '#8e98ab');
  }
}

function drawVan(c: Ctx, color: string, front: boolean) {
  const dark = carShade(color, 0.58);
  const light = carShade(color, 1.22);
  rrect(c, 8, 98, 112, 10, 4, 'rgba(8, 10, 16, 0.85)');
  rrect(c, 12, 84, 20, 22, 5, '#12151e');
  rrect(c, 96, 84, 20, 22, 5, '#12151e');

  const bodyG = c.createLinearGradient(0, 16, 0, 96);
  bodyG.addColorStop(0, light);
  bodyG.addColorStop(0.15, color);
  bodyG.addColorStop(0.85, dark);
  bodyG.addColorStop(1, '#181c26');
  rrect(c, 10, 16, 108, 80, 12, bodyG);

  if (front) {
    rrect(c, 20, 24, 88, 30, 6, '#263850');
    rrect(c, 24, 26, 80, 6, 3, '#52749c');
    rrect(c, 16, 66, 22, 14, 4, '#fff4c2');
    rrect(c, 90, 66, 22, 14, 4, '#fff4c2');
    rrect(c, 42, 68, 44, 14, 4, '#1b202b');
  } else {
    rrect(c, 20, 24, 88, 34, 6, '#1b2636');
    px(c, 62, 20, 4, 72, dark);
    rrect(c, 16, 66, 20, 14, 4, '#ff263d');
    rrect(c, 92, 66, 20, 14, 4, '#ff263d');
    rrect(c, 48, 70, 32, 10, 2, '#dfe5f0');
  }
  rrect(c, 10, 90, 108, 8, 3, '#222733');
}

function drawTruck(c: Ctx, front: boolean) {
  rrect(c, 4, 110, 136, 10, 4, 'rgba(8, 10, 16, 0.85)');
  rrect(c, 12, 92, 24, 24, 5, '#12151e');
  rrect(c, 108, 92, 24, 24, 5, '#12151e');

  const boxG = c.createLinearGradient(0, 8, 0, 98);
  boxG.addColorStop(0, '#ffffff');
  boxG.addColorStop(0.12, '#dfe5f0');
  boxG.addColorStop(0.85, '#9ea7b8');
  boxG.addColorStop(1, '#5c6475');
  rrect(c, 6, 8, 132, 90, 8, boxG);

  rrect(c, 14, 18, 116, 62, 4, '#c5cddb');
  px(c, 70, 18, 4, 62, '#8b94a6');
  rrect(c, 22, 30, 40, 16, 3, '#d8502a');
  rrect(c, 82, 30, 40, 16, 3, '#2f4e8f');

  if (front) {
    rrect(c, 18, 22, 108, 32, 5, '#263850');
    rrect(c, 12, 72, 24, 16, 4, '#fff4c2');
    rrect(c, 108, 72, 24, 16, 4, '#fff4c2');
    rrect(c, 44, 66, 56, 24, 4, '#252b38');
  } else {
    rrect(c, 12, 76, 22, 14, 4, '#ff263d');
    rrect(c, 110, 76, 22, 14, 4, '#ff263d');
  }
  rrect(c, 6, 96, 132, 8, 3, '#2b303b');
}

/* --------------------------------------------------------------- scenery */

function drawPine(c: Ctx) {
  px(c, 28, 74, 8, 22, '#4a3420');
  tri(c, [[32, 2], [8, 44], [56, 44]], '#1d5c38');
  tri(c, [[32, 14], [6, 60], [58, 60]], '#237044');
  tri(c, [[32, 30], [4, 80], [60, 80]], '#2b8550');
  tri(c, [[32, 14], [20, 60], [32, 60]], '#1a5334');
  tri(c, [[32, 30], [18, 80], [32, 80]], '#1f6440');
}

function drawTree(c: Ctx) {
  px(c, 28, 60, 9, 30, '#4a3420');
  px(c, 30, 60, 3, 30, '#6b4c2e');
  c.fillStyle = '#2c7d4b';
  c.beginPath();
  c.arc(32, 36, 26, 0, Math.PI * 2);
  c.arc(16, 46, 15, 0, Math.PI * 2);
  c.arc(48, 46, 15, 0, Math.PI * 2);
  c.fill();
  c.fillStyle = '#3fa164';
  c.beginPath();
  c.arc(26, 28, 16, 0, Math.PI * 2);
  c.fill();
  c.fillStyle = '#58c47d';
  c.beginPath();
  c.arc(24, 24, 8, 0, Math.PI * 2);
  c.fill();
}

function drawPalm(c: Ctx) {
  px(c, 26, 40, 7, 64, '#5b452a');
  for (let i = 0; i < 6; i++) px(c, 25, 48 + i * 10, 9, 3, '#7a603d');
  const fronds: number[][][] = [
    [[29, 40], [2, 22], [10, 40]],
    [[29, 40], [56, 20], [48, 40]],
    [[29, 40], [14, 6], [30, 24]],
    [[29, 40], [48, 6], [34, 24]],
    [[29, 40], [0, 44], [16, 44]],
    [[29, 40], [58, 44], [44, 44]],
  ];
  fronds.forEach((f, i) => tri(c, f, i % 2 ? '#2b8550' : '#237044'));
  px(c, 25, 34, 10, 8, '#8a5a2b');
}

function drawBillboard(c: Ctx) {
  px(c, 14, 46, 6, 34, '#4b5160');
  px(c, 52, 46, 6, 34, '#4b5160');
  px(c, 4, 4, 64, 44, '#1b1f2a');
  px(c, 7, 7, 58, 38, '#d8502a');
  px(c, 11, 12, 50, 8, '#ffe9c9');
  px(c, 11, 24, 32, 7, '#1b1f2a');
  px(c, 11, 34, 42, 6, '#ffb347');
  px(c, 4, 4, 64, 3, '#ffb347');
}

function drawSign(c: Ctx) {
  px(c, 17, 30, 6, 34, '#9aa2b1');
  tri(c, [[20, 0], [40, 20], [20, 40], [0, 20]], '#1b1f2a');
  tri(c, [[20, 3], [37, 20], [20, 37], [3, 20]], '#ffc83d');
  px(c, 17, 13, 6, 10, '#1b1f2a');
  tri(c, [[20, 6], [27, 15], [13, 15]], '#1b1f2a');
}

function drawSpeedSign(c: Ctx) {
  px(c, 15, 28, 6, 32, '#9aa2b1');
  px(c, 4, 2, 28, 30, '#1b1f2a');
  px(c, 7, 5, 22, 24, '#eef1f6');
  px(c, 10, 9, 5, 12, '#1b1f2a');
  px(c, 18, 9, 5, 12, '#1b1f2a');
  px(c, 10, 22, 13, 3, '#1b1f2a');
}

function drawBarrel(c: Ctx) {
  px(c, 4, 4, 22, 32, '#e2601f');
  px(c, 4, 10, 22, 6, '#f2f4f8');
  px(c, 4, 24, 22, 6, '#f2f4f8');
  px(c, 4, 4, 4, 32, '#a8420f');
  px(c, 22, 4, 4, 32, '#ff8f4d');
  px(c, 4, 2, 22, 4, '#ff8f4d');
}

function drawRock(c: Ctx) {
  tri(c, [[4, 36], [18, 6], [34, 36]], '#6f7686');
  tri(c, [[22, 36], [36, 14], [46, 36]], '#5a6170');
  tri(c, [[4, 36], [18, 6], [22, 36]], '#848c9d');
  px(c, 2, 33, 46, 4, '#454c5c');
}

function drawLamp(c: Ctx) {
  px(c, 10, 14, 5, 96, '#434a5a');
  px(c, 8, 106, 10, 6, '#2b303b');
  px(c, 10, 10, 20, 5, '#434a5a');
  px(c, 24, 14, 12, 5, '#ffe9a8');
  px(c, 25, 18, 10, 3, 'rgba(255,220,130,0.5)');
}

function drawCrate(c: Ctx) {
  px(c, 2, 6, 36, 30, '#8a6334');
  px(c, 2, 6, 36, 4, '#b07f45');
  px(c, 2, 32, 36, 4, '#5d4222');
  px(c, 16, 6, 6, 30, '#6f5029');
  px(c, 2, 18, 36, 5, '#6f5029');
}

/* ----------------------------------------------------------------- build */

export interface SpriteBank {
  /** High-resolution layered bikes: chassis, rider body, and horizon-leveled helmet. */
  bikes: { player: BikeSet; gang: BikeSet[]; cop: BikeSet };
  carsBack: Sprite[];
  carsFront: Sprite[];
  vanBack: Sprite[];
  vanFront: Sprite[];
  truckBack: Sprite;
  truckFront: Sprite;
  scenery: Record<string, Sprite>;
  sceneryKeys: string[];
}

let bank: SpriteBank | null = null;

/* ---- progressive asset build ------------------------------------------
 * Each BikeSet renders three 220x260 canvases, and the crash composite
 * re-draws the entire articulated rider — so building all eight liveries up
 * front blocked the main thread for long enough on a phone that the page sat
 * on a blank screen and looked like it had failed to load. We now build only
 * what attract mode needs, then stream the rest in one chunk per frame behind
 * a loading screen.
 */
let buildQueue: (() => void)[] = [];
let buildTotal = 0;
let buildDone = 0;

/** Build one queued asset. Returns 0..1 progress (1 = everything ready). */
export function stepSpriteBuild(): number {
  const step = buildQueue.shift();
  if (step) {
    step();
    buildDone++;
  }
  return buildTotal === 0 ? 1 : Math.min(1, buildDone / buildTotal);
}

export function spriteBuildPending(): number {
  return buildQueue.length;
}

export function getSprites(): SpriteBank {
  if (bank) return bank;
  const scenery: Record<string, Sprite> = {
    pine: make(64, 96, 0.44, drawPine),
    tree: make(64, 92, 0.42, drawTree),
    palm: make(60, 104, 0.4, drawPalm),
    billboard: make(72, 80, 0.46, drawBillboard),
    sign: make(40, 64, 0.22, drawSign),
    speedSign: make(36, 60, 0.2, drawSpeedSign),
    barrel: make(30, 38, 0.11, drawBarrel),
    rock: make(50, 38, 0.2, drawRock),
    lamp: make(40, 112, 0.22, drawLamp),
    crate: make(40, 38, 0.15, drawCrate),
  };
  // Player livery doubles as the placeholder for rivals until theirs stream in,
  // so every array index is always a valid BikeSet and nothing needs null checks.
  const playerSet = buildBikeSet(PLAYER_PAL);
  const gang: BikeSet[] = ENEMY_PALS.map(() => playerSet);
  const copSet = buildBikeSet(COP_PAL);

  buildQueue = ENEMY_PALS.map((pal, i) => () => {
    gang[i] = buildBikeSet(pal);
  });
  buildTotal = buildQueue.length;
  buildDone = 0;

  bank = {
    bikes: {
      player: playerSet,
      gang,
      cop: copSet,
    },
    carsBack: CAR_COLORS.map((col) => make(128, 96, 0.26, (c) => drawCar(c, col, false))),
    carsFront: CAR_COLORS.map((col) => make(128, 96, 0.26, (c) => drawCar(c, col, true))),
    vanBack: CAR_COLORS.map((col) => make(128, 112, 0.29, (c) => drawVan(c, col, false))),
    vanFront: CAR_COLORS.map((col) => make(128, 112, 0.29, (c) => drawVan(c, col, true))),
    truckBack: make(144, 128, 0.36, (c) => drawTruck(c, false)),
    truckFront: make(144, 128, 0.36, (c) => drawTruck(c, true)),
    scenery,
    sceneryKeys: Object.keys(scenery),
  };
  return bank;
}
