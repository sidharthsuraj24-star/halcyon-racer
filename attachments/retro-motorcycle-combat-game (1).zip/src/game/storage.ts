import type { ScoreEntry } from './types';

const KEY = 'roadfury.scores.v1';
const NAME_KEY = 'roadfury.name';
const MUTE_KEY = 'roadfury.muted';
const TILT_KEY = 'roadfury.tilt';
const AUTOGAS_KEY = 'roadfury.autogas';
const CONTROLS_KEY = 'roadfury.controls'; // 'buttons' | 'tilt'
const STEER_SENS_KEY = 'roadfury.steersens';

export function loadSteerSensitivity() {
  try {
    const v = parseFloat(localStorage.getItem(STEER_SENS_KEY) || '1');
    return Number.isFinite(v) ? Math.max(0.6, Math.min(1.8, v)) : 1;
  } catch {
    return 1;
  }
}

export function saveSteerSensitivity(v: number) {
  try {
    localStorage.setItem(STEER_SENS_KEY, String(v));
  } catch {
    /* ignore */
  }
}

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((e) => typeof e?.score === 'number')
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);
  } catch {
    return [];
  }
}

export function saveScore(entry: ScoreEntry): ScoreEntry[] {
  const all = [...loadScores(), entry].sort((a, b) => b.score - a.score).slice(0, 8);
  try {
    localStorage.setItem(KEY, JSON.stringify(all));
  } catch {
    /* ignore */
  }
  return all;
}

export function isHighScore(score: number) {
  const all = loadScores();
  return score > 0 && (all.length < 8 || score > all[all.length - 1].score);
}

export function loadName() {
  try {
    return localStorage.getItem(NAME_KEY) || 'RSH';
  } catch {
    return 'RSH';
  }
}

export function saveName(n: string) {
  try {
    localStorage.setItem(NAME_KEY, n);
  } catch {
    /* ignore */
  }
}

export function loadMuted() {
  try {
    return localStorage.getItem(MUTE_KEY) === '1';
  } catch {
    return false;
  }
}

export function saveMuted(m: boolean) {
  try {
    localStorage.setItem(MUTE_KEY, m ? '1' : '0');
  } catch {
    /* ignore */
  }
}

/* ---- mobile settings ---- */

export function loadTiltSensitivity() {
  try {
    return Math.max(0.3, Math.min(2, parseFloat(localStorage.getItem(TILT_KEY) || '1')));
  } catch {
    return 1;
  }
}

export function saveTiltSensitivity(v: number) {
  try {
    localStorage.setItem(TILT_KEY, String(v));
  } catch {
    /* ignore */
  }
}

export function loadAutoGas() {
  try {
    return localStorage.getItem(AUTOGAS_KEY) !== '0';
  } catch {
    return true;
  }
}

export function saveAutoGas(v: boolean) {
  try {
    localStorage.setItem(AUTOGAS_KEY, v ? '1' : '0');
  } catch {
    /* ignore */
  }
}

export function loadControlScheme() {
  try {
    return (localStorage.getItem(CONTROLS_KEY) || 'buttons') as 'buttons' | 'tilt';
  } catch {
    return 'buttons';
  }
}

export function saveControlScheme(v: 'buttons' | 'tilt') {
  try {
    localStorage.setItem(CONTROLS_KEY, v);
  } catch {
    /* ignore */
  }
}