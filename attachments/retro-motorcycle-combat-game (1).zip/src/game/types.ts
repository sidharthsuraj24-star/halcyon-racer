export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface SegPoint {
  world: Vec3;
  camera: Vec3;
  screen: { x: number; y: number; w: number; scale: number };
}

export interface RoadSprite {
  kind: string;
  offset: number;
}

export interface Segment {
  index: number;
  p1: SegPoint;
  p2: SegPoint;
  curve: number;
  sprites: RoadSprite[];
  ents: Entity[];
  clip: number;
  fog: number;
  looped: boolean;
  dark: boolean; // alternating tarmac shade
  lane: boolean; // dashed lane marker on this segment
}

export type EntityKind = 'traffic' | 'enemy' | 'pickup';

export interface BaseEntity {
  kind: EntityKind;
  z: number;
  x: number;
  alive: boolean;
}

export interface Traffic extends BaseEntity {
  kind: 'traffic';
  speed: number;
  dir: 1 | -1; // 1 = same direction, -1 = oncoming
  body: 'car' | 'van' | 'truck';
  colorIdx: number;
  drift: number;
  passed: boolean;
}

export type EnemyState = 'ride' | 'wind' | 'punch' | 'stun' | 'crash';

export interface Enemy extends BaseEntity {
  kind: 'enemy';
  id: number;
  type: 'gang' | 'cop';
  colorIdx: number;
  speed: number;
  vx: number;
  health: number;
  maxHealth: number;
  state: EnemyState;
  timer: number;
  cooldown: number;
  side: number;
  hitFlash: number;
  lean: number;
  punchSide: 1 | -1;
  crashRot: number;
  crashTime: number;
  bob: number;
  aggression: number;
  /** Race rival (lined up on the starting grid) vs. a roaming gang/cop. */
  racer: boolean;
  name: string;
  /** Cumulative forward distance — used to rank the race. */
  dist: number;
  /** Cruising pace as a fraction of MAX_SPEED. */
  pace: number;
  /** >0 while this racer is deliberately picking a fight with the player. */
  engage: number;
  /** Knocked out of the race by the player (did not finish). */
  dnf: boolean;
  /** Speech-bubble taunt, shown while winding up a punch. */
  taunt: string;
  tauntT: number;
  /** Rival's own weapon. */
  weapon: WeaponKind;
  /* tyre + suspension state, so rivals lean and slide like real riders */
  vLat: number;
  grip: number;
  slip: number;
  susp: number;
  wheel: number;
  hang: number;
}

export interface Pickup extends BaseEntity {
  kind: 'pickup';
  type: 'repair' | 'nitro' | 'weapon';
  phase: number;
  /** Only set when type === 'weapon'. */
  weapon: WeaponKind;
}

/** Road Rash style melee weapons, each with its own reach, damage and speed. */
export type WeaponKind = 'bat' | 'chain' | 'wrench';

export interface WeaponStats {
  name: string;
  /** Swing arc length multiplier — chain has the longest reach. */
  reach: number;
  /** Damage multiplier. */
  power: number;
  /** Seconds per swing. */
  swing: number;
  /** Knockback multiplier on hit. */
  knock: number;
  color: string;
}

export const WEAPONS: Record<WeaponKind, WeaponStats> = {
  bat: { name: 'NIGHTSTICK', reach: 1, power: 1, swing: 0.36, knock: 1, color: '#aab3c2' },
  chain: { name: 'STEEL CHAIN', reach: 1.45, power: 1.15, swing: 0.46, knock: 0.8, color: '#d6dde8' },
  wrench: { name: 'DIRT WRENCH', reach: 0.82, power: 1.75, swing: 0.58, knock: 1.7, color: '#c8781f' },
};

export type Entity = Traffic | Enemy | Pickup;

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  gravity: number;
  kind: 'spark' | 'smoke' | 'debris' | 'dust';
}

export interface Popup {
  x: number;
  y: number;
  vy: number;
  life: number;
  maxLife: number;
  text: string;
  color: string;
  size: number;
}

export interface HudState {
  speedKph: number;
  speedPct: number;
  health: number;
  score: number;
  distance: number;
  takedowns: number;
  combo: number;
  boost: number;
  wanted: number;
  offroad: boolean;
  weapon: string;
  weaponPower: number;
  /** Tyre traction 0..1 — falls when you ask for more cornering than grip allows. */
  grip: number;
  /** Race position (1 = leading). */
  position: number;
  /** Riders in the race, including the player. */
  field: number;
  /** Seconds left on the start countdown, or -1 once the race is underway. */
  countdown: number;
  /** Officers currently in pursuit (0..4). */
  cops: number;
}

export interface RunResult {
  score: number;
  distance: number;
  takedowns: number;
  bestCombo: number;
  time: number;
  cause: string;
  position: number;
  field: number;
  overtakes: number;
}

export interface ScoreEntry {
  name: string;
  score: number;
  distance: number;
  takedowns: number;
  date: number;
}
