// Haptic feedback for mobile devices using the Vibration API.
// Falls back gracefully on devices that don't support it.

function vibrate(pattern: number | number[]) {
  try {
    if (navigator.vibrate) navigator.vibrate(pattern);
  } catch {
    /* noop */
  }
}

export const haptic = {
  light() { vibrate(8); },
  medium() { vibrate(15); },
  heavy() { vibrate([20, 10, 30]); },
  hit() { vibrate([10, 8, 20]); },
  knockout() { vibrate([30, 15, 50, 15, 25]); },
  crash() { vibrate([50, 20, 40, 20, 60]); },
  pickup() { vibrate([5, 10, 5]); },
  ui() { vibrate(4); },
  boost() { vibrate([8, 4, 12, 4, 8]); },
};