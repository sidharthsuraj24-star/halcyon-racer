// Modern HD 2.5D procedural superbike + articulated rear-view rider renderer.
//
// Designed specifically for a 3rd-person rear chase camera:
// - True rear-perspective 200mm sportbike slick tyre (cylindrical rubber shading +
//   scrolling V-tread sipes, gold chain, edge-on brake rotor & gullwing swingarm —
//   no sideways spokes painted onto the rear tread).
// - True rear-view aerodynamic full-face helmet (glossy 3D shell, crown stripes,
//   rear aero spoiler & exhaust vents — no front visor on the back of the head).
// - Fully connected IK-style rider limbs: hands stay locked onto the clip-on
//   handlebar grips and boots stay planted on the footpegs at every lean & hang-off
//   angle, while the inside knee extends smoothly into corners.

import type { RiderPalette } from './sprites';
import { clamp, lerp } from './util';

type Ctx = CanvasRenderingContext2D;

export interface Sprite {
  cv: HTMLCanvasElement;
  w: number;
  h: number;
  ratio: number;
}

export const SPR_W = 220;
export const SPR_H = 260;
export const SPR_RATIO = 0.19;
/** Contact patch of the rear tyre in sprite space — the lean pivot. */
export const CONTACT_X = 110;
export const CONTACT_Y = 242;

export const LEAN_STEPS = 9;
export const LEAN_MAX = 0.52; // radians, ~30 degrees

export const LEAN_ANGLES: number[] = Array.from(
  { length: LEAN_STEPS },
  (_, i) => ((i / (LEAN_STEPS - 1)) * 2 - 1) * LEAN_MAX,
);

export function leanIndex(lean: number): number {
  return clamp(Math.round(((clamp(lean / LEAN_MAX, -1, 1) + 1) / 2) * (LEAN_STEPS - 1)), 0, LEAN_STEPS - 1);
}

// Key anchor points in bike-local coordinates (origin = rear tyre contact patch (0, 0))
export const HANDLEBAR_L: [number, number] = [-50, -141];
export const HANDLEBAR_R: [number, number] = [50, -141];
export const FOOTPEG_L: [number, number] = [-36, -60];
export const FOOTPEG_R: [number, number] = [36, -60];

function makeCanvas(): [HTMLCanvasElement, Ctx] {
  const cv = document.createElement('canvas');
  cv.width = SPR_W;
  cv.height = SPR_H;
  const c = cv.getContext('2d')!;
  c.imageSmoothingEnabled = true;
  return [cv, c];
}

function rrectPath(c: Ctx, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  c.beginPath();
  c.moveTo(x + rr, y);
  c.arcTo(x + w, y, x + w, y + h, rr);
  c.arcTo(x + w, y + h, x, y + h, rr);
  c.arcTo(x, y + h, x, y, rr);
  c.arcTo(x, y, x + w, y, rr);
  c.closePath();
}

function rrect(
  c: Ctx,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  fill: string | CanvasGradient,
  stroke?: string,
  lw = 1.4,
) {
  c.fillStyle = fill;
  rrectPath(c, x, y, w, h, r);
  c.fill();
  if (stroke) {
    c.strokeStyle = stroke;
    c.lineWidth = lw;
    c.stroke();
  }
}

function ell(
  c: Ctx,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  fill: string | CanvasGradient,
  stroke?: string,
  lw = 1.4,
) {
  c.fillStyle = fill;
  c.beginPath();
  c.ellipse(cx, cy, Math.max(0.5, rx), Math.max(0.5, ry), 0, 0, Math.PI * 2);
  c.fill();
  if (stroke) {
    c.strokeStyle = stroke;
    c.lineWidth = lw;
    c.stroke();
  }
}

function poly(c: Ctx, pts: number[][], fill: string | CanvasGradient, stroke?: string, lw = 1.5) {
  c.fillStyle = fill;
  c.beginPath();
  c.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
  c.closePath();
  c.fill();
  if (stroke) {
    c.strokeStyle = stroke;
    c.lineWidth = lw;
    c.lineJoin = 'round';
    c.stroke();
  }
}

function capsule(
  c: Ctx,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  r1: number,
  r2: number,
  fill: string | CanvasGradient,
  stroke?: string,
  lw = 1.6,
) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const ang = Math.atan2(dy, dx);

  c.beginPath();
  c.arc(x1, y1, r1, ang + Math.PI / 2, ang - Math.PI / 2, false);
  c.lineTo(x2 - nx * r2, y2 - ny * r2);
  c.arc(x2, y2, r2, ang - Math.PI / 2, ang + Math.PI / 2, false);
  c.closePath();
  c.fillStyle = fill;
  c.fill();
  if (stroke) {
    c.strokeStyle = stroke;
    c.lineWidth = lw;
    c.stroke();
  }
}

/* ----------------------------------------------------- bike front/mid */

/**
 * Forward & mid chassis parts (drawn BEHIND the rider):
 * front forks, smoked aero windscreen, digital dash, clip-on handlebars,
 * brake/clutch levers, stealth mirrors, sculpted front/side fairings, winglets,
 * fuel tank, lower engine/frame spars, and twin upswept titanium exhausts.
 */
export function drawBikeFront(c: Ctx, p: RiderPalette) {
  const cx = CONTACT_X;
  const cy = CONTACT_Y;

  // ---- Gold USD front fork tubes peeking behind handlebars
  const forkG = c.createLinearGradient(cx - 22, 0, cx + 22, 0);
  forkG.addColorStop(0, '#7c6222');
  forkG.addColorStop(0.5, '#f2d06b');
  forkG.addColorStop(1, '#7c6222');
  rrect(c, cx - 21, cy - 156, 6, 54, 3, forkG);
  rrect(c, cx + 15, cy - 156, 6, 54, 3, forkG);

  // ---- Smoked racing windscreen bubble
  const screenG = c.createLinearGradient(cx, cy - 190, cx, cy - 150);
  screenG.addColorStop(0, 'rgba(175, 225, 255, 0.52)');
  screenG.addColorStop(0.45, 'rgba(26, 42, 66, 0.78)');
  screenG.addColorStop(1, 'rgba(10, 14, 22, 0.94)');
  poly(
    c,
    [
      [cx - 23, cy - 152],
      [cx - 16, cy - 183],
      [cx, cy - 190],
      [cx + 16, cy - 183],
      [cx + 23, cy - 152],
    ],
    screenG,
    'rgba(200, 235, 255, 0.4)',
    1.4,
  );
  poly(
    c,
    [
      [cx - 11, cy - 156],
      [cx - 5, cy - 183],
      [cx + 1, cy - 183],
      [cx - 4, cy - 156],
    ],
    'rgba(255, 255, 255, 0.24)',
  );

  // ---- TFT dash glow
  rrect(c, cx - 13, cy - 164, 26, 11, 3, '#0a0f18');
  rrect(c, cx - 11, cy - 162, 22, 7, 2, '#2be4ff');

  // ---- Clip-on handlebars, levers & bar-end stealth mirrors (angled down naturally)
  c.strokeStyle = '#9aa5ba';
  c.lineWidth = 2.4;
  c.lineCap = 'round';
  c.beginPath();
  c.moveTo(cx - 38, cy - 150);
  c.lineTo(cx - 63, cy - 144);
  c.moveTo(cx + 38, cy - 150);
  c.lineTo(cx + 63, cy - 144);
  c.stroke();

  // Clip-on tubes
  capsule(c, cx - 18, cy - 154, cx - 63, cy - 139, 4, 4.5, '#2b313f', '#0d1017', 1.4);
  capsule(c, cx + 18, cy - 154, cx + 63, cy - 139, 4, 4.5, '#2b313f', '#0d1017', 1.4);
  // Rubber grips + anodized bar-ends
  capsule(c, cx - 40, cy - 146, cx - 63, cy - 139, 5, 5, '#141720');
  capsule(c, cx + 40, cy - 146, cx + 63, cy - 139, 5, 5, '#141720');
  ell(c, cx - 65, cy - 138.5, 3.5, 4.5, p.helmetStripe, '#0d1017', 1);
  ell(c, cx + 65, cy - 138.5, 3.5, 4.5, p.helmetStripe, '#0d1017', 1);

  // Fairing-mounted aero mirrors
  c.strokeStyle = '#202532';
  c.lineWidth = 3.2;
  c.beginPath();
  c.moveTo(cx - 32, cy - 160);
  c.lineTo(cx - 56, cy - 172);
  c.moveTo(cx + 32, cy - 160);
  c.lineTo(cx + 56, cy - 172);
  c.stroke();
  poly(
    c,
    [
      [cx - 73, cy - 175],
      [cx - 52, cy - 178],
      [cx - 49, cy - 170],
      [cx - 69, cy - 168],
    ],
    '#161a24',
    '#454f66',
    1.3,
  );
  poly(
    c,
    [
      [cx + 73, cy - 175],
      [cx + 52, cy - 178],
      [cx + 49, cy - 170],
      [cx + 69, cy - 168],
    ],
    '#161a24',
    '#454f66',
    1.3,
  );
  poly(c, [[cx - 70, cy - 174], [cx - 54, cy - 176], [cx - 52, cy - 171], [cx - 67, cy - 170]], '#5d84b5');
  poly(c, [[cx + 70, cy - 174], [cx + 54, cy - 176], [cx + 52, cy - 171], [cx + 67, cy - 170]], '#5d84b5');

  // ---- Wide aerodynamic front/side fairings & MotoGP downforce winglets
  // High-contrast metallic gunmetal/team-bike finish so the rider silhouette pops cleanly
  const fairG = c.createLinearGradient(cx - 46, cy - 165, cx + 46, cy - 90);
  fairG.addColorStop(0, p.bikeDark);
  fairG.addColorStop(0.28, p.bike);
  fairG.addColorStop(0.5, '#59657d');
  fairG.addColorStop(0.72, p.bike);
  fairG.addColorStop(1, p.bikeDark);

  poly(
    c,
    [
      [cx - 25, cy - 166],
      [cx - 45, cy - 142],
      [cx - 41, cy - 98],
      [cx - 26, cy - 78],
      [cx + 26, cy - 78],
      [cx + 41, cy - 98],
      [cx + 45, cy - 142],
      [cx + 25, cy - 166],
    ],
    fairG,
    '#0d1017',
    2,
  );

  // Carbon aero winglets on outer fairings
  poly(
    c,
    [
      [cx - 43, cy - 135],
      [cx - 57, cy - 127],
      [cx - 53, cy - 119],
      [cx - 41, cy - 123],
    ],
    '#181c26',
    p.helmetStripe,
    1.3,
  );
  poly(
    c,
    [
      [cx + 43, cy - 135],
      [cx + 57, cy - 127],
      [cx + 53, cy - 119],
      [cx + 41, cy - 123],
    ],
    '#181c26',
    p.helmetStripe,
    1.3,
  );

  // Dark mechanical engine / frame cradle & rearset brackets
  poly(
    c,
    [
      [cx - 34, cy - 104],
      [cx - 38, cy - 60],
      [cx - 22, cy - 48],
      [cx + 22, cy - 48],
      [cx + 38, cy - 60],
      [cx + 34, cy - 104],
    ],
    '#151821',
    '#2d3445',
    1.5,
  );

  // Aluminum footpegs & heel guards
  for (const dir of [-1, 1]) {
    const px = cx + dir * 36;
    const py = cy - 60;
    poly(
      c,
      [
        [px - dir * 6, py - 2],
        [px - dir * 10, py - 18],
        [px - dir * 3, py - 16],
        [px - dir * 1, py],
      ],
      '#6c768a',
      '#141720',
      1,
    );
    capsule(c, px - dir * 4, py, px + dir * 9, py, 2.8, 2.5, '#aeb8cc', '#11141c', 1);
  }

  // ---- Twin upswept hexagonal titanium/carbon exhaust canisters
  for (const dir of [-1, 1]) {
    const exX = cx + dir * 31;
    const exY = cy - 78;
    const canG = c.createLinearGradient(exX - 10, exY, exX + 10, exY);
    canG.addColorStop(0, '#323847');
    canG.addColorStop(0.35, '#d4ddeb');
    canG.addColorStop(0.68, '#8590a6');
    canG.addColorStop(1, '#222734');

    c.save();
    c.translate(exX, exY);
    c.rotate(dir * -0.13);
    // Stainless link pipe
    rrect(c, -4.5, 8, 9, 20, 3, '#8c7a65', '#151820', 1);
    // Hexagonal muffler body
    rrect(c, -9.5, -18, 19, 30, 5, canG, '#0e1118', 1.5);
    // Titanium heat-blue weld band
    rrect(c, -9, -11, 18, 4, 1, 'rgba(75, 145, 255, 0.42)');
    // Carbon conical end-cap & dark outlet bore
    poly(c, [[-9.5, -15], [-6.5, -24], [6.5, -24], [9.5, -15]], '#181b24', '#0b0d13', 1.2);
    ell(c, 0, -19.5, 5, 3.2, '#07080c', '#3c4354', 1);
    // Carbon hanger strap
    rrect(c, -10.5, -3, 21, 3.5, 1, '#1d222e');
    c.restore();
  }

  // ---- Sculpted muscular fuel tank ahead of saddle
  const tankG = c.createLinearGradient(cx - 26, cy - 156, cx + 26, cy - 116);
  tankG.addColorStop(0, p.bikeDark);
  tankG.addColorStop(0.28, p.bike);
  tankG.addColorStop(0.5, '#687691');
  tankG.addColorStop(0.72, p.bike);
  tankG.addColorStop(1, p.bikeDark);
  poly(
    c,
    [
      [cx - 18, cy - 156],
      [cx - 27, cy - 138],
      [cx - 22, cy - 112],
      [cx + 22, cy - 112],
      [cx + 27, cy - 138],
      [cx + 18, cy - 156],
    ],
    tankG,
    '#0d1017',
    1.6,
  );
  rrect(c, cx - 3.5, cy - 155, 7, 40, 2, p.helmetStripe);
}

/* ----------------------------------------------------- rear wheel & tail */

export interface WheelOpts {
  cx: number;
  cy: number;
  rx: number;
  ry: number;
  angle: number;
  slip: number;
  squash: number;
  rear?: boolean;
}

/**
 * True rear-perspective motorcycle tyre + chain + brake disc + swingarm.
 * Viewed from behind, you see the fat curved rubber slick crown & scrolling
 * tread sipes (NEVER sideways bicycle spokes painted onto the back of the tyre!).
 */
export function drawWheel(c: Ctx, o: WheelOpts) {
  const squash = clamp(o.squash, -0.32, 0.32);
  const ry = o.ry * (1 - squash * 0.34);
  const rx = o.rx * (1 + squash * 0.42);
  const isRear = o.rear !== false;

  c.save();
  c.translate(o.cx, o.cy + o.ry * squash * 0.34);

  if (isRear) {
    // ---- Edge-on Rear Sprocket & Gold Drive Chain (left) + Brake Disc & Caliper (right)
    rrect(c, -rx * 1.24, -ry * 0.38, rx * 0.24, ry * 0.74, 2, '#586175', '#0e1118', 1);
    rrect(c, -rx * 1.2, -ry * 0.42, rx * 0.14, ry * 0.82, 2, '#d4a647'); // gold chain
    // Edge-on steel brake rotor & crimson Brembo caliper on right
    rrect(c, rx * 1.0, -ry * 0.36, rx * 0.14, ry * 0.72, 2, '#aeb8cc', '#141821', 1);
    rrect(c, rx * 1.04, -ry * 0.26, rx * 0.24, ry * 0.3, 3, '#d92b3a', '#11131a', 1);

    // ---- Brushed Aluminum Gullwing Swingarm & Axle Blocks flanking the tyre
    const swG = c.createLinearGradient(-rx * 1.45, 0, rx * 1.45, 0);
    swG.addColorStop(0, '#5a6378');
    swG.addColorStop(0.2, '#c5cfdf');
    swG.addColorStop(0.8, '#c5cfdf');
    swG.addColorStop(1, '#5a6378');
    rrect(c, -rx * 1.44, -ry * 0.18, rx * 0.46, ry * 0.34, 3, swG, '#10131c', 1.2);
    rrect(c, rx * 0.98, -ry * 0.18, rx * 0.46, ry * 0.34, 3, swG, '#10131c', 1.2);
  }

  // ---- Fat 200mm Rear Sportbike Slick Tyre Profile (cylindrical horizontal shading!)
  const tyreW = rx * 2;
  const tyreH = ry * 2;
  const cylG = c.createLinearGradient(-rx, 0, rx, 0);
  cylG.addColorStop(0, '#07080d');
  cylG.addColorStop(0.18, '#171b24');
  cylG.addColorStop(0.5, o.slip > 0.3 ? '#3b3739' : '#2e3444');
  cylG.addColorStop(0.82, '#171b24');
  cylG.addColorStop(1, '#07080d');

  c.save();
  rrectPath(c, -rx, -ry, tyreW, tyreH, rx * 0.88);
  c.fillStyle = cylG;
  c.fill();
  c.clip();

  // Top & bottom vertical curvature falloff (3D torus shading)
  const vertG = c.createLinearGradient(0, -ry, 0, ry);
  vertG.addColorStop(0, 'rgba(4, 5, 10, 0.82)');
  vertG.addColorStop(0.25, 'rgba(0, 0, 0, 0)');
  vertG.addColorStop(0.75, 'rgba(0, 0, 0, 0)');
  vertG.addColorStop(1, 'rgba(4, 5, 10, 0.72)');
  c.fillStyle = vertG;
  c.fillRect(-rx, -ry, tyreW, tyreH);

  // Subtle center slick wear band
  c.fillStyle = 'rgba(15, 18, 25, 0.32)';
  c.fillRect(-rx * 0.32, -ry, rx * 0.64, tyreH);

  // Scrolling Pirelli Diablo Supercorsa lightning/chevron tread sipes
  const grooves = 6;
  const phase = (((o.angle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2)) / (Math.PI * 2);
  c.strokeStyle = '#0a0c12';
  c.lineWidth = Math.max(1.3, rx * 0.11);
  c.lineCap = 'round';
  for (let i = 0; i < grooves; i++) {
    const t = ((i / grooves + phase) % 1) * 2 - 1;
    // Perspective foreshortening around the tyre circumference
    const y = Math.sin(t * (Math.PI * 0.48)) * ry * 0.94;
    const vis = Math.cos(t * (Math.PI * 0.48));
    if (vis < 0.2) continue;
    const span = rx * 0.82;
    c.globalAlpha = 0.75 * vis;
    c.beginPath();
    c.moveTo(-span, y - ry * 0.08 * vis);
    c.lineTo(-span * 0.24, y + ry * 0.06 * vis);
    c.moveTo(span, y - ry * 0.08 * vis);
    c.lineTo(span * 0.24, y + ry * 0.06 * vis);
    c.stroke();
  }
  c.globalAlpha = 1;
  c.restore();

  // Crisp outer tyre outline
  rrectPath(c, -rx, -ry, tyreW, tyreH, rx * 0.88);
  c.strokeStyle = '#07080d';
  c.lineWidth = 1.5;
  c.stroke();

  if (isRear) {
    // Carbon-fiber rear tyre hugger mudguard arch over top of the rear slick
    poly(
      c,
      [
        [-rx * 1.06, -ry * 0.68],
        [-rx * 0.82, -ry * 1.04],
        [rx * 0.82, -ry * 1.04],
        [rx * 1.06, -ry * 0.68],
        [rx * 0.86, -ry * 0.82],
        [-rx * 0.86, -ry * 0.82],
      ],
      '#181c26',
      '#343c4f',
      1.1,
    );
  }

  c.restore();
}

/**
 * Draws the pointed MotoGP / Streetfighter rear tail cowl & glowing twin-blade
 * LED tail light assembly that projects BEHIND the rider's seat, right over the
 * rear wheel!
 */
export function drawTailCowl(c: Ctx, p: RiderPalette, braking: boolean) {
  // Coordinates in bike-local space (origin = rear tyre contact patch (0, 0))
  // Sits at y = -115 .. -84, overlapping the base of the rider's saddle!
  const tailG = c.createLinearGradient(-24, -116, 24, -86);
  tailG.addColorStop(0, p.bikeDark);
  tailG.addColorStop(0.28, p.bike);
  tailG.addColorStop(0.5, p.jacket);
  tailG.addColorStop(0.72, p.bike);
  tailG.addColorStop(1, p.bikeDark);

  // Black sculpted seat pan bolster cradling the rider's hips
  poly(
    c,
    [
      [-23, -120],
      [23, -120],
      [25, -108],
      [-25, -108],
    ],
    '#151822',
    '#0b0d14',
    1.4,
  );

  // Pointed aerodynamic rear cowl with Ducati/R1 open wing tunnels
  poly(
    c,
    [
      [-24, -112],
      [-26, -98],
      [-16, -86],
      [16, -86],
      [26, -98],
      [24, -112],
    ],
    tailG,
    '#0b0d14',
    1.8,
  );

  // Dark aero tunnel vents on left & right of tail cowl
  poly(c, [[-22, -107], [-15, -107], [-13, -93], [-20, -95]], '#0d1018');
  poly(c, [[22, -107], [15, -107], [13, -93], [20, -95]], '#0d1018');

  // Center tail fin spine
  rrect(c, -3, -112, 6, 16, 2, p.helmetStripe);

  // Recessed LED tail light housing at the trailing tip of the tail
  rrect(c, -15, -96, 30, 10, 3.5, '#140508', '#090a10', 1.2);
  const ledCol = braking ? '#ff384c' : '#d9162d';
  const ledCore = braking ? '#ffffff' : '#ff8a98';
  poly(c, [[-13, -94], [-3, -92.5], [-3, -88.5], [-13, -90]], ledCol);
  poly(c, [[13, -94], [3, -92.5], [3, -88.5], [13, -90]], ledCol);
  poly(c, [[-11, -92.8], [-4, -91.8], [-4, -90.2], [-11, -91.2]], ledCore);
  poly(c, [[11, -92.8], [4, -91.8], [4, -90.2], [11, -91.2]], ledCore);
}

/* ------------------------------------------------ rear-view helmet */

/**
 * True REAR-VIEW aerodynamic racing helmet (centered at (110, 110) on a 220x220
 * mini-sprite or at (CONTACT_X, 42) on SPR_W x SPR_H).
 * NO front visor on the back of the head! Shows glossy 3D dome, crown racing
 * stripes, rear aero spoiler fin, twin rear exhaust vents, and padded neck roll.
 */
export function drawHelmetRear(c: Ctx, p: RiderPalette) {
  const cx = CONTACT_X;
  const cy = 42;

  // Padded neoprene neck roll & helmet base skirt
  ell(c, cx, cy + 16, 16, 7, '#10131c', '#07090e', 1.4);

  // 3D spherical glossy helmet shell lit from upper-left (true rear view)
  const shellG = c.createRadialGradient(cx - 7, cy - 9, 2, cx, cy + 2, 24);
  shellG.addColorStop(0, '#5a6680');
  shellG.addColorStop(0.28, p.helmet);
  shellG.addColorStop(0.82, '#0d1018');
  shellG.addColorStop(1, '#06070c');

  c.save();
  rrectPath(c, cx - 19.5, cy - 20, 39, 37, 18);
  c.fillStyle = shellG;
  c.fill();
  c.clip();

  // Clean twin longitudinal racing stripes curving over the top-to-back of the helmet
  rrect(c, cx - 6, cy - 21, 4.2, 33, 1.5, p.helmetStripe);
  rrect(c, cx + 1.8, cy - 21, 4.2, 33, 1.5, p.helmetStripe);
  rrect(c, cx - 1.8, cy - 21, 3.6, 33, 1, p.jacket);

  // Subtle rear aero spoiler lip & lower rubber gasket trim
  poly(
    c,
    [
      [cx - 13, cy + 5],
      [cx, cy + 7.5],
      [cx + 13, cy + 5],
      [cx + 11, cy + 10],
      [cx, cy + 12],
      [cx - 11, cy + 10],
    ],
    '#171c28',
  );
  rrect(c, cx - 20, cy + 12.5, 40, 5, 2, '#0d1018');

  // Crisp glossy clear-coat highlight arc on upper-left crown
  c.fillStyle = 'rgba(255, 255, 255, 0.42)';
  c.beginPath();
  c.ellipse(cx - 8.5, cy - 9.5, 6, 2.8, -0.5, 0, Math.PI * 2);
  c.fill();
  c.restore();

  // Crisp outer shell contour
  rrectPath(c, cx - 19.5, cy - 20, 39, 37, 18);
  c.strokeStyle = '#07090e';
  c.lineWidth = 2;
  c.stroke();
}

/* ------------------------------------------- live articulated rider */

export type RiderPose = 'ride' | 'punchL' | 'punchR';

/**
 * Draws the rider live in bike-local space so every limb stays 100% physically
 * connected to the handlebars and footpegs while the hips, knee-down leg,
 * armored leather jacket torso, and rear-view helmet articulate smoothly!
 */
export interface SwingAnim {
  side: 1 | -1;
  /** 0..1 progress through swing */
  p: number;
  weapon: 'bat' | 'chain' | 'wrench';
  color: string;
}

export function drawArticulatedRider(
  c: Ctx,
  set: BikeSet,
  lean: number,
  hang: number,
  pose: RiderPose,
  braking: boolean,
  swing?: SwingAnim,
) {
  const p = set.palette;
  const h = clamp(hang, -0.85, 0.85);

  // Hip shifts slightly across the saddle; shoulders shift further into the apex
  const hipX = h * 9;
  const hipY = -117;
  const shX = h * 18;
  const shY = -173;

  // ---- 1. Articulated Legs (Hip -> Knee w/ Slider -> Shin -> Racing Boot on Footpeg)
  for (const dir of [-1, 1] as const) {
    const pegX = dir * 36;
    const pegY = -60;
    const hJointX = hipX + dir * 15;
    const hJointY = hipY + 3;

    // Inside knee swings out cleanly into a MotoGP knee-down; outside knee hugs tank
    const insideTurn = clamp((dir * lean) / LEAN_MAX, 0, 1);
    const outsideTurn = clamp((-dir * lean) / LEAN_MAX, 0, 1);
    const kneeX = dir * (28 + insideTurn * 20 - outsideTurn * 4) + h * 4;
    const kneeY = -114 + insideTurn * 12;

    // Thigh (hip -> knee)
    capsule(c, hJointX, hJointY, kneeX, kneeY, 11.5, 9.5, p.pants, '#0c0e15', 1.6);
    // Outer thigh racing stripe
    capsule(
      c,
      hJointX + dir * 4,
      hJointY - 1,
      kneeX + dir * 3,
      kneeY - 1,
      2.2,
      1.8,
      p.jacketLight,
    );

    // Shin (knee -> boot ankle on peg)
    capsule(c, kneeX, kneeY, pegX, pegY - 6, 9, 7.5, '#181c28', '#0b0d14', 1.5);

    // Carbon/colored knee slider puck right on the outside of the knee
    c.save();
    c.translate(kneeX + dir * 6.5, kneeY + 1);
    c.rotate(dir * (0.2 + insideTurn * 0.32));
    ell(c, 0, 0, 5, 8.5, '#141720', '#090b10', 1.2);
    ell(c, dir * 1, 0, 2.6, 5, p.helmetStripe);
    c.restore();

    // Armored racing boot planted squarely on the footpeg
    c.save();
    c.translate(pegX, pegY);
    rrect(c, -8.5, -16, 17, 23, 5.5, '#141822', '#080a10', 1.5);
    rrect(c, -7, -12, 14, 4.5, 2, p.helmetStripe); // ankle brace
    rrect(c, -6.5, -3, 13, 6, 2.5, '#2e3546'); // heel cup
    c.restore();
  }

  // ---- 2. Rider Pelvis / Leather Seat Base
  const hipG = c.createLinearGradient(hipX - 23, hipY, hipX + 23, hipY);
  hipG.addColorStop(0, '#0f121a');
  hipG.addColorStop(0.5, p.pants);
  hipG.addColorStop(1, '#0f121a');
  ell(c, hipX, hipY + 3, 22.5, 15, hipG, '#0a0c12', 1.6);

  // ---- 3. Pointed Rear Tail Cowl & LED Tail Light (projects BEHIND the saddle!)
  drawTailCowl(c, p, braking);

  // ---- 4. Connected Arms, Armored Elbows & Gloved Hands Locked onto Handlebars
  for (const dir of [-1, 1] as const) {
    const sJointX = shX + dir * 26;
    const sJointY = shY + 7;
    const isSwingingWeapon = swing && swing.side === dir;
    const isPunching = isSwingingWeapon || (dir === -1 && pose === 'punchL') || (dir === 1 && pose === 'punchR');

    if (isPunching) {
      // Dynamic windup -> horizontal strike arc!
      const prog = isSwingingWeapon ? swing.p : 0.55;
      const armAng = lerp(-1.15, 0.25, Math.min(1, prog * 1.3)) * dir;
      const elbX = sJointX + dir * 28 + Math.sin(armAng) * 8;
      const elbY = sJointY + 2 - Math.cos(armAng) * 10;
      const fistX = elbX + dir * 34 * Math.cos(armAng * 0.45);
      const fistY = elbY - 12 * Math.cos(prog * Math.PI);

      // Dark charcoal leather racing sleeve for sharp contrast
      capsule(c, sJointX, sJointY, elbX, elbY, 10, 8.2, '#1f2432', '#0b0d14', 1.6);
      capsule(c, elbX, elbY, fistX, fistY, 8.2, 6.8, '#171b26', '#0b0d14', 1.6);
      capsule(c, sJointX + dir * 2, sJointY, elbX + dir * 2, elbY, 2.5, 2, p.jacketLight);
      ell(c, elbX, elbY, 6, 4.8, '#282f40', '#0b0d14', 1);

      // If swinging a weapon, draw the weapon & motion trail directly in the rider's hand!
      if (isSwingingWeapon) {
        const wLen = swing.weapon === 'chain' ? 88 : swing.weapon === 'wrench' ? 66 : 74;
        const wThick = 6.5;
        const wAng = lerp(-2.05, 0.48, Math.min(1, prog * 1.25)) * dir;
        c.save();
        c.translate(fistX, fistY);
        c.rotate(wAng);

        // Motion-blur swing arc trail
        const trailAlpha = 0.28 * Math.max(0, 1 - Math.abs(prog - 0.45) * 2.1);
        if (trailAlpha > 0.02) {
          c.globalAlpha = trailAlpha;
          c.strokeStyle = '#ffffff';
          c.lineWidth = wThick * 1.7;
          c.lineCap = 'round';
          c.beginPath();
          c.arc(0, 0, wLen * 0.82, -0.8 * dir, 0.12 * dir, dir < 0);
          c.stroke();
          c.globalAlpha = 1;
        }

        const wc = swing.color;
        if (swing.weapon === 'chain') {
          c.strokeStyle = wc;
          c.lineWidth = 4.2;
          for (let i = 0; i < 7; i++) {
            const lx = (wLen * i) / 6;
            c.beginPath();
            c.ellipse(lx, 0, 4.2, 6.5, 0, 0, Math.PI * 2);
            c.stroke();
          }
        } else if (swing.weapon === 'wrench') {
          rrect(c, -6, -wThick * 0.45, wLen, wThick * 0.9, 2, wc, '#0d1017', 1.2);
          ell(c, wLen, 0, wThick * 1.5, wThick * 1.5, wc, '#0d1017', 1.2);
          ell(c, wLen, 0, wThick * 0.7, wThick * 0.7, '#161a24');
        } else {
          // Police/street nightstick with side handle & steel tip
          rrect(c, -8, -wThick * 0.5, wLen, wThick, 2.5, '#1d212b', '#090b10', 1.2);
          rrect(c, wLen * 0.72, -wThick * 0.62, wLen * 0.22, wThick * 1.24, 2, wc);
          rrect(c, -8, -wThick * 0.6, 15, wThick * 1.2, 2, '#d9b066');
        }
        c.restore();
      }

      // Armored gauntlet + fist gripping weapon
      rrect(c, fistX - 8, fistY - 8, 16, 16, 5, '#141720', '#090b10', 1.4);
      ell(c, fistX + dir * 4, fistY, 5, 5.5, '#2b3242', '#0b0d14', 1);
    } else {
      // Natural bent-elbow motorcycle posture: upper arm drops down & out to elbow,
      // forearm angles forward & in to the gloved hand locked on the clip-on grip!
      const [gx, gy] = dir === -1 ? HANDLEBAR_L : HANDLEBAR_R;
      const elbX = lerp(sJointX, gx, 0.68) + dir * 7;
      const elbY = gy + 6;

      // Gloved hand wrapping the handlebar grip
      ell(c, gx, gy, 7.5, 6.5, '#13161f', '#080a10', 1.3);
      // Forearm (elbow -> glove on handlebar)
      capsule(c, elbX, elbY, gx, gy, 7.8, 6.2, '#171b26', '#0b0d14', 1.5);
      // Muscular upper arm (shoulder -> bent elbow) in dark leather sleeve w/ team stripe
      capsule(c, sJointX, sJointY, elbX, elbY, 10.2, 8.2, '#212636', '#0b0d14', 1.6);
      capsule(
        c,
        sJointX + dir * 2.5,
        sJointY + 1,
        elbX + dir * 2,
        elbY - 1,
        2.4,
        1.8,
        p.jacketLight,
      );
      // Molded carbon elbow slider cup
      ell(c, elbX + dir * 2, elbY + 1, 5.5, 4.8, '#2b3244', '#0a0c12', 1.1);
    }
  }

  // ---- 5. Sculpted V-Taper Armored Leather Jacket (Torso Back)
  const torsoG = c.createLinearGradient(shX - 32, shY, hipX + 26, hipY);
  torsoG.addColorStop(0, p.jacketDark);
  torsoG.addColorStop(0.24, p.jacket);
  torsoG.addColorStop(0.5, p.jacketLight);
  torsoG.addColorStop(0.76, p.jacket);
  torsoG.addColorStop(1, p.jacketDark);

  c.beginPath();
  c.moveTo(shX - 22, shY - 6);
  c.quadraticCurveTo(shX, shY - 10, shX + 22, shY - 6);
  c.quadraticCurveTo(shX + 33, shY - 1, shX + 31, shY + 11);
  c.quadraticCurveTo(lerp(shX + 28, hipX + 20, 0.55), lerp(shY + 14, hipY, 0.5), hipX + 20, hipY - 2);
  c.quadraticCurveTo(hipX, hipY + 4, hipX - 20, hipY - 2);
  c.quadraticCurveTo(lerp(shX - 28, hipX - 20, 0.55), lerp(shY + 14, hipY, 0.5), shX - 31, shY + 11);
  c.quadraticCurveTo(shX - 33, shY - 1, shX - 22, shY - 6);
  c.closePath();
  c.fillStyle = torsoG;
  c.fill();
  c.strokeStyle = '#0b0e15';
  c.lineWidth = 2;
  c.stroke();

  // Dark Kevlar side-rib panels & kidney belt waist trim
  const midLX = lerp(shX - 27, hipX - 19, 0.5);
  const midRX = lerp(shX + 27, hipX + 19, 0.5);
  const midY = lerp(shY + 10, hipY - 3, 0.5);
  poly(
    c,
    [
      [shX - 29, shY + 11],
      [midLX, midY],
      [hipX - 19, hipY - 3],
      [hipX - 13, hipY - 2],
      [shX - 21, shY + 11],
    ],
    p.jacketDark,
  );
  poly(
    c,
    [
      [shX + 29, shY + 11],
      [midRX, midY],
      [hipX + 19, hipY - 3],
      [hipX + 13, hipY - 2],
      [shX + 21, shY + 11],
    ],
    p.jacketDark,
  );

  // Snug leather waist / kidney belt with racing accent
  capsule(c, hipX - 17, hipY - 4, hipX + 17, hipY - 4, 4.5, 4.5, '#171b26', '#0a0c12', 1.2);
  capsule(c, hipX - 10, hipY - 4, hipX + 10, hipY - 4, 2, 2, p.helmetStripe);

  // Bold racing livery chevron across upper back
  const axisX = (shX - hipX) * 0.25;
  poly(
    c,
    [
      [shX - 25, shY + 6],
      [shX - axisX * 0.2, shY + 15],
      [shX + 25, shY + 6],
      [shX + 23, shY + 12],
      [shX - axisX * 0.2, shY + 21],
      [shX - 23, shY + 12],
    ],
    p.helmetStripe,
  );

  // Sleek, clean MotoGP aerodynamic speed-hump (smooth shaded teardrop, no ladder bars!)
  const spineBotX = lerp(shX, hipX, 0.68);
  const spineBotY = lerp(shY, hipY, 0.68);
  const humpG = c.createLinearGradient(shX - 10, shY, shX + 10, shY);
  humpG.addColorStop(0, p.jacketDark);
  humpG.addColorStop(0.5, p.jacketLight);
  humpG.addColorStop(1, p.jacketDark);
  capsule(c, shX, shY + 3, spineBotX, spineBotY, 9.5, 4.5, humpG, 'rgba(12,15,22,0.65)', 1.2);

  // Titanium/carbon shoulder armor sliders on left & right deltoids
  for (const dir of [-1, 1] as const) {
    c.save();
    c.translate(shX + dir * 27, shY + 3);
    c.rotate(dir * 0.28);
    ell(c, 0, 0, 8.5, 6, '#171b26', '#090b10', 1.2);
    ell(c, -dir * 1, -0.8, 5, 3, '#b8c3d6');
    c.restore();
  }

  // ---- 6. True Rear-View Full-Face Racing Helmet (horizon-leveled around neck!)
  const neckX = shX + h * 2.5;
  const neckY = shY - 14;
  c.save();
  c.translate(neckX, neckY);
  // Counter-rotate slightly against bike lean so rider keeps eyes level with horizon
  c.rotate(-lean * 0.34);
  c.drawImage(set.helmet.cv, -CONTACT_X, -48);
  c.restore();
}

/* ------------------------------------------------------------------ bank */

export interface BikeSet {
  chassis: Sprite;
  helmet: Sprite;
  crashFull: Sprite;
  palette: RiderPalette;
}

export function buildBikeSet(p: RiderPalette): BikeSet {
  const mk = (draw: (c: Ctx) => void): Sprite => {
    const [cv, c] = makeCanvas();
    draw(c);
    return { cv, w: SPR_W, h: SPR_H, ratio: SPR_RATIO };
  };

  const chassis = mk((c) => drawBikeFront(c, p));
  const helmet = mk((c) => drawHelmetRear(c, p));
  const setPartial = { chassis, helmet, crashFull: chassis, palette: p };

  // Pre-rendered composite used only when tumbling in a wipeout crash
  const crashFull = mk((c) => {
    c.drawImage(chassis.cv, 0, 0);
    c.save();
    c.translate(CONTACT_X, CONTACT_Y);
    drawWheel(c, { cx: 0, cy: -48, rx: 21, ry: 46, angle: 0, slip: 0, squash: 0, rear: true });
    drawArticulatedRider(c, setPartial, 0, 0, 'ride', false);
    c.restore();
  });

  return {
    chassis,
    helmet,
    crashFull,
    palette: p,
  };
}
