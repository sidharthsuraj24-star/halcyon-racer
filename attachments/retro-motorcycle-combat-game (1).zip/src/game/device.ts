// Device capability detection and adaptive quality settings.

export interface DeviceProfile {
  isMobile: boolean;
  isTablet: boolean;
  hasGyro: boolean;
  isLowEnd: boolean;
  maxPixelRatio: number;
  drawDistance: number;
  maxParticles: number;
  enableScanlines: boolean;
  enableCrt: boolean;
}

function detectLowEnd(): boolean {
  // Heuristic: check if device has low RAM or few cores
  const nav = navigator as Navigator & { deviceMemory?: number; hardwareConcurrency?: number };
  const mem = nav.deviceMemory ?? 4;
  const cores = nav.hardwareConcurrency ?? 4;
  return mem <= 2 || cores <= 2;
}

function detectMobile(): boolean {
  if (typeof window === 'undefined') return false;
  return /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
    (navigator.maxTouchPoints > 1 && window.innerWidth < 1024);
}

function detectTablet(): boolean {
  if (typeof window === 'undefined') return false;
  return /iPad|Android(?!.*Mobile)/i.test(navigator.userAgent) ||
    (navigator.maxTouchPoints > 1 && window.innerWidth >= 768 && window.innerWidth < 1400);
}

const _isMobile = detectMobile();
const _isLowEnd = detectLowEnd();

export const device: DeviceProfile = {
  isMobile: _isMobile,
  isTablet: detectTablet(),
  hasGyro: typeof DeviceOrientationEvent !== 'undefined',
  isLowEnd: _isLowEnd,
  // Phones ship dpr 2.5–3.5. Backing every one of those pixels costs far more
  // than the sharpness is worth on a ~6" screen, so cap hard: this alone cuts
  // the mobile framebuffer by ~60% versus the old 2.5 ceiling.
  maxPixelRatio: _isLowEnd ? 1 : _isMobile ? 1.5 : 2.5,
  drawDistance: _isLowEnd ? 110 : _isMobile ? 140 : 210,
  maxParticles: _isLowEnd ? 90 : _isMobile ? 150 : 320,
  enableScanlines: !_isMobile,
  enableCrt: !_isMobile && !_isLowEnd,
};

/** Internal render target area (CSS px²) before the dpr multiply. */
export const RENDER_AREA = _isLowEnd ? 240 * 440 : _isMobile ? 320 * 580 : 400 * 740;
/** Bikes drawn narrower than this use the cheap cached composite (LOD). */
export const BIKE_LOD_MIN_PX = _isMobile ? 46 : 34;

// Request gyro permission (iOS 13+ requires user gesture)
export async function requestGyroPermission(): Promise<boolean> {
  const DOE = DeviceOrientationEvent as unknown as {
    requestPermission?: () => Promise<'granted' | 'denied'>;
  };
  if (typeof DOE.requestPermission === 'function') {
    try {
      const result = await DOE.requestPermission();
      return result === 'granted';
    } catch {
      return false;
    }
  }
  // Non-iOS devices just work
  return true;
}