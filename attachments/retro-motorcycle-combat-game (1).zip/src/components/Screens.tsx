import type { RunResult, ScoreEntry } from '../game/types';

function Overlay({
  children,
  dim = 'rgba(6,4,12,0.72)',
  z = 40,
}: {
  children: React.ReactNode;
  dim?: string;
  z?: number;
}) {
  return (
    <div
      className="absolute inset-0 flex items-center justify-center overflow-y-auto p-3"
      style={{ background: dim, backdropFilter: 'blur(3px)', zIndex: z }}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------- boot / load */

const BOOT_LINES = [
  'IGNITION COIL .......... OK',
  'FUEL INJECTION ......... OK',
  'TYRE GRIP MODEL ........ OK',
  'RIVAL LIVERIES ......... ',
  'TRACK GEOMETRY ......... OK',
  'PIT LANE TELEMETRY ..... OK',
];

/**
 * Arcade-cabinet power-on self-test. Gives a slow phone something to look at
 * while the HD bike art streams in, instead of a blank screen that reads as
 * "the game did not open".
 */
export function BootScreen({ pct }: { pct: number }) {
  const done = Math.floor(pct * (BOOT_LINES.length - 1));
  return (
    <div className="boot-screen absolute inset-0 z-[70] flex flex-col justify-end overflow-hidden p-5 sm:p-8">
      <div className="boot-stripes" aria-hidden />
      <div className="relative">
        <div className="font-display text-[8px] tracking-[0.42em] text-rash-cyan/70">ARCADE SYSTEM BOARD</div>
        <h1
          className="title-glow mt-2 font-display text-[22px] leading-none text-rash-orange sm:text-[34px]"
          style={{ letterSpacing: '-0.02em' }}
        >
          ROAD FURY
        </h1>
        <div className="mt-1 font-display text-[9px] tracking-[0.28em] text-white/55">JAILBREAK RUN</div>

        {/* tachometer-style loader */}
        <div className="mt-5 h-3 w-full max-w-[420px] overflow-hidden rounded-sm border border-white/15 bg-black/70">
          <div
            className="boot-tacho h-full"
            style={{ width: `${Math.max(4, pct * 100)}%` }}
            role="progressbar"
            aria-valuenow={Math.round(pct * 100)}
            aria-valuemin={0}
            aria-valuemax={100}
          />
        </div>

        <div className="mt-4 space-y-1 font-hud text-[11px] leading-tight tracking-[0.12em] sm:text-[12px]">
          {BOOT_LINES.map((line, i) => {
            const state = i < done ? 'ok' : i === done ? 'busy' : 'idle';
            return (
              <div
                key={line}
                className={
                  state === 'ok'
                    ? 'text-rash-lime/80'
                    : state === 'busy'
                      ? 'anim-pulse text-rash-orange'
                      : 'text-white/20'
                }
              >
                <span className="mr-2 text-white/25">{String(i + 1).padStart(2, '0')}</span>
                {line}
                {state === 'ok' && <span className="ml-1">OK</span>}
                {state === 'busy' && <span className="ml-1">BUILDING</span>}
              </div>
            );
          })}
        </div>

        <div className="mt-5 font-display text-[9px] tabular-nums text-white/40">
          {String(Math.round(pct * 100)).padStart(3, '0')}%
          <span className="ml-3 tracking-[0.2em] text-white/25">WARMING UP THE ENGINE</span>
        </div>
      </div>
    </div>
  );
}

function Key({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex min-w-[22px] items-center justify-center rounded border border-white/25 bg-white/10 px-1.5 py-0.5 font-display text-[8px] text-white/90">
      {children}
    </span>
  );
}

export function ScoreTable({ scores, highlight }: { scores: ScoreEntry[]; highlight?: number }) {
  return (
    <div className="w-full">
      <div className="mb-1 flex items-center gap-2">
        <span className="font-display text-[9px] tracking-wider text-rash-cyan">TOP RIDERS</span>
        <div className="h-px flex-1 bg-gradient-to-r from-rash-cyan/50 to-transparent" />
      </div>
      {scores.length === 0 ? (
        <div className="py-2 text-center text-[11px] tracking-widest text-white/35">NO RECORDS — BE THE FIRST</div>
      ) : (
        <ol className="space-y-0.5">
          {scores.slice(0, 5).map((s, i) => {
            const hot = highlight !== undefined && s.score === highlight;
            return (
              <li
                key={`${s.date}-${i}`}
                className={`flex items-center gap-2 rounded px-1.5 py-0.5 text-[12px] tabular-nums ${
                  hot ? 'bg-rash-orange/20 ring-1 ring-rash-orange/50' : i % 2 ? 'bg-white/[0.03]' : ''
                }`}
              >
                <span className="w-4 font-display text-[8px] text-white/40">{i + 1}</span>
                <span className="w-12 font-display text-[9px] text-rash-orange">{s.name}</span>
                <span className="flex-1 text-right font-semibold text-white">{s.score.toLocaleString('en-US')}</span>
                <span className="w-16 text-right text-[10px] text-white/45">{s.distance.toLocaleString('en-US')}m</span>
                <span className="w-9 text-right text-[10px] text-white/45">{s.takedowns} KO</span>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}

/* ---------------------------------------------------------- Settings */

function SensitivitySlider({
  label,
  hint,
  value,
  min,
  max,
  step,
  accent,
  onChange,
}: {
  label: string;
  hint: string;
  value: number;
  min: number;
  max: number;
  step: number;
  accent: string;
  onChange: (v: number) => void;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="mb-3">
      <div className="mb-1.5 flex items-center justify-between">
        <div>
          <div className="text-[10px] font-semibold tracking-[0.2em] text-white/70">{label}</div>
          <div className="text-[9px] text-white/35">{hint}</div>
        </div>
        <span className="font-display text-[11px]" style={{ color: accent }}>
          {value.toFixed(1)}×
        </span>
      </div>
      <div className="relative flex h-6 items-center">
        {/* filled track */}
        <div className="absolute inset-x-0 h-1.5 rounded-full bg-white/10">
          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: accent }} />
        </div>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="relative z-10 w-full appearance-none bg-transparent
            [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:appearance-none
            [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-black/60
            [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:shadow-lg
            [&::-moz-range-thumb]:h-5 [&::-moz-range-thumb]:w-5 [&::-moz-range-thumb]:rounded-full
            [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-black/60 [&::-moz-range-thumb]:bg-white"
          style={{ touchAction: 'none' }}
        />
      </div>
      <div className="mt-0.5 flex justify-between text-[8px] tracking-widest text-white/25">
        <span>SLUGGISH</span>
        <span>TWITCHY</span>
      </div>
    </div>
  );
}

export function SettingsPanel({
  controlScheme,
  autoGas,
  tiltSensitivity,
  steerSensitivity,
  isMobile,
  onChangeScheme,
  onChangeAutoGas,
  onChangeTilt,
  onChangeSteer,
  onClose,
}: {
  controlScheme: 'buttons' | 'tilt';
  autoGas: boolean;
  tiltSensitivity: number;
  steerSensitivity: number;
  isMobile: boolean;
  onChangeScheme: (s: 'buttons' | 'tilt') => void;
  onChangeAutoGas: (v: boolean) => void;
  onChangeTilt: (v: number) => void;
  onChangeSteer: (v: number) => void;
  onClose: () => void;
}) {
  const tiltLabel =
    tiltSensitivity < 0.7 ? 'GENTLE' : tiltSensitivity < 1.2 ? 'BALANCED' : tiltSensitivity < 1.6 ? 'SHARP' : 'HAIR-TRIGGER';
  const steerLabel =
    steerSensitivity < 0.85 ? 'CRUISE' : steerSensitivity < 1.15 ? 'BALANCED' : steerSensitivity < 1.45 ? 'SPORT' : 'ARCADE';
  return (
    <Overlay dim="rgba(6,4,12,0.92)" z={60}>
      <div className="anim-pop panel w-full max-w-[380px] rounded-lg p-4 sm:p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-[14px] text-rash-cyan neon-cyan">HANDLING</h2>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded font-display text-[12px] text-white/50 hover:bg-white/10 hover:text-white"
            aria-label="Close settings"
          >
            ✕
          </button>
        </div>

        {/* Steering sensitivity — applies to EVERY input method */}
        <SensitivitySlider
          label="STEERING SPEED"
          hint={`How fast the bike cuts across the road · ${steerLabel}`}
          value={steerSensitivity}
          min={0.6}
          max={1.8}
          step={0.1}
          accent="#ff8a3c"
          onChange={onChangeSteer}
        />

        {isMobile && (
          <>
            {/* Control scheme */}
            <div className="mb-3">
              <div className="mb-1.5 text-[10px] font-semibold tracking-[0.2em] text-white/50">STEERING INPUT</div>
              <div className="flex gap-2">
                {(['buttons', 'tilt'] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => onChangeScheme(s)}
                    className={`flex-1 rounded py-2 text-center font-display text-[10px] uppercase transition ${
                      controlScheme === s
                        ? 'bg-rash-orange text-black'
                        : 'bg-white/10 text-white/60 hover:bg-white/15'
                    }`}
                  >
                    {s === 'buttons' ? '◄ ► PAD' : '◢ TILT'}
                  </button>
                ))}
              </div>
            </div>

            {/* Tilt sensitivity — tilt scheme only */}
            {controlScheme === 'tilt' && (
              <SensitivitySlider
                label="TILT RANGE"
                hint={`Degrees of tilt needed to turn · ${tiltLabel}`}
                value={tiltSensitivity}
                min={0.4}
                max={2}
                step={0.1}
                accent="#6ff0ff"
                onChange={onChangeTilt}
              />
            )}

            {/* Auto-gas */}
            <div className="mb-3 flex items-center justify-between rounded bg-white/[0.04] px-3 py-2">
              <div>
                <div className="text-[10px] font-semibold tracking-[0.2em] text-white/70">AUTO-THROTTLE</div>
                <div className="text-[9px] text-white/35">Always accelerate, focus on steering</div>
              </div>
              <div
                className={`toggle-track ${autoGas ? 'on' : ''}`}
                onClick={() => onChangeAutoGas(!autoGas)}
                role="switch"
                aria-checked={autoGas}
              >
                <div className="toggle-knob" />
              </div>
            </div>
          </>
        )}

        {/* Live preview strip so you can feel the setting before riding */}
        <div className="mb-3 rounded border border-white/10 bg-black/40 px-3 py-2">
          <div className="mb-1 text-[9px] tracking-[0.2em] text-white/40">RESPONSE PREVIEW</div>
          <div className="relative h-2 overflow-hidden rounded-full bg-white/[0.06]">
            <div
              className="absolute inset-y-0 rounded-full bg-gradient-to-r from-rash-orange to-rash-ember"
              style={{
                width: `${((steerSensitivity - 0.6) / 1.2) * 70 + 15}%`,
                transition: 'width .15s ease',
              }}
            />
          </div>
          <div className="mt-1 text-[9px] text-white/30">
            Lap-to-lap it takes{' '}
            <span className="text-rash-orange">{(1.35 / steerSensitivity).toFixed(2)}s</span> to cross the road
          </div>
        </div>

        <div className="rounded border border-white/10 bg-white/[0.03] p-3 text-[10px] text-white/50">
          <div className="mb-1 font-semibold text-white/70">KEYBOARD (always available)</div>
          <div className="grid grid-cols-2 gap-1">
            <span><Key>←</Key> <Key>→</Key> Steer</span>
            <span><Key>↑</Key> Throttle</span>
            <span><Key>SPC</Key> Nightstick</span>
            <span><Key>SHF</Key> Nitro</span>
            <span><Key>P</Key> Pause</span>
            <span><Key>R</Key> Restart</span>
          </div>
        </div>

        <button onClick={onClose} className="btn btn-primary mt-3 w-full rounded py-2.5 text-[11px]">
          DONE
        </button>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ menu */

export function StartScreen({
  onStart,
  scores,
  muted,
  onToggleMute,
  touch,
  onSettings,
}: {
  onStart: () => void;
  scores: ScoreEntry[];
  muted: boolean;
  onToggleMute: () => void;
  touch: boolean;
  onSettings: () => void;
}) {
  return (
    <Overlay dim="linear-gradient(180deg, rgba(6,4,12,0.55) 0%, rgba(6,4,12,0.88) 70%)">
      <div className="anim-pop panel w-full max-w-[560px] rounded-lg p-4 sm:p-5">
        <div className="text-center">
          <div className="font-display text-[9px] tracking-[0.35em] text-rash-cyan neon-cyan">ARCADE · 1997 · PSEUDO-3D</div>
          <h1 className="title-glow anim-flicker mt-2 font-display text-[26px] leading-[1.15] text-rash-orange sm:text-[38px]">
            ROAD FURY
          </h1>
          <div className="mt-1 font-display text-[11px] tracking-[0.2em] text-white/85 sm:text-[14px]">JAILBREAK RUN</div>
          <div className="mt-2 overflow-hidden border-y border-white/10 py-1">
            <div className="marquee-track text-[11px] tracking-[0.25em] text-white/45">
              {'10-RIDER RACE · NAIL THE LAUNCH · SWING THE NIGHTSTICK · FINISH P1 · '.repeat(2)}
            </div>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button onClick={onStart} className="btn btn-primary anim-sheen flex-1 overflow-hidden rounded py-3 text-[14px]">
            {touch ? 'TAP TO RIDE' : 'START ENGINE'}
          </button>
          <button
            onClick={onSettings}
            className="btn btn-ghost rounded px-4 py-3 text-[11px]"
            aria-label="Settings"
            title="Settings"
          >
            ⚙
          </button>
        </div>

        {!touch && (
          <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 text-[11px] text-white/70">
            <div className="flex items-center gap-1.5">
              <Key>←</Key>
              <Key>→</Key>
              <span className="text-white/45">STEER</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Key>↑</Key>
              <Key>W</Key>
              <span className="text-white/45">THROTTLE</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Key>SPC</Key>
              <span className="text-white/45">NIGHTSTICK</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Key>SHF</Key>
              <span className="text-white/45">NITRO</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Key>↓</Key>
              <Key>S</Key>
              <span className="text-white/45">BRAKE</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Key>P</Key>
              <Key>ESC</Key>
              <span className="text-white/45">PAUSE</span>
            </div>
          </div>
        )}

        {touch && (
          <div className="mt-3 rounded border border-white/10 bg-white/[0.03] p-2 text-center text-[10px] text-white/45">
            <span className="text-rash-cyan">TILT</span> your phone to steer · <span className="text-rash-lime">GAS</span> is auto · Tap <span className="text-rash-orange">HIT</span> to swing
          </div>
        )}

        <div className="mt-3 rounded border border-white/10 bg-black/30 p-2">
          <ScoreTable scores={scores} />
        </div>

        <div className="mt-3 flex items-center justify-between text-[10px] text-white/35">
          <span className="tracking-[0.2em]">RIDE · FIGHT · SURVIVE</span>
          <div className="flex gap-2">
            <button onClick={onToggleMute} className="btn btn-ghost rounded px-2 py-1 text-[8px]">
              {muted ? '🔇' : '🔊'}
            </button>
          </div>
        </div>
      </div>
    </Overlay>
  );
}

/* ----------------------------------------------------------------- pause */

export function PauseScreen({
  onResume,
  onRestart,
  onQuit,
  muted,
  onToggleMute,
  onSettings,
}: {
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
  muted: boolean;
  onToggleMute: () => void;
  onSettings: () => void;
}) {
  return (
    <Overlay>
      <div className="anim-pop panel w-full max-w-[340px] rounded-lg p-5 text-center">
        <h2 className="font-display text-[20px] text-rash-cyan neon-cyan">PAUSED</h2>
        <p className="mt-1 text-[11px] tracking-[0.2em] text-white/40">ENGINE IDLING</p>
        <div className="mt-4 space-y-2">
          <button onClick={onResume} className="btn btn-primary w-full rounded py-2.5 text-[12px]">
            RESUME
          </button>
          <button onClick={onSettings} className="btn btn-ghost w-full rounded py-2 text-[10px]">
            ⚙ TUNE HANDLING
          </button>
          <button onClick={onRestart} className="btn btn-ghost w-full rounded py-2 text-[10px]">
            RESTART RUN
          </button>
          <button onClick={onQuit} className="btn btn-ghost w-full rounded py-2 text-[10px]">
            QUIT TO TITLE
          </button>
          <button onClick={onToggleMute} className="btn btn-ghost w-full rounded py-2 text-[8px]">
            {muted ? '🔇 SOUND OFF' : '🔊 SOUND ON'}
          </button>
        </div>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------- Rotate prompt */

/**
 * Portrait nudge. Must stay dismissible: iOS Safari supports neither
 * screen.orientation.lock() nor element fullscreen, so a hard block would leave
 * iPhone users staring at this wall with no way to actually play.
 */
export function RotatePrompt({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#06040c] px-6 text-center">
      <div className="anim-rotate mb-5 text-[52px]">📱</div>
      <div className="font-display text-[13px] tracking-[0.18em] text-rash-orange">TURN YOUR PHONE</div>
      <div className="mt-2 max-w-[280px] text-[12px] leading-relaxed tracking-[0.08em] text-white/45">
        Landscape gives you the full road and room for the controls.
      </div>
      <button onClick={onContinue} className="btn btn-ghost mt-6 rounded px-6 py-2.5 text-[10px]">
        PLAY IN PORTRAIT
      </button>
    </div>
  );
}

/* ------------------------------------------------------------- game over */

export function GameOverScreen({
  result,
  scores,
  qualifies,
  name,
  onNameChange,
  onSave,
  saved,
  onRestart,
  onMenu,
  touch,
}: {
  result: RunResult;
  scores: ScoreEntry[];
  qualifies: boolean;
  name: string;
  onNameChange: (n: string) => void;
  onSave: () => void;
  saved: boolean;
  onRestart: () => void;
  onMenu: () => void;
  touch?: boolean;
}) {
  const stats: [string, string][] = [
    ['POSITION', `${result.position} / ${result.field}`],
    ['OVERTAKES', `${result.overtakes}`],
    ['TAKEDOWNS', `${result.takedowns}`],
    ['DISTANCE', `${result.distance.toLocaleString('en-US')} M`],
    ['BEST COMBO', `x${result.bestCombo}`],
    ['TIME', `${result.time.toFixed(1)}s`],
  ];
  return (
    <Overlay dim="radial-gradient(circle at 50% 35%, rgba(90,10,10,0.55), rgba(6,4,12,0.92) 70%)">
      <div className="anim-pop panel w-full max-w-[460px] rounded-lg p-4 sm:p-5">
        <div className="text-center">
          <h2
            className="font-display text-[26px] text-rash-ember sm:text-[32px]"
            style={{ textShadow: '0 0 14px rgba(255,60,40,.8), 0 4px 0 #4a0a05' }}
          >
            BUSTED
          </h2>
          <p className="mt-1 text-[11px] tracking-[0.22em] text-white/50">{result.cause || 'YOU WENT DOWN HARD'}</p>
        </div>

        <div className="mt-3 rounded border border-white/10 bg-black/40 p-3 text-center">
          <div className="text-[9px] tracking-[0.3em] text-white/40">FINAL SCORE</div>
          <div
            className="font-display text-[28px] tabular-nums text-white sm:text-[34px]"
            style={{ textShadow: '0 0 16px rgba(255,150,60,.6), 0 4px 0 rgba(0,0,0,.8)' }}
          >
            {result.score.toLocaleString('en-US')}
          </div>
        </div>

        <div className="mt-2 grid grid-cols-3 gap-1.5">
          {stats.map(([k, v]) => (
            <div key={k} className="rounded border border-white/10 bg-white/[0.04] px-2 py-1.5">
              <div className="text-[9px] tracking-[0.2em] text-white/40">{k}</div>
              <div className="font-display text-[11px] text-rash-orange">{v}</div>
            </div>
          ))}
        </div>

        {qualifies && !saved && (
          <div className="mt-3 flex items-center gap-2 rounded border border-rash-orange/40 bg-rash-orange/10 p-2">
            <span className="font-display text-[8px] text-rash-orange">NEW RECORD!</span>
            <input
              value={name}
              onChange={(e) => onNameChange(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3))}
              maxLength={3}
              className="w-16 rounded border border-white/20 bg-black/50 px-2 py-1 text-center font-display text-[12px] tracking-widest text-white outline-none focus:border-rash-orange"
              autoComplete="off"
              autoCapitalize="characters"
              inputMode="text"
            />
            <button onClick={onSave} className="btn btn-primary flex-1 rounded py-1.5 text-[9px]">
              SAVE
            </button>
          </div>
        )}

        <div className="mt-3 rounded border border-white/10 bg-black/30 p-2">
          <ScoreTable scores={scores} highlight={saved ? result.score : undefined} />
        </div>

        <div className="mt-3 flex gap-2">
          <button onClick={onRestart} className="btn btn-primary flex-1 rounded py-2.5 text-[12px]">
            RIDE AGAIN
          </button>
          <button onClick={onMenu} className="btn btn-ghost rounded px-4 py-2.5 text-[10px]">
            TITLE
          </button>
        </div>
        <p className="mt-2 text-center text-[10px] tracking-[0.2em] text-white/30">
          {touch ? 'TAP RIDE AGAIN TO RESTART' : 'PRESS ENTER TO RESTART'}
        </p>
      </div>
    </Overlay>
  );
}