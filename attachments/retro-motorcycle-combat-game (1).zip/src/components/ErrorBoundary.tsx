import { Component, type ErrorInfo, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}
interface State {
  error: Error | null;
}

/**
 * Without this, any exception thrown while rendering the game unmounts the whole
 * React tree and the player is left staring at a pure black page with no clue
 * what happened. Now they get the actual message plus a one-tap recovery.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Keep the detail in the console for debugging, but never fail silently.
    console.error('Road Fury crashed:', error, info?.componentStack);
  }

  private recover = () => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {
      /* ignore */
    }
    try {
      if (window.caches) {
        void caches.keys().then((ks) => Promise.all(ks.map((k) => caches.delete(k))));
      }
      if (navigator.serviceWorker?.getRegistrations) {
        void navigator.serviceWorker
          .getRegistrations()
          .then((rs) => Promise.all(rs.map((r) => r.unregister())));
      }
    } catch {
      /* ignore */
    }
    setTimeout(() => location.reload(), 250);
  };

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center gap-4 bg-[#0b0712] p-6 text-center">
        <div className="text-[34px]">🏍️</div>
        <div className="font-display text-[12px] tracking-[0.18em] text-rash-orange">
          ENGINE STALLED
        </div>
        <p className="max-w-[340px] text-[13px] leading-relaxed text-white/60">
          The game hit an error while starting. Clearing the saved state and reloading usually
          fixes it.
        </p>
        <pre className="max-h-[110px] w-full max-w-[360px] overflow-auto rounded border border-white/10 bg-black/60 p-2 text-left text-[10px] leading-snug text-rash-ember/90">
          {this.state.error.message}
        </pre>
        <button onClick={this.recover} className="btn btn-primary rounded px-6 py-3 text-[11px]">
          CLEAR SAVE &amp; RESTART
        </button>
        <button onClick={() => location.reload()} className="btn btn-ghost rounded px-5 py-2 text-[9px]">
          JUST RELOAD
        </button>
      </div>
    );
  }
}
