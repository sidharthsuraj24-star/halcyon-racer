import { useCallback, useEffect, useRef, useState, type PointerEvent as RPointerEvent } from 'react';

/* ---------------------------------------------------------------- Pad */

function Pad({
  label,
  sub,
  onDown,
  onUp,
  size = 66,
  tone = 'default',
  className = '',
}: {
  label: string;
  sub?: string;
  onDown: () => void;
  onUp?: () => void;
  size?: number;
  tone?: 'default' | 'gas' | 'hit' | 'nos';
  className?: string;
}) {
  const [active, setActive] = useState(false);
  const idRef = useRef<number | null>(null);

  const down = (e: RPointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    idRef.current = e.pointerId;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
    setActive(true);
    onDown();
  };
  const up = (e: RPointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (idRef.current !== null) {
      try {
        e.currentTarget.releasePointerCapture(idRef.current);
      } catch {
        /* noop */
      }
      idRef.current = null;
    }
    setActive(false);
    onUp?.();
  };

  const toneStyle =
    tone === 'gas'
      ? { borderColor: 'rgba(140,255,120,0.55)', color: '#d9ffd0' }
      : tone === 'hit'
        ? { borderColor: 'rgba(255,150,70,0.6)', color: '#ffe0c0' }
        : tone === 'nos'
          ? { borderColor: 'rgba(110,240,255,0.55)', color: '#cdf8ff' }
          : {};

  return (
    <div
      onPointerDown={down}
      onPointerUp={up}
      onPointerCancel={up}
      onPointerLeave={up}
      className={`touch-pad flex select-none items-center justify-center rounded-full ${active ? 'active' : ''} ${className}`}
      style={{ width: size, height: size, touchAction: 'none', ...toneStyle }}
    >
      <div className="text-center leading-none">
        <div className="font-display" style={{ fontSize: size > 70 ? 13 : 11 }}>
          {label}
        </div>
        {sub && <div className="mt-1 text-[8px] tracking-[0.18em] opacity-70">{sub}</div>}
      </div>
    </div>
  );
}

/* ----------------------------------------------------------- Gyro */

function useTiltSteer(
  enabled: boolean,
  sensitivity: number,
  setInput: (k: 'left' | 'right', v: boolean) => void,
  engineRef?: React.MutableRefObject<{ steerSensitivity: number } | null>,
) {
  const baseRef = useRef<number | null>(null);
  const leanRef = useRef(0);

  useEffect(() => {
    if (!enabled) return;

    const handler = (e: DeviceOrientationEvent) => {
      const gamma = e.gamma ?? 0; // left-right tilt: -90..90
      if (baseRef.current === null) {
        baseRef.current = gamma;
      }
      const offset = (gamma - baseRef.current) * sensitivity;
      const dz = 2.5; // dead-zone in degrees
      const absOff = Math.abs(offset);
      if (absOff < dz) {
        leanRef.current = 0;
      } else {
        // smooth ramp: dead-zone edge → 25° = full lock
        leanRef.current = clamp(((absOff - dz) / (25 - dz)) * Math.sign(offset), -1, 1);
      }
    };

    window.addEventListener('deviceorientation', handler, true);
    return () => window.removeEventListener('deviceorientation', handler, true);
  }, [enabled, sensitivity]);

  useEffect(() => {
    if (!enabled) return;
    const id = setInterval(() => {
      const v = leanRef.current;
      setInput('left', v < -0.12);
      setInput('right', v > 0.12);
      // feed analog sensitivity to engine for smoother curves
      if (engineRef?.current) {
        engineRef.current.steerSensitivity = 0.7 + Math.abs(v) * 0.8;
      }
    }, 1000 / 30);
    return () => clearInterval(id);
  }, [enabled, setInput, engineRef]);

  const recalibrate = useCallback(() => {
    baseRef.current = null;
  }, []);

  return { lean: leanRef, recalibrate };
}

function clamp(v: number, min: number, max: number) {
  return v < min ? min : v > max ? max : v;
}

/* --------------------------------------------------- Main Controls */

export interface TouchSettings {
  controlScheme: 'buttons' | 'tilt';
  autoGas: boolean;
  tiltSensitivity: number;
}

export function TouchControls({
  setInput,
  attack,
  kick,
  boostDown,
  boostUp,
  settings,
}: {
  setInput: (k: 'left' | 'right' | 'up' | 'down' | 'boost', v: boolean) => void;
  attack: () => void;
  kick: () => void;
  boostDown: () => void;
  boostUp: () => void;
  settings: TouchSettings;
}) {
  const { recalibrate } = useTiltSteer(
    settings.controlScheme === 'tilt',
    settings.tiltSensitivity,
    (k, v) => setInput(k, v),
  );

  if (settings.controlScheme === 'tilt') {
    /* ---------- TILT mode: tilt to steer, big buttons for gas/attack/nos */
    return (
      <div
        className="pointer-events-none absolute inset-0 z-30 select-none"
        style={{ touchAction: 'none' }}
      >
        {/* bottom row: NOS | HIT (big) | BRAKE */}
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between px-2"
          style={{ paddingBottom: 'calc(6px + env(safe-area-inset-bottom))' }}
        >
          <div className="pointer-events-auto flex items-end gap-2">
            <Pad
              label="SLOW"
              onDown={() => setInput('down', true)}
              onUp={() => setInput('down', false)}
              size={62}
            />
            {!settings.autoGas && (
              <Pad
                label="GAS"
                onDown={() => setInput('up', true)}
                onUp={() => setInput('up', false)}
                size={62}
                tone="gas"
              />
            )}
          </div>

          {/* centre: auto-gas indicator + tap-to-attack zone */}
          <div className="pointer-events-auto flex items-end gap-2">
            <Pad label="KICK" onDown={kick} size={58} />
            <Pad label="HIT" sub="⚔" onDown={attack} size={80} tone="hit" />
          </div>

          <div className="pointer-events-auto flex items-end gap-2">
            <Pad
              label="NOS"
              onDown={boostDown}
              onUp={boostUp}
              size={58}
              tone="nos"
            />
          </div>
        </div>

        {/* recalibrate hint — tap top-centre */}
        <div
          className="pointer-events-auto absolute left-1/2 top-2 -translate-x-1/2 cursor-pointer rounded-full px-3 py-1"
          style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}
          onPointerDown={recalibrate}
        >
          <span className="font-display text-[7px] tracking-wider text-white/40">TAP TO RECALIBRATE TILT</span>
        </div>
      </div>
    );
  }

  /* ---------- BUTTONS mode (classic) */
  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 z-30 flex items-end justify-between px-2"
      style={{
        paddingBottom: 'calc(6px + env(safe-area-inset-bottom))',
        touchAction: 'none',
      }}
    >
      <div className="pointer-events-auto flex items-end gap-2">
        <Pad
          label="◄"
          onDown={() => setInput('left', true)}
          onUp={() => setInput('left', false)}
          size={68}
        />
        <Pad
          label="►"
          onDown={() => setInput('right', true)}
          onUp={() => setInput('right', false)}
          size={68}
        />
      </div>
      <div className="pointer-events-auto flex items-end gap-2">
        {/* Brake is ALWAYS available — even with auto-throttle you need to scrub speed. */}
        <Pad
          label="SLOW"
          onDown={() => setInput('down', true)}
          onUp={() => setInput('down', false)}
          size={52}
        />
        <Pad label="NOS" onDown={boostDown} onUp={boostUp} size={52} tone="nos" />
        <Pad label="KICK" onDown={kick} size={52} />
        <Pad label="HIT" sub="⚔" onDown={attack} size={72} tone="hit" />
        {!settings.autoGas && (
          <Pad
            label="GAS"
            onDown={() => setInput('up', true)}
            onUp={() => setInput('up', false)}
            size={80}
            tone="gas"
          />
        )}
      </div>
    </div>
  );
}