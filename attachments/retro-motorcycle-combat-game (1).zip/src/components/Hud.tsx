import { memo } from 'react';
import type { HudState } from '../game/types';
import { device } from '../game/device';

const segMask =
  'repeating-linear-gradient(90deg, rgba(0,0,0,0) 0px, rgba(0,0,0,0) 7px, rgba(0,0,0,0.85) 7px, rgba(0,0,0,0.85) 9px)';

function Bar({
  value,
  color,
  glow,
  height = 14,
}: {
  value: number;
  color: string;
  glow: string;
  height?: number;
}) {
  return (
    <div
      className="relative w-full overflow-hidden rounded-[3px] border border-black/70 bg-black/60"
      style={{ height }}
    >
      <div
        className="bar-fill h-full"
        style={{
          width: `${Math.max(0, Math.min(100, value))}%`,
          background: color,
          boxShadow: `0 0 10px ${glow}, inset 0 1px 0 rgba(255,255,255,0.35)`,
        }}
      />
      <div className="pointer-events-none absolute inset-0" style={{ backgroundImage: segMask }} />
    </div>
  );
}

function ordinal(n: number) {
  const v = n % 100;
  if (v >= 11 && v <= 13) return 'TH';
  return ['TH', 'ST', 'ND', 'RD'][n % 10] ?? 'TH';
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <span className="text-[10px] font-semibold tracking-[0.18em] text-white/45">{label}</span>
      <span
        className="font-display text-[11px] tabular-nums"
        style={{ color: accent ?? '#e9e6f5', textShadow: '0 2px 0 rgba(0,0,0,0.8)' }}
      >
        {value}
      </span>
    </div>
  );
}

export const Hud = memo(function Hud({
  hud,
  onPause,
  paused,
  touch,
  bestScore = 0,
}: {
  hud: HudState;
  onPause: () => void;
  paused: boolean;
  touch: boolean;
  bestScore?: number;
}) {
  const hp = hud.health;
  const hpColor =
    hp > 60
      ? 'linear-gradient(180deg,#9dff8a,#36c45a)'
      : hp > 30
        ? 'linear-gradient(180deg,#ffdc6b,#f29b1d)'
        : 'linear-gradient(180deg,#ff8a7a,#e32718)';
  const hpGlow = hp > 60 ? 'rgba(80,230,120,.6)' : hp > 30 ? 'rgba(255,200,80,.6)' : 'rgba(255,70,50,.75)';
  const isMobile = device.isMobile;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none p-2 sm:p-3">
      {/* ---------------- top left: armor + heat */}
      <div
        className="absolute left-2 top-2 w-[42vw] max-w-[260px] sm:left-3 sm:top-3"
        style={{ paddingLeft: isMobile ? 'env(safe-area-inset-left)' : undefined }}
      >
        <div className="hud-chip rounded-md px-2 py-1.5">
          <div className="mb-1 flex items-center justify-between">
            <span className="font-display text-[8px] tracking-wider text-rash-orange">ARMOR</span>
            <span className="font-display text-[8px] tabular-nums text-white/70">{hp}%</span>
          </div>
          <Bar value={hp} color={hpColor} glow={hpGlow} />
          <div className="mt-1.5 flex items-center gap-1">
            <span className="text-[9px] font-semibold tracking-[0.2em] text-white/40">HEAT</span>
            <div className="flex gap-0.5">
              {[0, 1, 2, 3, 4].map((i) => (
                <span
                  key={i}
                  className={i < hud.wanted ? 'anim-pulse' : ''}
                  style={{
                    fontSize: 11,
                    lineHeight: '11px',
                    color: i < hud.wanted ? '#ff5a4d' : 'rgba(255,255,255,0.18)',
                    textShadow: i < hud.wanted ? '0 0 8px rgba(255,80,60,0.9)' : 'none',
                  }}
                >
                  ★
                </span>
              ))}
            </div>
          </div>
          {/* Pursuit counter: how many officers are actively hunting right now */}
          {hud.cops > 0 && (
            <div className="mt-1 flex items-center gap-1">
              <span className="text-[9px] font-semibold tracking-[0.2em] text-white/40">COPS</span>
              <div className="flex items-center gap-0.5">
                {Array.from({ length: hud.cops }).map((_, i) => (
                  <span
                    key={i}
                    className="anim-pulse"
                    style={{
                      fontSize: 10,
                      lineHeight: '10px',
                      color: '#6fb4ff',
                      textShadow: '0 0 8px rgba(90,160,255,0.95)',
                    }}
                  >
                    ◆
                  </span>
                ))}
                <span className="ml-1 text-[8px] tracking-[0.14em] text-white/35">PURSUIT</span>
              </div>
            </div>
          )}
          {hud.field > 1 && (
            <div className="mt-1.5 flex items-baseline gap-1.5 border-t border-white/10 pt-1">
              <span className="text-[9px] font-semibold tracking-[0.2em] text-white/40">POS</span>
              <span
                key={hud.position}
                className="anim-pop font-display text-[18px] leading-none tabular-nums"
                style={{
                  color: hud.position === 1 ? '#ffd86b' : hud.position <= 3 ? '#8dff6a' : '#f2f3f7',
                  textShadow: '0 0 10px rgba(255,200,90,.45), 0 2px 0 rgba(0,0,0,.85)',
                }}
              >
                {hud.position}
                <sup className="ml-0.5 text-[8px]">{ordinal(hud.position)}</sup>
              </span>
              <span className="font-display text-[10px] text-white/45">/ {hud.field}</span>
            </div>
          )}
        </div>
      </div>

      {/* ---------------- top right: score */}
      <div
        className="absolute right-2 top-2 w-[38vw] max-w-[220px] sm:right-3 sm:top-3"
        style={{ paddingRight: isMobile ? 'env(safe-area-inset-right)' : undefined }}
      >
        <div className="hud-chip rounded-md px-2 py-1.5">
          <div className="text-right">
            <div className="text-[9px] font-semibold tracking-[0.25em] text-white/45">SCORE</div>
            <div
              className="font-display text-[15px] leading-tight tabular-nums text-white sm:text-[18px]"
              style={{ textShadow: '0 0 10px rgba(255,160,70,.55), 0 3px 0 rgba(0,0,0,.8)' }}
            >
              {hud.score.toLocaleString('en-US')}
            </div>
          </div>
          <div className="mt-1 space-y-0.5">
            <Stat label="DIST" value={`${hud.distance.toLocaleString('en-US')} M`} accent="#6ff0ff" />
            <Stat label="K.O." value={`${hud.takedowns}`} accent="#ff8a3c" />
          </div>
        </div>
      </div>

      {/* ---------------- combo */}
      {hud.combo >= 2 && (
        <div className="absolute left-1/2 top-13 -translate-x-1/2 sm:top-14">
          <div
            key={hud.combo}
            className="anim-pop hud-chip rounded-md px-3 py-1 text-center"
            style={{ borderColor: 'rgba(255,170,70,0.65)' }}
          >
            <div
              className="font-display text-[13px] text-rash-orange"
              style={{ textShadow: '0 0 12px rgba(255,140,60,.9)' }}
            >
              x{hud.combo}
            </div>
            <div className="text-[8px] tracking-[0.22em] text-white/50">COMBO</div>
          </div>
        </div>
      )}

      {/* ---------------- off-road warning */}
      {hud.offroad && (
        <div className="absolute left-1/2 top-1/3 -translate-x-1/2">
          <div
            className="anim-pulse font-display text-[11px] tracking-wider text-rash-ember sm:text-[14px]"
            style={{ textShadow: '0 0 14px rgba(255,60,40,.9), 0 2px 0 #000' }}
          >
            ◄ OFF ROAD ►
          </div>
        </div>
      )}

      {/* ---------------- best-score marker */}
      {bestScore > 0 && hud.score < bestScore && (
        <div className="absolute left-1/2 top-[4.5rem] -translate-x-1/2 sm:top-[5rem]">
          <div className="font-display text-[7px] tracking-[0.2em] text-white/25">
            TARGET {bestScore.toLocaleString('en-US')}
          </div>
        </div>
      )}

      {/* ---------------- bottom left: speed + nitro */}
      <div
        className="absolute left-2 w-[46vw] max-w-[250px] sm:left-3"
        style={{
          bottom: touch
            ? 'calc(90px + env(safe-area-inset-bottom))'
            : 12,
          paddingLeft: isMobile ? 'env(safe-area-inset-left)' : undefined,
        }}
      >
        <div className="hud-chip rounded-md px-2 py-1.5">
          <div className="flex items-end justify-between">
            <div className="flex items-baseline gap-1">
              <span
                className="font-display text-[20px] tabular-nums leading-none text-white sm:text-[26px]"
                style={{
                  textShadow: `0 0 ${8 + hud.speedPct * 16}px rgba(111,240,255,${0.3 + hud.speedPct * 0.6}), 0 3px 0 rgba(0,0,0,.85)`,
                }}
              >
                {hud.speedKph}
              </span>
              <span className="text-[10px] font-bold tracking-[0.2em] text-white/50">KM/H</span>
            </div>
          </div>
          <div className="mt-1">
            <Bar
              value={hud.speedPct * 100}
              color="linear-gradient(90deg,#6ff0ff,#4a7bff 60%,#a06bff)"
              glow="rgba(111,240,255,.55)"
              height={8}
            />
          </div>
          <div className="mt-1 flex items-center gap-1.5">
            <span className="font-display text-[7px] tracking-wider text-rash-orange">GRIP</span>
            <div className="flex-1">
              <Bar
                value={hud.grip * 100}
                color={
                  hud.grip > 0.6
                    ? 'linear-gradient(90deg,#ffd86b,#ff8a3c)'
                    : 'linear-gradient(90deg,#ff6b5a,#e01f0f)'
                }
                glow={hud.grip > 0.6 ? 'rgba(255,180,80,.45)' : 'rgba(255,70,50,.7)'}
                height={7}
              />
            </div>
          </div>
          <div className="mt-1 flex items-center gap-1.5">
            <span className="font-display text-[7px] tracking-wider text-rash-cyan">NITRO</span>
            <div className="flex-1">
              <Bar
                value={hud.boost}
                color="linear-gradient(90deg,#8dff6a,#2fd0a0)"
                glow="rgba(140,255,110,.5)"
                height={7}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ---------------- equipped weapon */}
      {hud.field > 1 && (
        <div className="absolute bottom-2 right-2 text-right sm:bottom-3 sm:right-3">
          <div className="hud-chip rounded-md px-2 py-1.5">
            <div className="text-[9px] font-semibold tracking-[0.25em] text-white/40">WEAPON</div>
            <div
              className="font-display text-[10px] tracking-wider"
              style={{
                color:
                  hud.weapon === 'STEEL CHAIN' ? '#d6dde8' : hud.weapon === 'DIRT WRENCH' ? '#e0a44a' : '#aab3c2',
                textShadow: '0 2px 0 rgba(0,0,0,.8)',
              }}
            >
              {hud.weapon}
            </div>
            <div className="mt-0.5 text-[9px] tracking-[0.15em] text-white/35">POWER {hud.weaponPower}%</div>
          </div>
        </div>
      )}

      {/* ---------------- pause button */}
      <button
        onClick={onPause}
        className="pointer-events-auto absolute left-1/2 top-2 flex h-9 w-12 -translate-x-1/2 items-center justify-center rounded-md border-2 border-white/20 bg-black/55 text-white/80 active:scale-95 sm:top-3"
        aria-label={paused ? 'Resume' : 'Pause'}
        style={{ touchAction: 'manipulation' }}
      >
        <span className="font-display text-[10px]">{paused ? '▶' : 'II'}</span>
      </button>
    </div>
  );
});