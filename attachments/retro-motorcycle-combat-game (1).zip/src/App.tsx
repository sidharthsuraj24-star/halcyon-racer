import { useCallback, useEffect, useRef, useState } from 'react';
import { Engine } from './game/engine';
import { audio } from './game/audio';
import { device, requestGyroPermission } from './game/device';
import { haptic } from './game/haptics';
import {
  isHighScore,
  loadAutoGas,
  loadControlScheme,
  loadMuted,
  loadName,
  loadScores,
  loadSteerSensitivity,
  loadTiltSensitivity,
  saveAutoGas,
  saveControlScheme,
  saveMuted,
  saveName,
  saveScore,
  saveSteerSensitivity,
  saveTiltSensitivity,
} from './game/storage';
import type { HudState, RunResult, ScoreEntry } from './game/types';
import { Hud } from './components/Hud';
import { TouchControls, type TouchSettings } from './components/TouchControls';
import {
  BootScreen,
  GameOverScreen,
  PauseScreen,
  RotatePrompt,
  SettingsPanel,
  StartScreen,
} from './components/Screens';

type Phase = 'menu' | 'playing' | 'paused' | 'gameover';

const EMPTY_HUD: HudState = {
  speedKph: 0,
  speedPct: 0,
  health: 100,
  score: 0,
  distance: 0,
  takedowns: 0,
  combo: 0,
  boost: 100,
  wanted: 0,
  offroad: false,
  position: 10,
  field: 10,
  countdown: 4,
  cops: 0,
  weapon: 'NIGHTSTICK',
  weaponPower: 100,
  grip: 1,
};

function isLandscape() {
  if (typeof screen !== 'undefined' && screen.orientation?.type) {
    return screen.orientation.type.startsWith('landscape');
  }
  return window.innerWidth > window.innerHeight;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<Engine | null>(null);

  const [phase, setPhase] = useState<Phase>('menu');
  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [result, setResult] = useState<RunResult | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [qualifies, setQualifies] = useState(false);
  const [saved, setSaved] = useState(false);
  const [name, setName] = useState(() => loadName());
  const [muted, setMuted] = useState(() => loadMuted());
  const [showSettings, setShowSettings] = useState(false);
  const [landscape, setLandscape] = useState(() => isLandscape());
  const [controlScheme, setControlScheme] = useState<'buttons' | 'tilt'>(() => loadControlScheme());
  const [autoGas, setAutoGas] = useState(() => loadAutoGas());
  const [tiltSensitivity, setTiltSensitivity] = useState(() => loadTiltSensitivity());
  const [steerSensitivity, setSteerSensitivity] = useState(() => loadSteerSensitivity());
  const [gyroGranted, setGyroGranted] = useState(false);
  // Boot sequence: assets stream in behind this so slow phones never show a
  // blank screen that looks like the game failed to open.
  const [booting, setBooting] = useState(true);
  const [bootPct, setBootPct] = useState(0);
  // Once the rider opts into portrait we stop nagging for the rest of the session.
  const [rotateDismissed, setRotateDismissed] = useState(false);

  // Touch capability is sticky-upgradable: if a real touch ever happens we switch
  // to touch UI even when UA sniffing said desktop (hybrid laptops, misdetection).
  const [touchSeen, setTouchSeen] = useState(false);
  const isMobile = device.isMobile || touchSeen;
  const touch = isMobile;

  // mirror state for stable event handlers
  const ref = useRef({ phase, result, qualifies, saved, name, showSettings, booting });
  ref.current = { phase, result, qualifies, saved, name, showSettings, booting };
  const touchRef = useRef(touch);
  touchRef.current = touch;
  const autoGasRef = useRef(autoGas);
  autoGasRef.current = autoGas;
  const controlSchemeRef = useRef(controlScheme);
  controlSchemeRef.current = controlScheme;

  /* ------------------------------------------------------------- engine */

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const engine = new Engine(canvas, {
      onHud: (h) => setHud(h),
      onGameOver: (r) => {
        setResult(r);
        setQualifies(isHighScore(r.score));
        setSaved(false);
        setPhase('gameover');
        haptic.crash();
      },
    });
    engineRef.current = engine;
    engine.start();
    audio.setMuted(loadMuted());
    engine.autoGas = loadAutoGas();
    engine.steerSensitivity = loadSteerSensitivity();

    // Stream the remaining rival liveries in one chunk per frame. Doing this
    // all at once froze the main thread long enough on phones that the page
    // looked broken; the boot screen now covers it and reports real progress.
    let bootRaf = 0;
    const bootStep = () => {
      const pct = engine.stepAssetBuild();
      setBootPct(pct);
      if (pct < 1) {
        bootRaf = requestAnimationFrame(bootStep);
      } else {
        // One more frame so the canvas has a laid-out size before we reveal it.
        engine.resize();
        bootRaf = requestAnimationFrame(() => setBooting(false));
      }
    };
    bootRaf = requestAnimationFrame(bootStep);

    const ro = new ResizeObserver(() => engine.resize());
    ro.observe(wrap);
    const onOrient = () => {
      window.setTimeout(() => {
        engine.resize();
        setLandscape(isLandscape());
      }, 200);
    };
    window.addEventListener('orientationchange', onOrient);
    window.addEventListener('resize', onOrient);
    return () => {
      cancelAnimationFrame(bootRaf);
      ro.disconnect();
      window.removeEventListener('orientationchange', onOrient);
      window.removeEventListener('resize', onOrient);
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  /* ------------------------------------------------------------ actions */

  const persist = useCallback(() => {
    const s = ref.current;
    if (s.result && s.qualifies && !s.saved) {
      const next = saveScore({
        name: (s.name || 'RSH').toUpperCase().slice(0, 3) || 'RSH',
        score: s.result.score,
        distance: s.result.distance,
        takedowns: s.result.takedowns,
        date: Date.now(),
      });
      saveName(s.name || 'RSH');
      setScores(next);
      setSaved(true);
      return next;
    }
    return undefined;
  }, []);

  const startGame = useCallback(() => {
    if (ref.current.booting) return; // assets still streaming in
    persist();
    audio.resume();
    const e = engineRef.current;
    if (!e) return;
    e.touchHints = touchRef.current;
    e.autoGas = autoGasRef.current;

    // Kick off the countdown FIRST. Waiting on the iOS gyro prompt or a
    // fullscreen request before this point delayed the start by seconds.
    e.startRun();
    e.setPaused(false);
    setHud(EMPTY_HUD);
    setResult(null);
    setPhase('playing');

    // Housekeeping that can happily finish while the lights count down.
    if (controlSchemeRef.current === 'tilt' && !gyroGranted) {
      void requestGyroPermission().then(setGyroGranted);
    }
    // Deliberately NO automatic fullscreen / orientation lock here.
    // On Android it fires a system toast ("drag from the top to exit") and, if
    // anything else goes wrong, leaves the player stranded in an inescapable
    // black fullscreen with no browser chrome to reload from. The game is fully
    // playable in the normal viewport, so we let the rider choose.
  }, [persist, gyroGranted]);

  const toMenu = useCallback(() => {
    persist();
    const e = engineRef.current;
    if (!e) return;
    e.setPaused(false);
    e.toAttract();
    setScores(loadScores());
    setPhase('menu');
    // exit fullscreen
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
  }, [persist]);

  const togglePause = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    setPhase((p) => {
      if (p === 'playing') {
        e.setPaused(true);
        audio.ui();
        haptic.ui();
        return 'paused';
      }
      if (p === 'paused') {
        e.setPaused(false);
        audio.ui();
        haptic.ui();
        return 'playing';
      }
      return p;
    });
  }, []);

  /** Open settings; if a run is live, pause it first so the bike doesn't crash. */
  const openSettings = useCallback(() => {
    const e = engineRef.current;
    if (e && ref.current.phase === 'playing') {
      e.setPaused(true);
      setPhase('paused');
    }
    audio.ui();
    setShowSettings(true);
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      audio.resume();
      audio.setMuted(next);
      saveMuted(next);
      return next;
    });
  }, []);

  // Only the on-screen touch pads call this, so it hands control back to touch mode.
  const setInput = useCallback((k: 'left' | 'right' | 'up' | 'down' | 'boost', v: boolean) => {
    const e = engineRef.current;
    if (!e) return;
    e.input[k] = v;
    if (v) e.keyboardDriving = false;
  }, []);

  const doAttack = useCallback(() => {
    engineRef.current?.attack();
  }, []);

  const doKick = useCallback(() => {
    engineRef.current?.kick();
  }, []);

  const updateControlScheme = useCallback(
    (scheme: 'buttons' | 'tilt') => {
      setControlScheme(scheme);
      saveControlScheme(scheme);
      if (scheme === 'tilt' && !gyroGranted) {
        requestGyroPermission().then(setGyroGranted);
      }
    },
    [gyroGranted],
  );

  const updateAutoGas = useCallback(
    (v: boolean) => {
      setAutoGas(v);
      saveAutoGas(v);
      if (engineRef.current) engineRef.current.autoGas = v;
    },
    [],
  );

  const updateTiltSensitivity = useCallback((v: number) => {
    setTiltSensitivity(v);
    saveTiltSensitivity(v);
  }, []);

  const updateSteerSensitivity = useCallback((v: number) => {
    setSteerSensitivity(v);
    saveSteerSensitivity(v);
    if (engineRef.current) engineRef.current.steerSensitivity = v;
  }, []);

  /* ---------------------------------------------------------- keyboard */

  useEffect(() => {
    const down = (ev: KeyboardEvent) => {
      const e = engineRef.current;
      if (!e) return;
      const p = ref.current.phase;
      const code = ev.code;
      if (
        ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space', 'KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(code)
      ) {
        ev.preventDefault();
      }
      if (ev.repeat) return;
      // While the settings modal is open only Escape is meaningful.
      if (ref.current.showSettings && code !== 'Escape') return;
      switch (code) {
        case 'ArrowLeft':
        case 'KeyA':
          e.input.left = true;
          e.keyboardDriving = true;
          break;
        case 'ArrowRight':
        case 'KeyD':
          e.input.right = true;
          e.keyboardDriving = true;
          break;
        case 'ArrowUp':
        case 'KeyW':
          e.input.up = true;
          // Keyboard rider: bike moves ONLY while ↑ / W is held.
          e.keyboardDriving = true;
          break;
        case 'ArrowDown':
        case 'KeyS':
          e.input.down = true;
          e.keyboardDriving = true;
          break;
        case 'ShiftLeft':
        case 'ShiftRight':
          e.input.boost = true;
          break;
        case 'KeyF':
        case 'KeyL':
          if (p === 'playing') e.kick();
          break;
        case 'Space':
          if (p === 'playing') e.attack();
          else if (p === 'menu') startGame();
          else if (p === 'gameover') startGame();
          break;
        case 'Enter':
        case 'NumpadEnter':
          if (p === 'menu' || p === 'gameover') startGame();
          else if (p === 'paused') togglePause();
          break;
        case 'KeyP':
        case 'Escape':
          // Escape closes Settings first, then falls through to pause toggling.
          if (ref.current.showSettings) {
            setShowSettings(false);
            break;
          }
          if (p === 'playing' || p === 'paused') togglePause();
          break;
        case 'KeyR':
          if (p === 'playing' || p === 'gameover' || p === 'paused') startGame();
          break;
        case 'KeyM':
          toggleMute();
          break;
      }
    };
    const up = (ev: KeyboardEvent) => {
      const e = engineRef.current;
      if (!e) return;
      switch (ev.code) {
        case 'ArrowLeft':
        case 'KeyA':
          e.input.left = false;
          break;
        case 'ArrowRight':
        case 'KeyD':
          e.input.right = false;
          break;
        case 'ArrowUp':
        case 'KeyW':
          e.input.up = false;
          break;
        case 'ArrowDown':
        case 'KeyS':
          e.input.down = false;
          break;
        case 'ShiftLeft':
        case 'ShiftRight':
          e.input.boost = false;
          break;
      }
    };
    const blur = () => {
      const e = engineRef.current;
      if (!e) return;
      e.input.left = e.input.right = e.input.up = e.input.down = e.input.boost = false;
      if (ref.current.phase === 'playing') togglePause();
    };
    const onVisibility = () => {
      if (document.hidden) blur();
    };
    // A genuine touch upgrades us to the touch UI permanently.
    const onTouch = () => setTouchSeen(true);

    window.addEventListener('touchstart', onTouch, { passive: true, once: true });
    window.addEventListener('keydown', down, { passive: false });
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('touchstart', onTouch);
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [startGame, togglePause, toggleMute]);

  /* -------------------------------------------------------------- view */

  // A nudge, never a wall: portrait play stays available (see RotatePrompt).
  const needsRotate =
    isMobile && !landscape && !rotateDismissed && (phase === 'playing' || phase === 'paused');

  const touchSettings: TouchSettings = {
    controlScheme,
    autoGas,
    tiltSensitivity,
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#06040c]">
      <div
        ref={wrapRef}
        className={`relative h-full w-full overflow-hidden ${device.enableScanlines ? 'scanlines' : ''} ${device.enableCrt ? 'crt' : ''}`}
      >
        <canvas ref={canvasRef} className="h-full w-full" />

        {(phase === 'playing' || phase === 'paused') && (
          <Hud
            hud={hud}
            onPause={togglePause}
            paused={phase === 'paused'}
            touch={touch}
            bestScore={scores[0]?.score ?? 0}
          />
        )}

        {touch && phase === 'playing' && (
          <TouchControls
            setInput={setInput}
            attack={doAttack}
            kick={doKick}
            boostDown={() => setInput('boost', true)}
            boostUp={() => setInput('boost', false)}
            settings={touchSettings}
          />
        )}

        {booting && <BootScreen pct={bootPct} />}

        {!booting && phase === 'menu' && (
          <StartScreen
            onStart={startGame}
            scores={scores}
            muted={muted}
            onToggleMute={toggleMute}
            touch={touch}
            onSettings={openSettings}
          />
        )}

        {phase === 'paused' && (
          <PauseScreen
            onResume={togglePause}
            onRestart={startGame}
            onQuit={toMenu}
            muted={muted}
            onToggleMute={toggleMute}
            onSettings={openSettings}
          />
        )}

        {/* Settings sits above every screen so handling can be tuned mid-run */}
        {showSettings && (
          <SettingsPanel
            controlScheme={controlScheme}
            autoGas={autoGas}
            tiltSensitivity={tiltSensitivity}
            steerSensitivity={steerSensitivity}
            isMobile={isMobile}
            onChangeScheme={updateControlScheme}
            onChangeAutoGas={updateAutoGas}
            onChangeTilt={updateTiltSensitivity}
            onChangeSteer={updateSteerSensitivity}
            onClose={() => setShowSettings(false)}
          />
        )}

        {phase === 'gameover' && result && (
          <GameOverScreen
            result={result}
            scores={scores}
            qualifies={qualifies}
            name={name}
            onNameChange={setName}
            onSave={() => persist()}
            saved={saved}
            onRestart={startGame}
            onMenu={toMenu}
            touch={touch}
          />
        )}

        {needsRotate && <RotatePrompt onContinue={() => setRotateDismissed(true)} />}
      </div>
    </div>
  );
}